const { chromium } = require('playwright');
const log=[]; const ok=(c,m)=>log.push((c?'PASS ':'FAIL ')+m);
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext({viewport:{width:1400,height:900}})).newPage();
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  // Mock supabase-js before the page scripts run
  await p.addInitScript(require('fs').readFileSync(__dirname+'/mock-supabase.js','utf8'));
  // block the real CDN so the mock stays
  await p.route('**/supabase.min.js', r=>r.fulfill({status:200,body:'/* mocked */',contentType:'application/javascript'}));
  const url='file://'+process.cwd()+'/index.html';
  try {
  await p.goto(url); await p.waitForTimeout(500);
  ok(await p.locator('#demoBanner').isHidden(),'real mode: demo banner hidden');
  ok(await p.locator('#signInBtn').isVisible() && await p.locator('#createAccountBtn').isVisible(),'signed out: Sign in + Create account visible');
  ok(await p.locator('.account-btn').isHidden(),'signed out: Account button hidden');
  // gate: messaging requires sign in
  await p.locator('.profile-card .message-person').first().click(); await p.waitForTimeout(300);
  ok(await p.locator('#page-create-account').evaluate(e=>e.classList.contains('active')),'Message while signed out -> create account page');
  ok(await p.locator('.chat-window').count()===0,'no chat opened while signed out');
  // sign up
  await p.fill('#suName','Egis'); await p.fill('#suEmail','egis@example.com'); await p.fill('#suPass','short'); await p.click('[data-auth-signup]'); await p.waitForTimeout(200);
  ok((await p.locator('.toast').last().textContent()).includes('8 characters'),'short password rejected');
  await p.fill('#suPass','longpassword1'); await p.click('[data-auth-signup]'); await p.waitForTimeout(800);
  ok(await p.locator('#page-account').evaluate(e=>e.classList.contains('active')),'sign up -> account page');
  ok((await p.textContent('#accountName')).trim()==='Egis','account shows real name');
  ok((await p.textContent('#accountRole')).trim()==='Client','new account is a client');
  ok(await p.locator('#signInBtn').isHidden() && await p.locator('.account-btn').isVisible(),'signed in: header switches');
  ok(await p.locator('#signOutBtn').isVisible(),'sign out button visible');
  ok(await p.locator('#myProfileBtn').isHidden(),'client: no editor profile button');
  ok(await p.locator('.reco-card').count()===0,'client: no progress reminder');
  // settings: role select disabled in real mode
  await p.goto(url+'#settings'); await p.waitForTimeout(400);
  ok(await p.locator('#accountTypeSelect').isDisabled(),'account type cannot be changed by hand');
  // invite -> editor
  await p.goto(url+'#join-editor'); await p.waitForTimeout(300);
  await p.fill('#inviteCode','CUV-AAAA-BBBB'); await p.click('#inviteBtn'); await p.waitForTimeout(300);
  ok((await p.textContent('#inviteResult')).includes('not valid'),'invalid invite rejected by server');
  await p.fill('#inviteCode','CUV-2026-EDIT'); await p.click('#inviteBtn'); await p.waitForTimeout(500);
  ok((await p.textContent('#inviteResult')).includes('Invite accepted'),'valid invite accepted by server');
  await p.goto(url+'#account'); await p.waitForTimeout(300);
  ok((await p.textContent('#accountRole')).trim()==='Editor','role is now Editor');
  ok(await p.locator('#myProfileBtn').isVisible(),'editor: My editor profile button');
  // sign out / sign in with wrong then right password
  await p.click('#signOutBtn'); await p.waitForTimeout(400);
  ok(await p.locator('#signInBtn').isVisible(),'signed out again');
  await p.click('#signInBtn'); await p.waitForTimeout(300);
  ok(await p.locator('[data-auth-pane="signin"]').isVisible(),'Sign in button opens sign-in pane');
  await p.fill('#siEmail','egis@example.com'); await p.fill('#siPass','wrong'); await p.click('[data-auth-signin]'); await p.waitForTimeout(300);
  ok((await p.locator('.toast').last().textContent()).includes('Wrong email'),'wrong password message');
  await p.fill('#siPass','longpassword1'); await p.click('[data-auth-signin]'); await p.waitForTimeout(600);
  ok(await p.locator('#page-account').evaluate(e=>e.classList.contains('active')),'sign in -> account page');
  ok((await p.textContent('#accountRole')).trim()==='Editor','role persisted from server');
  // duplicate sign up
  await p.click('#signOutBtn'); await p.waitForTimeout(300); await p.click('#createAccountBtn'); await p.waitForTimeout(300);
  await p.fill('#suName','X'); await p.fill('#suEmail','egis@example.com'); await p.fill('#suPass','longpassword1'); await p.click('[data-auth-signup]'); await p.waitForTimeout(300);
  ok((await p.locator('.toast').last().textContent()).includes('already exists'),'duplicate email message');
  await p.screenshot({path:'shots/auth.png'});
  } catch(e){ log.push('EXCEPTION '+e.message.split('\n')[0]); await p.screenshot({path:'shots/auth-fail.png'}); }
  await b.close(); console.log(log.join('\n')); console.log(errs.length?('ERRORS:\n'+errs.join('\n')):'no page errors');
})();
