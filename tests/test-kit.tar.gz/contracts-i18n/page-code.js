  // ---------- contract templates: types, governing law, clauses, versions, PDF ----------
  const CT_TYPES=["fixed","hourly","retainer","quick"];
  const CT_LANGS=["en","de","ru","lt","es","pl","uk"];
  const CT_COUNTRIES=["LT","LV","EE","PL","DE","AT","CH","NL","BE","LU","FR","ES","PT","IT","IE","GB","DK","SE","NO","FI","IS","CZ","SK","HU","SI","HR","RO","BG","GR","CY","MT","UA","MD","GE","RS","TR","US","CA","AU","NZ","IL","AE","IN","BR","MX","JP","KR","SG","ZA"];
  const CT_TOGGLES={ fixed:["deposit","cancel","late","usage","credit","raw","materials","nda","liability","force","vat"], hourly:["deposit","cancel","late","usage","credit","raw","materials","nda","liability","force","vat"], retainer:["late","usage","credit","raw","materials","nda","liability","force","vat"], quick:["usage","credit","materials","late","vat"] };
  const CT_DEFAULT_ON={ deposit:false, cancel:true, late:false, usage:true, credit:true, raw:false, materials:true, nda:false, liability:true, force:true, vat:true };
  // toggles that make no sense with a protected payment (the money is already held by Cuvori)
  const ctTogglesFor=(type,esc)=>(CT_TOGGLES[type]||[]).filter(k=>!(esc&&k==="deposit"));
  const CT_UNIT={ project:"perProject", hour:"perHour", day:"perDay", month:"ct_perMonth" };
  function tl(lang, key){ const o=CT_LANGS.includes(lang)?T[lang]:null; const own=x=>x&&Object.prototype.hasOwnProperty.call(x,key)&&typeof x[key]==="string"&&x[key]; return own(o)?o[key]:own(T.en)?T.en[key]:escapeHtml(String(key)); }
  function countryName(code, lang){ if(code==="XX") return tl(lang,"ct_countryOther"); try{ return new Intl.DisplayNames([lang||"en"],{type:"region"}).of(code)||code; }catch(e){ return code; } }
  function ctDefaultTerms(type){ const on={}; (CT_TOGGLES[type]||[]).forEach(k=>on[k]=!!CT_DEFAULT_ON[k]); return { on, cancel_days:type==="retainer"?30:7, late_pct:2, pay_days:7, hours:10, cap:15, months:1, grace_days:7, deposit_pct:30, included:"", custom:"" }; }
  function ctNum(v,def,min,max){ const n=Number(v); return Number.isFinite(n)?Math.min(max,Math.max(min,n)):def; }
  function ctCleanTerms(raw, type){
    const d=ctDefaultTerms(type), r=(raw&&typeof raw==="object")?raw:{}; const on={};
    (CT_TOGGLES[type]||[]).forEach(k=>on[k]=(r.on&&typeof r.on==="object"&&k in r.on)?!!r.on[k]:d.on[k]);
    return { on, cancel_days:Math.round(ctNum(r.cancel_days,d.cancel_days,3,365)), late_pct:ctNum(r.late_pct,d.late_pct,0,5), pay_days:Math.round(ctNum(r.pay_days,d.pay_days,0,90)),
      hours:ctNum(r.hours,d.hours,0,10000), cap:ctNum(r.cap,d.cap,0,10000), months:Math.round(ctNum(r.months,d.months,1,24)),
      grace_days:Math.round(ctNum(r.grace_days,d.grace_days,3,60)), deposit_pct:Math.round(ctNum(r.deposit_pct,d.deposit_pct,0,50)),
      included:String(r.included||"").slice(0,1000), custom:String(r.custom||"").slice(0,5000) };
  }
  function ctGuessCountry(){
    try{ for(const l of (navigator.languages||[navigator.language||""])){ const r=new Intl.Locale(l).region; if(r&&CT_COUNTRIES.includes(r)) return r; } }catch(e){}
    return ({lt:"LT",de:"DE",pl:"PL",uk:"UA",es:"ES",ru:"XX",en:"XX"})[state.language]||"XX";
  }
  function ctTypeOf(c){ return CT_TYPES.includes(c.contract_type)?c.contract_type:"fixed"; }
  function ctLangOf(c){ return CT_LANGS.includes(c.language)?c.language:"en"; }
  function ctLawOf(c){ return /^[A-Z]{2}$/.test(String(c.law_country||""))?c.law_country:"XX"; }
  // the contract as a list of clauses {t:title, b:body} in the contract's own language (plain text, escaped when rendered)
  function ctClauses(c, names){
    const lang=ctLangOf(c), type=ctTypeOf(c), tm=ctCleanTerms(c.terms,type), law=ctLawOf(c), esc=isEscrow(c);
    const L=k=>tl(lang,k), unit=L(CT_UNIT[c.pricing]||"perProject");
    const v={ editor:names.editor, client:names.client, title:c.title||"", price:money(c.price,c.currency), unit, deadline:c.deadline?fmtDate(c.deadline):"", revisions:c.revisions??0, country:countryName(law,lang),
      days:tm.cancel_days, pct:tm.late_pct, hours:tm.hours, cap:tm.cap, included:tm.included||"—", months:tm.months, payDays:tm.pay_days,
      autoDays:Number.isFinite(+c.auto_days)&&+c.auto_days>0?+c.auto_days:ESCROW.days, grace:tm.grace_days, dep:tm.deposit_pct,
      feePct:ESCROW.feePercent, feeFixed:money(ESCROW.feeFixedCents/100,c.currency), lang:lang.toUpperCase() };
    const F=k=>fill(L(k),v); const out=[]; const add=(tk,bk)=>out.push({t:L(tk),b:F(bk)});
    const on=k=>!!tm.on[k] && ctTogglesFor(type,esc).includes(k);
    add("k_scope_t","k_scope");
    if(type==="hourly") add("k_price_hourly_t","k_price_hourly"); else if(type==="retainer") add("k_price_retainer_t","k_price_retainer"); else if(type==="quick") add("k_price_quick_t","k_price_quick"); else add("k_price_fixed_t","k_price_fixed");
    out[out.length-1].b+=" "+F(esc?"k_pay_escrow":"k_pay_direct");
    if(on("deposit")) add("k_deposit_t","k_deposit");
    if(type==="retainer") add("k_term_t","k_term"); else add("k_delivery_t",c.deadline?"k_delivery":"k_delivery_nodate");
    if(type!=="hourly") add("k_revisions_t","k_revisions");
    if(tm.on.usage) add("k_usage_full_t","k_usage_full"); else add("k_usage_license_t","k_usage_license");
    out[out.length-1].b+=" "+F("k_paidinfull")+" "+F("k_thirdparty");
    if(on("credit")) add("k_credit_t","k_credit");
    if(on("raw")) add("k_raw_t","k_raw");
    if(on("materials")) add("k_materials_t","k_materials");
    if(on("cancel")) add("k_cancel_t",esc?"k_cancel_escrow":"k_cancel_direct");
    add("k_nodeliver_t",(type==="retainer"||!c.deadline)?"k_nodeliver_open":"k_nodeliver");   // always: what happens if nothing arrives
    add("k_dispute_t","k_dispute");                     // always: Cuvori steps in
    add("k_comm_t","k_comm");                           // always: everything in writing on Cuvori
    add("k_withdraw_t","k_withdraw");                   // always: consumer withdrawal right
    if(on("late")) add("k_late_t","k_late");
    if(on("nda")) add("k_nda_t","k_nda");
    if(on("liability")) add("k_liability_t","k_liability");
    add("k_tax_t",tm.on.vat?"k_tax_excl":"k_tax_incl"); // always, and never two contradicting tax clauses
    if(on("force")) add("k_force_t","k_force");
    if(tm.custom.trim()) out.push({t:L("k_custom_t"),b:tm.custom.trim()});
    add("k_law_t",law==="XX"?"k_law_other":"k_law");
    out[out.length-1].b+=" "+F("k_consumer");
    if(type!=="quick") add("k_independent_t","k_independent");
    add("k_entire_t","k_entire");
    return out;
  }
  // the text that was accepted, if it was frozen at acceptance; otherwise the current template text
  function ctFrozen(c){
    const d=c&&c.terms_doc; if(!d||typeof d!=="object"||!Array.isArray(d.clauses)) return null;
    const cls=d.clauses.filter(x=>x&&typeof x==="object").slice(0,60).map(x=>({t:String(x.t||"").slice(0,200),b:String(x.b||"").slice(0,20000)}));
    return cls.length?{clauses:cls,version:String(d.version||"").slice(0,40),lang:CT_LANGS.includes(d.lang)?d.lang:null}:null;
  }
  function ctDocHtml(c, names){
    const frozen=ctFrozen(c); const lang=(frozen&&frozen.lang)||ctLangOf(c), L=k=>tl(lang,k); const acceptedAt=c.accepted_at||c.funded_at||null;
    const cls=frozen?frozen.clauses:ctClauses(c,names);
    return `<div class="ct-doc"><h2>${escapeHtml(L("ct_docTitle"))}</h2>
      <div class="muted small">${escapeHtml(fill(L("ct_ref"),{id:String(c.id||"").slice(0,8),n:c.terms_version||1,lang:((frozen&&frozen.version)||c.clauses_version||"")+" "+lang.toUpperCase()}))} · ${escapeHtml(L("ct_type"))}: ${escapeHtml(L("ct_type"+ctTypeOf(c).replace(/^./,x=>x.toUpperCase())))}</div>
      <p class="ct-parties">${escapeHtml(L("ct_between"))}<br><strong>${escapeHtml(L("ct_editorParty"))}:</strong> ${escapeHtml(names.editor)}<br><strong>${escapeHtml(L("ct_clientParty"))}:</strong> ${escapeHtml(names.client)}</p>
      <h3>${escapeHtml(c.title)}</h3>${c.description?`<p style="white-space:pre-wrap">${escapeHtml(c.description)}</p>`:""}
      ${cls.map((k,i)=>`<h4>${i+1}. ${escapeHtml(k.t)}</h4><p>${escapeHtml(k.b)}</p>`).join("")}
      <p class="ct-sign ${acceptedAt?"ok":""}">${escapeHtml(acceptedAt?fill(L("ct_acceptedOn"),{d:fmtDate(acceptedAt)}):L("ct_notAccepted"))}</p>
      <p class="muted small">${escapeHtml(L("ct_notLegal"))}</p></div>`;
  }
  function ctPrint(c, names){
    let host=$("#printDoc"); if(!host){ host=document.createElement("div"); host.id="printDoc"; document.body.append(host); }
    host.innerHTML=ctDocHtml(c,names); document.body.classList.add("printing"); window.print();
    setTimeout(()=>{ document.body.classList.remove("printing"); },500);
  }
  // reads the propose / adjust form
  function ctReadForm(root, type){
    const q=s=>$(s,root); const tm=ctDefaultTerms(type); const on={};
    (CT_TOGGLES[type]||[]).forEach(k=>{ const el=q(`[data-ct-on="${k}"]`); on[k]=el?el.checked:tm.on[k]; });
    const num=(s,d)=>{ const el=q(s); return el&&el.value!==""?Number(el.value):d; };
    return { on, cancel_days:num("#ctCancelDays",tm.cancel_days), late_pct:num("#ctLatePct",tm.late_pct), pay_days:num("#ctPayDays",tm.pay_days), hours:num("#ctHours",tm.hours), cap:num("#ctCap",tm.cap), months:num("#ctMonths",tm.months), grace_days:num("#ctGraceDays",tm.grace_days), deposit_pct:num("#ctDepositPct",tm.deposit_pct), included:(q("#ctIncluded")||{}).value||"", custom:(q("#ctCustom")||{}).value||"" };
  }
  function ctFormHtml(type, c){
    const tm=ctCleanTerms(c.terms,type); const lang=ctLangOf(c); const esc=isEscrow(c);
    const unitSel=type==="hourly"?`<select id="ctUnit"><option value="hour" ${c.pricing==="hour"?"selected":""}>${t("perHour")}</option><option value="day" ${c.pricing==="day"?"selected":""}>${t("perDay")}</option></select>`:"";
    const priceLabel=type==="retainer"?t("ct_monthlyFee"):t("c_price")+" (€)";
    return `
      <div class="form-grid">
        <div style="grid-column:1/-1"><label>${t("c_title")}</label><input id="ctTitle" maxlength="200" value="${escapeHtml(c.title||"")}" placeholder="${t("c_titlePh")}"></div>
        <div style="grid-column:1/-1"><label>${t("c_scope")}</label><textarea id="ctDesc" maxlength="5000" style="min-height:80px" placeholder="${t("c_scopePh")}">${escapeHtml(c.description||"")}</textarea></div>
        <div><label>${priceLabel}</label><input id="ctPrice" type="number" min="${esc?1:0}" max="1000000" step="1" value="${escapeHtml(c.price??"")}"></div>
        ${type==="hourly"?`<div><label>${t("d_rateUnit")}</label>${unitSel}</div><div><label>${t("ct_hoursEst")}</label><input id="ctHours" type="number" min="0" max="10000" value="${tm.hours}"></div><div><label>${t("ct_hoursCap")}</label><input id="ctCap" type="number" min="0" max="10000" value="${tm.cap}"></div>`:""}
        ${type==="retainer"?`<div><label>${t("ct_months")}</label><input id="ctMonths" type="number" min="1" max="24" value="${tm.months}"></div><div style="grid-column:1/-1"><label>${t("ct_included")}</label><input id="ctIncluded" maxlength="1000" value="${escapeHtml(tm.included)}" placeholder="${t("ct_includedPh")}"></div><div><label>${t("ct_cancelDays")}</label><input id="ctCancelDays" type="number" min="3" max="365" value="${tm.cancel_days}"></div>`:`<div><label>${t("quoteDeadlineLabel")}</label><input id="ctDeadline" type="date" min="${new Date().toISOString().slice(0,10)}" value="${escapeHtml(c.deadline||"")}"></div>`}
        ${type!=="hourly"?`<div><label>${t("d_revisions")}</label><input id="ctRev" type="number" min="0" max="50" value="${c.revisions??2}"></div>`:""}
        ${esc?"":`<div><label>${t("ct_payDays")}</label><input id="ctPayDays" type="number" min="0" max="90" value="${tm.pay_days}"></div>`}
        ${type==="retainer"?"":`<div><label>${t("ct_graceDays")}</label><input id="ctGraceDays" type="number" min="3" max="60" value="${tm.grace_days}"></div>`}
        <div><label>${t("ct_country")}</label><select id="ctLaw">${CT_COUNTRIES.map(k=>`<option value="${k}" ${ctLawOf(c)===k?"selected":""}>${escapeHtml(countryName(k,state.language))}</option>`).join("")}<option value="XX" ${ctLawOf(c)==="XX"?"selected":""}>${t("ct_countryOther")}</option></select></div>
        <div><label>${t("ct_language")}</label><select id="ctLang">${CT_LANGS.map(k=>`<option value="${k}" ${lang===k?"selected":""}>${k.toUpperCase()}</option>`).join("")}</select></div>
      </div>
      <div style="margin-top:12px"><strong>${t("ct_clauses")}</strong><div class="muted small">${t("ct_clausesHint")}</div>
        <div class="ct-toggles">${ctTogglesFor(type,esc).map(k=>`<label class="ct-toggle"><input type="checkbox" data-ct-on="${k}" ${tm.on[k]?"checked":""}> <span>${t(k==="usage"?"k_usage_full_t":k==="vat"?"k_tax_t":"k_"+k+"_t")}</span>${k==="cancel"&&type!=="retainer"?` <input id="ctCancelDays" type="number" min="3" max="365" value="${tm.cancel_days}" class="ct-inline"> ${t("ct_cancelDays").toLowerCase()}`:""}${k==="late"?` <input id="ctLatePct" type="number" min="0" max="5" step="0.5" value="${tm.late_pct}" class="ct-inline"> %`:""}${k==="deposit"?` <input id="ctDepositPct" type="number" min="0" max="50" step="5" value="${tm.deposit_pct}" class="ct-inline"> %`:""}</label>`).join("")}</div>
        <div class="notice" style="margin-top:10px">${t("ct_cuvoriPromise")}</div>
        <div class="muted small" style="margin-top:6px">${t("ct_notLegal")}</div>
        <label style="margin-top:10px">${t("ct_custom")}</label><textarea id="ctCustom" maxlength="5000" style="min-height:70px" placeholder="${t("ct_customPh")}">${escapeHtml(tm.custom)}</textarea>
      </div>
      <div class="muted small" style="margin-top:10px">${esc?fill(t("es_proposeNote"),{n:ESCROW.days}):t("c_noFee")}</div>
      <button class="link-btn" id="ctPreviewBtn" type="button" style="margin-top:10px">${t("ct_preview")}</button><div id="ctPreview" class="hidden" style="margin-top:8px"></div>`;
  }
  // one modal for both "propose" and "adjust"
  function proposeContractModal(conv, key, prefill, existing){
    const other=displayOf(key); const pf=prefill||{}; const editing=!!existing;
    const c=existing?{...existing}:{ title:pf.title||"", description:pf.description||"", price:pf.price||"", pricing:"project", deadline:pf.deadline||"", revisions:2, payment_mode:ESCROW.enabled?"escrow":"direct", contract_type:"fixed", law_country:ctGuessCountry(), language:state.language, terms:{} };
    let type=ctTypeOf(c);
    openModal(editing?t("ct_adjust"):fill(t("c_proposeTitle"),{name:other}), `
      <p class="muted" style="margin-bottom:10px">${editing?t("ct_adjustDesc"):t("c_proposeDesc")}</p>
      <div class="ct-types">${CT_TYPES.map(k=>`<button type="button" class="ct-type ${type===k?"on":""}" data-ct-type="${k}" ${editing&&isEscrow(c)&&!["fixed","quick"].includes(k)?"disabled":""}><strong>${t("ct_type"+k.replace(/^./,x=>x.toUpperCase()))}</strong><span class="muted small">${t("ct_type"+k.replace(/^./,x=>x.toUpperCase())+"D")}</span></button>`).join("")}</div>
      <div id="ctForm">${ctFormHtml(type,c)}</div>
      <button class="primary" id="ctSend" style="margin-top:14px">${editing?t("ct_sendChanges"):t("c_sendProposal")}</button>`, root=>{
        const collect=()=>{ const q=s=>$(s,root); const terms=ctReadForm(root,type); const pricing=type==="hourly"?(q("#ctUnit")||{}).value||"hour":type==="retainer"?"month":"project";
          return { title:(q("#ctTitle").value||"").trim(), description:(q("#ctDesc").value||"").trim(), price:q("#ctPrice").value, pricing, deadline:(q("#ctDeadline")||{}).value||null, revisions:type==="hourly"?0:Math.min(50,Math.max(0,Math.round(+(q("#ctRev")||{}).value||0))), ctype:type, law:q("#ctLaw").value, lang:q("#ctLang").value, terms }; };
        const bind=()=>{
          $("#ctPreviewBtn",root).addEventListener("click",()=>{ const pv=$("#ctPreview",root); const f=collect(); const show=pv.classList.contains("hidden");
            pv.classList.toggle("hidden",!show); $("#ctPreviewBtn",root).textContent=t(show?"ct_hidePreview":"ct_preview");
            if(show){ const row={...c, title:f.title||"—", description:f.description, price:f.price||0, pricing:f.pricing, deadline:f.deadline, revisions:f.revisions, contract_type:type, law_country:f.law, language:f.lang, terms:f.terms, terms_version:(c.terms_version||0)+(editing?1:1), accepted_at:null, funded_at:null };
              const names=c.editor?{editor:displayOf("u:"+c.editor),client:displayOf("u:"+c.client)}:(isEditor()?{editor:displayName(),client:other}:{editor:other,client:displayName()}); pv.innerHTML=ctDocHtml(row,names); } });
        };
        bind();
        $$("[data-ct-type]",root).forEach(b=>b.addEventListener("click",()=>{ if(b.disabled) return; const f=collect(); type=b.dataset.ctType; $$("[data-ct-type]",root).forEach(x=>x.classList.toggle("on",x===b));
          if(!editing) c.payment_mode=(ESCROW.enabled&&["fixed","quick"].includes(type))?"escrow":"direct";
          Object.assign(c,{ title:f.title, description:f.description, price:f.price, deadline:f.deadline, revisions:f.revisions, law_country:f.law, language:f.lang, terms:{...ctCleanTerms(f.terms,type), on:{...ctDefaultTerms(type).on, ...f.terms.on}} , pricing:type==="hourly"?"hour":type==="retainer"?"month":"project" });
          $("#ctForm",root).innerHTML=ctFormHtml(type,c); bind(); }));
        $("#ctSend",root).addEventListener("click",async()=>{
          const f=collect();
          if(!f.title||f.price===""||(type==="retainer"&&!f.terms.included.trim())){ toast(t("a_fillAll")); return; }
          if(type==="hourly"&&f.terms.cap<f.terms.hours){ toast(t("ct_capTooLow")); return; }
          const btn=$("#ctSend",root); btn.disabled=true;
          try{
            if(editing){
              const { data, error } = await sb.rpc("adjust_contract",{ cid:c.id, title:f.title, description:f.description, price:Number(f.price), pricing:f.pricing, deadline:f.deadline, revisions:f.revisions, ctype:f.ctype, law:f.law, lang:f.lang, terms:f.terms });
              if(error||data!=="ok"){ toast(errText(error,data)); return; }
              closeModal(); toast(t("ct_changed")); contractModal(c.id); refreshContractsPage();
            } else {
              const mode=ESCROW.enabled&&f.pricing==="project"?"escrow":"direct";
              const { error } = await sb.rpc("propose_contract",{ conv, title:f.title, description:f.description, price:Number(f.price), pricing:f.pricing, deadline:f.deadline, revisions:f.revisions, mode, ctype:f.ctype, law:f.law, lang:f.lang, terms:f.terms });
              if(error){ toast(errText(error)); console.error(error); return; }
              closeModal(); toast(t("c_sent")); refreshContractsPage();
            }
          } finally { btn.disabled=false; }
        });
      }, "wide");
  }

  // freeze the wording at acceptance so later template edits can never rewrite an accepted contract
  async function ctFreezeDoc(c, names){
    try{
      if(!REAL||!c||c.terms_doc) return;
      const doc={ clauses:ctClauses(c,names), version:c.clauses_version||"", lang:ctLangOf(c), at:new Date().toISOString() };
      await sb.rpc("store_contract_doc",{ cid:c.id, doc });
    }catch(e){ console.error("freeze", e && e.message); }
  }
