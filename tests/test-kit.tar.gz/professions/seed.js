// The single source of truth for professions, filters and which filters each profession uses.
// Stable keys are identity; labels are data. tools/gen-professions.js turns this into SQL and into
// the browser mock, so the database, the page and the tests never disagree.
// Labels: {en,de,ru,lt,es,pl,uk}. Missing languages fall back to English at runtime.
const catLabels = require('/tmp/claude-0/cat-labels.json');
const L = (en, more) => Object.assign({ en }, more || {});
const cat = k => catLabels[k];

// ---------- professions ----------
const professions = [
  { slug:'video-editor',   group:'video-media',  sort:10, active:true,  invite_only:true, units:['hour','project','day'],     portfolio:'video',
    labels:L('Video editor',{de:'Videoeditor',ru:'Видеомонтажёр',lt:'Editorius',es:'Editor de vídeo',pl:'Montażysta wideo',uk:'Відеомонтажер'}),
    synonyms:['editor','video editing','montage','editorius','montažas','монтаж','schnitt','edición'] },
  { slug:'videographer',   group:'video-media',  sort:20, active:true,  invite_only:true, units:['hour','day','project'],     portfolio:'video',
    labels:L('Videographer',{de:'Videograf',ru:'Видеограф',lt:'Videografas',es:'Videógrafo',pl:'Wideograf',uk:'Відеограф'}),
    synonyms:['camera operator','filming','filmavimas','съёмка','filmen'] },
  { slug:'photographer',   group:'video-media',  sort:30, active:true,  invite_only:true, units:['session','hour','day','project'], portfolio:'image',
    labels:L('Photographer',{de:'Fotograf',ru:'Фотограф',lt:'Fotografas',es:'Fotógrafo',pl:'Fotograf',uk:'Фотограф'}),
    synonyms:['photo','photography','fotografas','фото','foto'] },
  { slug:'motion-designer',group:'video-media',  sort:40, active:false, invite_only:true, units:['hour','project'],           portfolio:'video',
    labels:L('Motion designer',{de:'Motion Designer',ru:'Моушн-дизайнер',lt:'Judesio dizaineris',es:'Diseñador de motion',pl:'Motion designer',uk:'Моушн-дизайнер'}),
    synonyms:['motion graphics','animation','animator'] },
  { slug:'copywriter',     group:'writing',      sort:50, active:false, invite_only:true, units:['word','hour','project'],    portfolio:'link',
    labels:L('Copywriter',{de:'Texter',ru:'Копирайтер',lt:'Tekstų kūrėjas',es:'Redactor publicitario',pl:'Copywriter',uk:'Копірайтер'}),
    synonyms:['writer','copy','texts','tekstai','тексты'] },
  { slug:'web-developer',  group:'development',  sort:60, active:false, invite_only:true, units:['hour','project'],           portfolio:'link',
    labels:L('Web developer',{de:'Webentwickler',ru:'Веб-разработчик',lt:'Interneto programuotojas',es:'Desarrollador web',pl:'Programista stron',uk:'Веб-розробник'}),
    synonyms:['developer','programmer','programuotojas','разработчик','entwickler','react developer'] },
];

const groups = {
  'video-media': L('Video & media',{de:'Video & Medien',ru:'Видео и медиа',lt:'Vaizdas ir medija',es:'Vídeo y medios',pl:'Wideo i media',uk:'Відео та медіа'}),
  'writing':     L('Writing & content',{de:'Text & Content',ru:'Тексты и контент',lt:'Tekstai ir turinys',es:'Redacción y contenido',pl:'Teksty i treści',uk:'Тексти та контент'}),
  'development': L('Development & technology',{de:'Entwicklung & Technik',ru:'Разработка и технологии',lt:'Programavimas ir technologijos',es:'Desarrollo y tecnología',pl:'Programowanie i technologia',uk:'Розробка та технології'}),
};

// ---------- filters ----------
// kind: price | languages | location | availability | multi | single | bool | range | tags
// match: for multi — 'any' (client picks several, a professional needs one) or 'all'
const opt = (key, labels) => ({ key, labels });
const software = ['Premiere Pro','DaVinci Resolve','Final Cut Pro','After Effects','CapCut','Blender','Cinema 4D','Photoshop','Lightroom','Illustrator','Audition','Pro Tools','Logic Pro','Nuke','Unreal Engine','Figma','Canva']
  .map(n => opt(n.toLowerCase().replace(/[^a-z0-9]+/g,'_'), L(n)));   // proper nouns: same in every language
const videoSkills = [
  ['motion_graphics','Motion graphics'],['color_grading','Color grading'],['sound_design','Sound design'],['subtitles','Subtitles & captions'],
  ['thumbnails','Thumbnails'],['vfx','VFX & compositing'],['green_screen','Green screen'],['multicam','Multicam'],['drone','Drone footage'],
  ['storytelling','Storytelling & scripting'],['talking_head','Talking-head editing'],['short_hooks','Short-form hooks'],['three_d','3D'],
  ['ai_tools','AI tools'],['retouching','Photo retouching'],['live_streaming','Live streaming']].map(([k,en]) => opt(k, L(en)));
const langNames = ['English','Lithuanian','German','Russian','Ukrainian','Polish','Spanish','French','Italian','Portuguese','Dutch','Latvian','Estonian','Swedish','Norwegian','Danish','Finnish','Czech','Turkish','Arabic','Hindi','Chinese','Japanese','Korean']
  .map(n => opt(n, L(n)));   // the key is the English name: that is what editor_profiles.languages already stores

const filters = [
  // shared
  { key:'price',        kind:'price',        labels:L('Price',{de:'Preis',ru:'Цена',lt:'Kaina',es:'Precio',pl:'Cena',uk:'Ціна'}) },
  { key:'languages',    kind:'languages',    match:'all', options:langNames, labels:L('Languages',{de:'Sprachen',ru:'Языки',lt:'Kalbos',es:'Idiomas',pl:'Języki',uk:'Мови'}) },
  { key:'location',     kind:'location',     labels:L('Location',{de:'Standort',ru:'Местоположение',lt:'Vieta',es:'Ubicación',pl:'Lokalizacja',uk:'Місце'}) },
  { key:'availability', kind:'availability', labels:L('Availability',{de:'Verfügbarkeit',ru:'Доступность',lt:'Užimtumas',es:'Disponibilidad',pl:'Dostępność',uk:'Доступність'}) },
  { key:'remote',       kind:'bool',         labels:L('Works remotely',{de:'Arbeitet remote',ru:'Работает удалённо',lt:'Dirba nuotoliniu būdu',es:'Trabaja en remoto',pl:'Pracuje zdalnie',uk:'Працює віддалено'}) },
  { key:'skills',       kind:'tags',         labels:L('Skills',{de:'Fähigkeiten',ru:'Навыки',lt:'Įgūdžiai',es:'Habilidades',pl:'Umiejętności',uk:'Навички'}) },
  // video & media
  { key:'video_specialty', kind:'multi', match:'any', labels:L('Specialisation',{de:'Spezialisierung',ru:'Специализация',lt:'Specializacija',es:'Especialización',pl:'Specjalizacja',uk:'Спеціалізація'}),
    options:['catCommercial','catYoutubeLong','catShorts','catDocumentary','catPodcasts','catMusic','catWedding','catCorporate','catRealEstate','catGaming','catEducation','catMotion','catColor','catTravel','catOther'].map(k=>opt(k,cat(k))) },
  { key:'software',     kind:'multi', match:'any', options:software, labels:L('Software',{de:'Software',ru:'Программы',lt:'Programos',es:'Software',pl:'Programy',uk:'Програми'}) },
  { key:'video_skills', kind:'multi', match:'any', options:videoSkills, labels:L('Editing skills',{de:'Schnitt-Fähigkeiten',ru:'Навыки монтажа',lt:'Montažo įgūdžiai',es:'Habilidades de edición',pl:'Umiejętności montażu',uk:'Навички монтажу'}) },
  { key:'turnaround_days', kind:'range', min:1, max:60, unit:'days', labels:L('Turnaround',{de:'Bearbeitungszeit',ru:'Срок выполнения',lt:'Atlikimo laikas',es:'Plazo de entrega',pl:'Czas realizacji',uk:'Термін виконання'}) },
  { key:'shoot_place',  kind:'single', labels:L('Where they shoot',{de:'Wo gedreht wird',ru:'Где снимает',lt:'Kur filmuoja / fotografuoja',es:'Dónde trabaja',pl:'Gdzie pracuje',uk:'Де знімає'}),
    options:[opt('studio',L('Studio')),opt('on_location',L('On location',{de:'Vor Ort',ru:'На выезде',lt:'Vietoje',es:'En exteriores',pl:'W plenerze',uk:'На виїзді'})),opt('both',L('Studio and on location',{de:'Studio und vor Ort',ru:'Студия и выезд',lt:'Studija ir vietoje',es:'Estudio y exteriores',pl:'Studio i plener',uk:'Студія та виїзд'}))] },
  { key:'travel_km',    kind:'range', min:0, max:1000, unit:'km', labels:L('Travel radius',{de:'Anfahrtsradius',ru:'Радиус выезда',lt:'Atvyksta iki',es:'Radio de desplazamiento',pl:'Zasięg dojazdu',uk:'Радіус виїзду'}) },
  { key:'equipment',    kind:'tags', labels:L('Equipment',{de:'Ausrüstung',ru:'Оборудование',lt:'Įranga',es:'Equipo',pl:'Sprzęt',uk:'Обладнання'}) },
  // photography
  { key:'shoot_type',   kind:'multi', match:'any', labels:L('Shoot type',{de:'Art des Shootings',ru:'Тип съёмки',lt:'Fotosesijos tipas',es:'Tipo de sesión',pl:'Rodzaj sesji',uk:'Тип зйомки'}),
    options:[['portrait','Portrait'],['product','Product'],['wedding','Wedding'],['event','Event'],['fashion','Fashion'],['real_estate','Real estate'],['food','Food'],['sports','Sports'],['travel','Travel'],['newborn','Newborn & family'],['corporate','Corporate & headshots'],['other','Other']].map(([k,en])=>opt(k,L(en))) },
  { key:'editing_included', kind:'bool', labels:L('Editing included',{de:'Bearbeitung inklusive',ru:'Обработка включена',lt:'Redagavimas įskaičiuotas',es:'Edición incluida',pl:'Obróbka w cenie',uk:'Обробка включена'}) },
  { key:'delivery_days', kind:'range', min:1, max:60, unit:'days', labels:L('Delivery time',{de:'Lieferzeit',ru:'Срок отдачи',lt:'Pristatymo laikas',es:'Tiempo de entrega',pl:'Czas dostarczenia',uk:'Термін віддачі'}) },
  // motion design
  { key:'motion_type',  kind:'multi', match:'any', labels:L('Type of work',{de:'Art der Arbeit',ru:'Тип работ',lt:'Darbų tipas',es:'Tipo de trabajo',pl:'Rodzaj pracy',uk:'Тип робіт'}),
    options:[['explainer','Explainer videos'],['logo_animation','Logo animation'],['titles','Titles & lower thirds'],['ui_animation','UI animation'],['three_d','3D'],['character','Character animation'],['social','Social media motion']].map(([k,en])=>opt(k,L(en))) },
  // writing
  { key:'writing_type', kind:'multi', match:'any', labels:L('Writing type',{de:'Textart',ru:'Тип текстов',lt:'Tekstų tipas',es:'Tipo de texto',pl:'Rodzaj tekstów',uk:'Тип текстів'}),
    options:[['advertising','Advertising'],['email','Email'],['landing_pages','Landing pages'],['seo','SEO articles'],['blog','Blog writing'],['script','Scriptwriting'],['technical','Technical writing'],['social','Social media']].map(([k,en])=>opt(k,L(en))) },
  { key:'industries',   kind:'tags', labels:L('Industry experience',{de:'Branchenerfahrung',ru:'Опыт в отраслях',lt:'Patirtis srityse',es:'Experiencia por sector',pl:'Doświadczenie branżowe',uk:'Галузевий досвід'}) },
  // development
  { key:'dev_area',     kind:'multi', match:'any', labels:L('Area',{de:'Bereich',ru:'Направление',lt:'Sritis',es:'Área',pl:'Obszar',uk:'Напрям'}),
    options:[['frontend','Frontend'],['backend','Backend'],['fullstack','Full-stack'],['mobile','Mobile']].map(([k,en])=>opt(k,L(en))) },
  { key:'framework',    kind:'multi', match:'any', labels:L('Frameworks',{de:'Frameworks',ru:'Фреймворки',lt:'Karkasai',es:'Frameworks',pl:'Frameworki',uk:'Фреймворки'}),
    options:['React','Vue','Angular','Next.js','Svelte','Node.js','Django','Laravel','Rails','WordPress','Shopify'].map(n=>opt(n.toLowerCase().replace(/[^a-z0-9]+/g,'_'),L(n))) },
  { key:'prog_lang',    kind:'multi', match:'any', labels:L('Programming languages',{de:'Programmiersprachen',ru:'Языки программирования',lt:'Programavimo kalbos',es:'Lenguajes de programación',pl:'Języki programowania',uk:'Мови програмування'}),
    options:['JavaScript','TypeScript','Python','PHP','Ruby','Go','Java','C#','Swift','Kotlin'].map(n=>opt(n.toLowerCase().replace(/[^a-z0-9]+/g,'_'),L(n))) },
  { key:'work_mode',    kind:'single', labels:L('Availability type',{de:'Art der Verfügbarkeit',ru:'Формат занятости',lt:'Užimtumo forma',es:'Tipo de disponibilidad',pl:'Forma dostępności',uk:'Формат зайнятості'}),
    options:[opt('full_time',L('Full-time',{de:'Vollzeit',ru:'Полная занятость',lt:'Visą darbo dieną',es:'Jornada completa',pl:'Pełny etat',uk:'Повна зайнятість'})),opt('part_time',L('Part-time',{de:'Teilzeit',ru:'Частичная занятость',lt:'Ne visą darbo dieną',es:'Media jornada',pl:'Część etatu',uk:'Часткова зайнятість'})),opt('project',L('Project basis',{de:'Projektbasis',ru:'Проектно',lt:'Pagal projektus',es:'Por proyecto',pl:'Projektowo',uk:'Проєктно'}))] },
];

// ---------- which filters each profession uses, in order; primary = shown in the chip row ----------
const P = (key, primary, profile=true) => ({ key, primary, profile });
const professionFilters = {
  'video-editor':   [P('price',true),P('video_specialty',true),P('software',true),P('video_skills',false),P('turnaround_days',false),P('languages',false),P('location',false),P('availability',true),P('remote',false),P('skills',false)],
  'videographer':   [P('price',true),P('video_specialty',true),P('shoot_place',false),P('travel_km',false),P('equipment',false),P('software',false),P('video_skills',false),P('turnaround_days',false),P('languages',false),P('location',true),P('availability',true),P('skills',false)],
  'photographer':   [P('price',true),P('shoot_type',true),P('shoot_place',false),P('travel_km',false),P('editing_included',true),P('delivery_days',false),P('equipment',false),P('languages',false),P('location',true),P('availability',true),P('skills',false)],
  'motion-designer':[P('price',true),P('motion_type',true),P('software',true),P('turnaround_days',false),P('languages',false),P('location',false),P('availability',true),P('remote',false),P('skills',false)],
  'copywriter':     [P('price',true),P('writing_type',true),P('languages',true),P('industries',false),P('turnaround_days',false),P('location',false),P('availability',true),P('remote',false),P('skills',false)],
  'web-developer':  [P('price',true),P('dev_area',true),P('framework',true),P('prog_lang',false),P('work_mode',false),P('remote',true),P('languages',false),P('location',false),P('availability',true),P('skills',false)],
};
// filters every profession shares, shown when no profession is chosen
const sharedFilters = ['price','languages','location','availability'];

// price units and their labels
const units = {
  hour:    L('per hour',{de:'pro Stunde',ru:'в час',lt:'už valandą',es:'por hora',pl:'za godzinę',uk:'за годину'}),
  day:     L('per day',{de:'pro Tag',ru:'в день',lt:'už dieną',es:'por día',pl:'za dzień',uk:'за день'}),
  project: L('per project',{de:'pro Projekt',ru:'за проект',lt:'už projektą',es:'por proyecto',pl:'za projekt',uk:'за проєкт'}),
  session: L('per session',{de:'pro Shooting',ru:'за съёмку',lt:'už fotosesiją',es:'por sesión',pl:'za sesję',uk:'за сесію'}),
  word:    L('per word',{de:'pro Wort',ru:'за слово',lt:'už žodį',es:'por palabra',pl:'za słowo',uk:'за слово'}),
};

module.exports = { professions, groups, filters, professionFilters, sharedFilters, units };
