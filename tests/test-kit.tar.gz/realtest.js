const { chromium } = require('playwright'); const fs=require('fs');
const log=[]; const ok=(c,m)=>log.push((c?'PASS ':'FAIL ')+m);
const mock=fs.readFileSync(__dirname+'/mock-supabase.js','utf8');
(async () => {
  const b = await chromium.launch(); const ctx=await b.newContext({viewport:{width:1400,height:900}});
  const errs=[];
  const url='file://'+process.cwd()+'/index.html';
  await ctx.addInitScript(mock);
  await ctx.route('**/supabase.min.js', r=>r.fulfill({status:200,body:'/* mocked */',contentType:'application/javascript'}));
  const p = await ctx.newPage(); p.on('pageerror',e=>errs.push('P1 '+e.message));
  try {
  await p.goto(url); await p.waitForTimeout(500);
  ok(await p.locator('.profile-card:not(.real-card)').first().isVisible(),'no real editors yet: example cards shown');
  ok(await p.locator('#exampleNote').count()===1,'example note shown');
  ok(await p.locator('#jobsEmptyReal').count()===0 || true,'jobs page loads');
  // --- editor signs up, redeems invite, creates public profile with project ---
  await p.goto(url+'#create-account'); await p.waitForTimeout(300);
  await p.fill('#suName','Maya'); await p.fill('#suEmail','maya@test.com'); await p.fill('#suPass','password123'); await p.check('#suAgree'); await p.click('[data-auth-signup]'); await p.waitForTimeout(800);
  await p.goto(url+'#join-editor'); await p.waitForTimeout(300); await p.fill('#inviteCode','CUV-2026-EDIT'); await p.click('#inviteBtn'); await p.waitForTimeout(1800);
  ok(await p.locator('#page-profile').evaluate(e=>e.classList.contains('active')),'invite accepted -> jumps to own profile');
  ok(await p.locator('#epSave').count()===1,'edit-profile form opens automatically');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML=''); await p.waitForTimeout(300);
  await p.goto(url+'#account'); await p.waitForTimeout(400);
  ok(await p.locator('#myProfileBtn').isVisible(),'editor sees My editor profile');
  await p.click('#myProfileBtn'); await p.waitForTimeout(800);
  ok(await p.locator('#page-profile').evaluate(e=>e.classList.contains('active')),'own profile page opens (draft)');
  ok(await p.locator('[data-edit-profile]').count()>=1,'Edit profile button for owner');
  ok((await p.textContent('#page-profile')).includes('Set up your editor profile'),'setup steps shown on draft profile');
  await p.locator('[data-edit-profile]').first().click(); await p.waitForTimeout(400);
  await p.fill('#epName','Maya Klein'); await p.fill('#epCity','Munich'); await p.fill('#epCountry','Germany'); await p.fill('#epLangs','English, German'); await p.fill('#epTools','DaVinci Resolve, Premiere Pro');
  await p.click('.ep-spec[data-c="catCommercial"]'); await p.fill('#epBio','Story-focused editor.'); await p.fill('#epRate','35'); await p.check('#epPublic');
  await p.click('#epSave'); await p.waitForTimeout(1000);
  ok((await p.textContent('#page-profile')).includes('Maya Klein') && (await p.textContent('#page-profile')).includes('Munich, Germany'),'profile saved and re-rendered from DB');
  ok(await p.locator('#page-profile .notice').count()===0,'no draft notice after publishing');
  // add project via link -> DB
  await p.click('[data-pf-add]'); await p.waitForTimeout(300);
  await p.fill('#npUrl','https://www.youtube.com/watch?v=dQw4w9WgXcQ'); await p.fill('#npTitle','Brand film'); await p.fill('#npTags','wedding'); await p.click('#npSave'); await p.waitForTimeout(800);
  const dbp=await p.evaluate(()=>window.__mockdb.projects.length); ok(dbp===1,`project saved to DB (${dbp})`);
  // training & credentials: course by Casey Faris linked to the project; chips for programs/skills/languages
  await p.locator('[data-edit-profile]').first().click(); await p.waitForTimeout(400);
  ok(await p.locator('.ep-lang.selected').count()===2 && await p.locator('.ep-skill.selected').count()===2,'saved languages/programs shown as selected chips');
  await p.click('.ep-skill[data-s="Color grading"]'); await p.click('.ep-lang[data-s="Lithuanian"]');
  await p.click('#epAddCred'); await p.waitForTimeout(200);
  await p.selectOption('.cred-row .cr-kind','course'); await p.fill('.cred-row .cr-title','Resolve Masterclass'); await p.fill('.cred-row .cr-by','Casey Faris'); await p.fill('.cred-row .cr-year','2025'); await p.fill('.cred-row .cr-link','caseyfaris.com/resolve');
  await p.locator('.cred-row .cr-proj').selectOption({index:1});
  await p.click('#epSave'); await p.waitForTimeout(1000);
  ok(await p.evaluate(()=>{ const e=window.__mockdb.editor_profiles[0]; return e.credentials.length===1 && e.credentials[0].by==='Casey Faris' && e.credentials[0].link==='https://caseyfaris.com/resolve' && !!e.credentials[0].project_id && e.tools.includes('Color grading') && e.languages.includes('Lithuanian'); }),'credentials + chip picks saved to DB');
  await p.click('.ep-tab[data-tab="about"]'); await p.waitForTimeout(200);
  ok((await p.textContent('[data-pane="about"]')).includes('Casey Faris') && (await p.textContent('[data-pane="about"]')).includes('Brand film'),'about tab shows training with linked project');
  // browse shows real card, hides demo
  await p.goto(url+'#home'); await p.waitForTimeout(900);
  ok(await p.locator('.real-card').count()===1,'real editor card on browse');
  ok(await p.locator('.profile-card:not(.real-card)').first().isHidden(),'example cards hidden once a real editor exists');
  ok((await p.textContent('.real-card .price')).includes('€35'),'price-first card shows €35');
  ok(await p.locator('.real-card .card-gallery .car-item').count()===1,'card gallery has the 1 real video');
  ok((await p.textContent('.real-card')).includes('Casey Faris'),'card shows training line');
  await p.hover('.real-card .car-item'); await p.waitForTimeout(700);
  ok(await p.locator('.real-card .hover-embed').count()===1 && (await p.getAttribute('.real-card .hover-embed','src')).includes('autoplay=1&mute=1'),'hovering a card video starts a muted YouTube preview');
  await p.mouse.move(5,5); await p.waitForTimeout(200);
  ok(await p.locator('.real-card .hover-embed').count()===0,'preview stops when the mouse leaves');
  // ---------- is this editor taking work? ----------
  ok((await p.textContent('.real-card .status')).includes('Available'),'a new editor shows as available');
  ok(await p.getAttribute('.real-card','data-av')==='open','card carries the status for filtering');
  // the editor says they are busy until a date
  await p.click('.real-card .view-profile'); await p.waitForTimeout(700);
  await p.locator('[data-edit-profile]').first().click(); await p.waitForTimeout(400);
  ok(await p.locator('#avFreeWrap').evaluate(e=>e.classList.contains('hidden')),'the date field is hidden until "busy" is chosen');
  await p.click('.av-seg [data-av="busy"]'); await p.waitForTimeout(200);
  ok(!await p.locator('#avFreeWrap').evaluate(e=>e.classList.contains('hidden')),'choosing busy asks when they are free again');
  const soon = new Date(Date.now()+10*86400000).toISOString().slice(0,10);
  await p.fill('#avFreeFrom', soon); await p.click('#epSave'); await p.waitForTimeout(1000);
  ok(await p.evaluate(()=>{const e=window.__mockdb.editor_profiles[0]; return e.availability==='busy' && !!e.free_from;}),'status saved to the database');
  await p.goto(url+'#home'); await p.waitForTimeout(800);
  ok(await p.getAttribute('.real-card','data-av')==='soon','busy with a near date reads as "free soon"');
  ok((await p.textContent('.real-card .status')).includes('Free from'),'card tells clients when they are free again');
  // the Available-now filter hides them
  await p.click('.chip[data-filter="av:open"]'); await p.waitForTimeout(500);
  ok(await p.locator('.real-card').first().isHidden(),'"Available now" filter hides a busy editor');
  await p.click('.chip[data-filter="av:open"]'); await p.waitForTimeout(400);
  ok(await p.locator('.real-card').first().isVisible(),'turning the filter off shows them again');
  // signing back in is what makes the app re-read the editor rows
  const reMaya = async () => {
    await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
    await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signin"]'); await p.waitForTimeout(200);
    await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1300);
    await p.goto(url+'#home'); await p.waitForTimeout(900);
  };
  // a date that has already passed means free again
  await p.evaluate(()=>{ const e=window.__mockdb.editor_profiles[0]; e.free_from=new Date(Date.now()-86400000).toISOString().slice(0,10); });
  await reMaya();
  ok(await p.getAttribute('.real-card','data-av')==='open','a busy date in the past counts as available again');
  // a status nobody has touched for months stops claiming anything
  await p.evaluate(()=>{ const e=window.__mockdb.editor_profiles[0]; e.availability='open'; e.free_from=null;
    e.availability_set_at=new Date(Date.now()-200*86400000).toISOString();
    e.last_active_on=new Date(Date.now()-200*86400000).toISOString().slice(0,10); });
  await reMaya();
  ok(await p.getAttribute('.real-card','data-av')==='stale','a forgotten status stops showing as available');
  ok(!(await p.textContent('.real-card .status')).includes('Available'),'a forgotten profile no longer claims to be available');
  ok((await p.textContent('.real-card .status')).toLowerCase().includes('last active'),'it shows when they were last active instead');
  ok(!await p.locator('#avNudge').evaluate(e=>e.classList.contains('hidden')),'the editor is nudged to update it');
  await p.click('#avNudgeGo'); await p.waitForTimeout(500);
  await p.click('.av-seg [data-av="open"]'); await p.click('#epSave'); await p.waitForTimeout(1000);
  await p.goto(url+'#home'); await p.waitForTimeout(800);
  ok(await p.getAttribute('.real-card','data-av')==='open','updating it makes the editor available again');

  await p.click('#allFiltersBtn'); await p.waitForTimeout(300);
  ok(await p.locator('.modal-filter[data-filter="YouTube long-form"]').count()===1 && await p.locator('.modal-filter[data-filter="price:30-60"]').count()===1,'all-filters has new categories, role and price');
  await p.click('.modal-filter[data-filter="Commercial"]'); await p.click('.modal-filter[data-filter="Editor"]'); await p.click('.modal-filter[data-filter="price:30-60"]'); await p.click('#applyFilters'); await p.waitForTimeout(300);
  ok(await p.locator('.real-card').first().isVisible(),'real card matches Commercial + Editor + €30–60');
  await p.click('#allFiltersBtn'); await p.waitForTimeout(300); await p.click('.modal-filter[data-filter="price:30-60"]'); await p.click('.modal-filter[data-filter="price:60-"]'); await p.click('#applyFilters'); await p.waitForTimeout(300);
  ok(await p.locator('.real-card').first().isHidden(),'price filter €60+ hides the €35 card');
  await p.click('#allFiltersBtn'); await p.waitForTimeout(300); await p.$$eval('.modal-filter.selected',els=>els.forEach(e=>e.click())); await p.click('#applyFilters'); await p.waitForTimeout(300);
  ok(await p.locator('.real-card').first().isVisible(),'filters cleared');
  // post a job as editor? (any account can) — post as this user
  await p.goto(url+'#post-job'); await p.waitForTimeout(300);
  await p.fill('#jobTitle','Need a colour grade'); await p.fill('#jobDesc','Short brand film'); await p.fill('#jobBudget','€300'); await p.click('#publishJob'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.jobs.length)===1,'job saved to DB');
  ok(await p.locator('.real-job').count()===1,'real job listed');
  ok(await p.locator('.job[data-job]:not(.real-job)').first().isHidden(),'demo jobs hidden');
  await p.click('#signOutBtn').catch(()=>{}); await p.goto(url+'#account'); await p.waitForTimeout(300); if(await p.locator('#signOutBtn').isVisible()){ await p.click('#signOutBtn'); await p.waitForTimeout(400); }
  // --- client signs up, messages editor ---
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signup"]'); await p.waitForTimeout(200);
  await p.fill('#suName','Jonas'); await p.fill('#suEmail','jonas@test.com'); await p.fill('#suPass','password123'); await p.check('#suAgree'); await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.goto(url+'#home'); await p.waitForTimeout(600);
  await p.click('.real-card .message-person'); await p.waitForTimeout(800);
  ok(await p.locator('.chat-window').count()===1,'client opens chat with real editor');
  ok((await p.textContent('.chat-window .chat-head')).includes('Maya Klein'),'chat header shows editor name');
  ok(await p.locator('.chat-window .send-report').count()===0,'client has no Send update button');
  await p.fill('.chat-window input','Hi Maya, can you grade my film?'); await p.keyboard.press('Enter'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>window.__mockdb.messages.length)===1,'message saved to DB');
  ok(await p.locator('.chat-window .bubble.mine').count()===1,'message shown once (no duplicate from realtime)');
  ok(await p.locator('#contactList .contact').count()===1,'sidebar lists the conversation');
  // --- editor logs back in, sees message, sends progress update ---
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1000);
  ok(await p.locator('#contactList .contact').count()===1,'editor sees conversation with Jonas');
  await p.click('#notificationsBtn'); await p.waitForTimeout(600);
  ok((await p.textContent('#modalRoot')).includes('New message from Jonas'),'notification for new message');
  await p.click('#modalRoot [data-notif-target]'); await p.waitForTimeout(800);
  ok((await p.textContent('.chat-window .chat-messages')).includes('grade my film'),'editor sees client message');
  ok(await p.locator('.chat-window .send-report').count()===1,'editor has Send update button');
  await p.click('.chat-window .send-report'); await p.waitForTimeout(400);
  await p.fill('#rText','First cut ready'); await p.fill('#rLink','https://youtu.be/dQw4w9WgXcQ'); await p.click('#sendProgress'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.messages.filter(m=>m.kind==='report').length)===1,'progress report saved to DB');
  ok(await p.locator('.chat-window .report-card').count()===1,'report card in chat');
  ok(await p.locator('.reco-card').count()===0 && (await p.evaluate(()=>Object.keys(window.__cuv||{}).length))>=0,'no reminder right after sending');
  // client reviews and approves
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','jonas@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1000);
  await p.click('#contactList .contact'); await p.waitForTimeout(800);
  await p.click('.chat-window .report-card'); await p.waitForTimeout(600);
  ok(await p.locator('#approveVersion').count()===1,'client opens review modal');
  await p.click('#approveVersion'); await p.waitForTimeout(500);
  ok(await p.evaluate(()=>window.__mockdb.messages.find(m=>m.kind==='report').payload.status==='approved'),'approval saved to DB');
  // reminder for editor after 9 days
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.evaluate(()=>{ const m=window.__mockdb.messages.find(m=>m.kind==='report'); m.created_at=new Date(Date.now()-9*86400000).toISOString(); });
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#account'); await p.waitForTimeout(600);
  ok(await p.locator('.reco-card').count()===1,'editor gets 9-day reminder based on real messages');
  ok((await p.textContent('.reco-card')).includes('Jonas'),'reminder names the real client');
  // ---------- reviews: client reviews editor ----------
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','jonas@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1000);
  await p.goto(url+'#home'); await p.waitForTimeout(700);
  await p.click('.real-card .view-profile'); await p.waitForTimeout(600);
  await p.click('.ep-tab[data-tab="reviews"]'); await p.waitForTimeout(200);
  ok(await p.locator('[data-review]').count()===1,'client sees Leave a review button');
  await p.click('[data-review]'); await p.waitForTimeout(500);
  ok(await p.locator('#rvSave').count()===1,'review modal opens (has a conversation)');
  await p.click('.star-pick[data-star="4"]'); await p.fill('#rvText','Great colour work, fast.'); await p.click('#rvSave'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>window.__mockdb.reviews.length)===1,'review saved to DB');
  ok((await p.textContent('#page-profile')).includes('Great colour work'),'review shown on profile');
  ok((await p.textContent('#page-profile')).includes('4.0'),'profile rating 4.0');
  await p.goto(url+'#home'); await p.waitForTimeout(600);
  ok((await p.textContent('.real-card .status')).includes('4.0'),'card shows rating');
  ok(await p.locator('#adminBtn').isHidden(),'client has no admin button');
  // ---------- contracts + direct payment ----------
  await p.goto(url+'#home'); await p.waitForTimeout(600); await p.click('.real-card .message-person'); await p.waitForTimeout(900);
  ok(await p.locator('.chat-window .open-contract').count()===1,'chat has Contract button');
  await p.click('.chat-window .open-contract'); await p.waitForTimeout(400);
  ok(await p.locator('#ctSend').count()===1,'propose-contract form opens');
  ok(await p.locator('[data-ct-type]').count()===4,'four contract types offered');
  await p.click('[data-ct-type="hourly"]'); await p.waitForTimeout(150);
  ok(await p.locator('#ctHours').count()===1 && await p.locator('#ctRev').count()===0,'hourly type shows hours, hides revisions');
  await p.fill('#ctTitle','Brand film edit'); await p.fill('#ctPrice','40'); await p.fill('#ctHours','12'); await p.fill('#ctCap','20');
  await p.click('#ctPreviewBtn'); await p.waitForTimeout(150);
  ok((await p.textContent('#ctPreview')).includes('12 hour') && (await p.textContent('#ctPreview')).includes('20 hour'),'preview renders the hourly clause with the numbers');
  await p.click('[data-ct-type="retainer"]'); await p.waitForTimeout(150);
  ok(await p.locator('#ctIncluded').count()===1,'retainer type asks what is included');
  await p.click('[data-ct-type="fixed"]'); await p.waitForTimeout(150);
  ok(await p.inputValue('#ctTitle')==='Brand film edit','title kept while switching types');
  await p.fill('#ctDesc','4 min cut, 2 versions'); await p.fill('#ctPrice','300'); await p.selectOption('#ctLaw','DE'); await p.selectOption('#ctLang','lt');
  await p.check('[data-ct-on="nda"]'); await p.uncheck('[data-ct-on="credit"]'); await p.fill('#ctCustom','Music licence paid by client.');
  await p.click('#ctPreviewBtn'); await p.waitForTimeout(150);
  const pv=await p.textContent('#ctPreview');
  ok(pv.includes('Konfidencialumas') && pv.includes('Vokietija') && pv.includes('Music licence paid by client.') && !pv.includes('Portfolio'),'preview in Lithuanian: NDA on, portfolio off, German law, custom text');
  ok(!/The Editor agrees to perform|Neither side is left alone/.test(pv),'no English sentences leak into a Lithuanian contract');
  ok(/Cuvori/.test(pv) && pv.includes('ginč'),'dispute clause (Cuvori steps in) is always present');
  ok(pv.includes('atsisak'),'consumer withdrawal clause is always present');
  await p.check('[data-ct-on="deposit"]'); await p.fill('#ctDepositPct','40'); await p.waitForTimeout(100);
  await p.click('#ctPreviewBtn'); await p.click('#ctPreviewBtn'); await p.waitForTimeout(200);
  ok((await p.textContent('#ctPreview')).includes('40'),'deposit clause shows the chosen percentage');
  ok(await p.evaluate(()=>document.querySelector('#ctDepositPct').max==='50' && document.querySelector('#ctLatePct').max==='5' && document.querySelector('#ctGraceDays').min==='3'),'abuse limits in the form: deposit 50%, late fee 5%, grace 3 days');
  await p.click('#ctSend'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>window.__mockdb.contracts.length===1 && window.__mockdb.contracts[0].client!==window.__mockdb.contracts[0].editor),'contract saved with client/editor roles');
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts[0]; return c.contract_type==='fixed' && c.law_country==='DE' && c.language==='lt' && c.terms.on.nda===true && c.terms.on.credit===false && c.terms.custom==='Music licence paid by client.' && c.terms.deposit_pct===40; }),'type, law, language, deposit and clauses saved');
  ok(await p.locator('.chat-window .contract-card').count()===1,'contract card appears in chat');
  await p.click('.chat-window .contract-card'); await p.waitForTimeout(500);
  ok((await p.textContent('#modalRoot')).includes('Waiting for the other side'),'proposer sees waiting state');
  ok(await p.locator('[data-caction="accept"]').count()===0 && await p.locator('[data-caction="cancel"]').count()===1,'proposer cannot accept own proposal');
  ok(await p.locator('.ct-details').count()===1 && (await p.textContent('.ct-details')).includes('Paslaugų'),'contract modal shows the full terms in the contract language');
  ok(await p.locator('[data-caction="pdf"]').count()===0,'no PDF before acceptance');
  await p.click('[data-caction="adjust"]'); await p.waitForTimeout(400);
  ok(await p.inputValue('#ctPrice')==='300' && await p.isChecked('[data-ct-on="nda"]'),'adjust form is prefilled with the current terms');
  await p.fill('#ctPrice','320'); await p.click('#ctSend'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts[0]; return c.price==320 && c.terms_version===2 && window.__mockdb.messages.some(m=>m.kind==='contract'&&m.payload.event==='terms_changed'); }),'adjusted terms saved as version 2 with a chat event');
  ok((await p.textContent('#modalRoot')).includes('Version 2'),'modal shows version 2');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  // editor: payout details, accept
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#settings'); await p.waitForTimeout(400);
  ok(await p.locator('.snav[data-set="payout"]').isVisible(),'editor sees Payout details in settings');
  await p.click('.snav[data-set="payout"]'); await p.click('#addPayoutBtn'); await p.waitForTimeout(200);
  await p.fill('#payoutRows .po-details','LT12 3456 7890 1234 5678'); await p.fill('#payoutNote','Write the contract title as reference'); await p.click('#savePayoutBtn'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>window.__mockdb.payout_details.length===1 && window.__mockdb.payout_details[0].methods[0].type==='bank'),'payout details saved');
  await p.goto(url+'#contracts'); await p.waitForTimeout(700);
  ok(await p.locator('#contractsList .c-row').count()===1,'contracts page lists the contract');
  await p.click('#contractsList .c-row'); await p.waitForTimeout(500);
  ok(await p.locator('[data-caction="accept"]').count()===1 && await p.locator('[data-caction="adjust"]').count()===1,'editor can accept or adjust');
  await p.click('[data-caction="accept"]'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.contracts[0].status==='accepted'),'contract accepted');
  ok(await p.locator('[data-caction="adjust"]').count()===0 && await p.locator('[data-caction="pdf"]').count()===1,'after acceptance: no adjusting, PDF available');
  await p.evaluate(()=>{ window.__printed=0; window.print=()=>{ window.__printed++; }; }); await p.click('[data-caction="pdf"]'); await p.waitForTimeout(300);
  ok(await p.evaluate(()=>window.__printed===1 && document.querySelector('#printDoc .ct-doc') && document.querySelector('#printDoc .ct-sign.ok') && document.querySelector('#printDoc').textContent.includes('Vokietija')),'PDF: print document built with acceptance line');
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts[0]; return c.terms_doc && Array.isArray(c.terms_doc.clauses) && c.terms_doc.clauses.length>8 && c.terms_doc.lang==='lt'; }),'accepted wording is frozen on the contract');
  ok(await p.evaluate(async()=>{ const c=window.__mockdb.contracts[0]; const before=JSON.stringify(c.terms_doc); const r=await window.__sb.rpc('store_contract_doc',{cid:c.id,doc:{clauses:[{t:'Free work',b:'The editor works for free.'}]}}); return JSON.stringify(window.__mockdb.contracts[0].terms_doc)===before; }),'frozen wording cannot be overwritten afterwards');
  ok((await p.textContent('#modalRoot')).includes('Waiting for the client to pay'),'editor sees waiting-for-payment');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  // client: sees payout info, marks paid
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','jonas@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.click('#contractsList .c-row'); await p.waitForTimeout(600);
  ok((await p.textContent('#modalRoot')).includes('LT12 3456'),'client sees editor IBAN after acceptance');
  ok((await p.textContent('#modalRoot')).includes('Cuvori is not involved'),'direct-payment note shown');
  await p.click('[data-caction="mark_paid"]'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.contracts[0].status==='paid_marked'),'client marked as paid');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  ok(await p.evaluate(()=>window.__mockdb.messages.filter(m=>m.kind==='contract').length===4),'each step posted a contract event in chat');
  // editor: confirm + complete
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.click('#contractsList .c-row'); await p.waitForTimeout(600);
  await p.click('[data-caction="confirm_paid"]'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.contracts[0].status==='paid'),'editor confirmed payment');
  await p.click('[data-caction="complete"]'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.contracts[0].status==='completed'),'contract completed');
  ok(await p.locator('[data-caction]:not([data-caction="pdf"])').count()===0,'no more actions on a completed contract (only PDF)');
  // finishing a job asks the editor whether they are free again, and will not be waved away
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.goto(url+'#home'); await p.waitForTimeout(400);
  await p.goto(url+'#contracts'); await p.waitForTimeout(1400);
  ok(await p.locator('.modal.locked').count()===1,'finishing a job asks about availability');
  ok(await p.locator('.modal.locked .close-x').count()===0,'the question has no close button');
  await p.locator('.modal-backdrop').click({position:{x:5,y:5}}); await p.waitForTimeout(300);
  ok(await p.locator('.modal.locked').count()===1,'clicking away does not dismiss it');
  await p.click('[data-avpick="busy"]'); await p.waitForTimeout(200);
  ok(await p.locator('#avDoneFrom').isVisible(),'choosing busy asks for the date');
  await p.click('[data-avpick="closed"]'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.editor_profiles[0].availability==='closed'),'the answer is saved against the profile');
  ok(await p.locator('.modal.locked').count()===0,'answering closes the question');
  await p.goto(url+'#home'); await p.waitForTimeout(400);
  await p.goto(url+'#contracts'); await p.waitForTimeout(1400);
  ok(await p.locator('.modal.locked').count()===0,'it is not asked again for the same job');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  // ---------- escrow (Stripe) flow ----------
  const signin=async(e)=>{ await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML=''); await p.goto(url+'#account'); await p.waitForTimeout(300); if(await p.locator('#signOutBtn').isVisible()){ await p.click('#signOutBtn'); await p.waitForTimeout(400);} await p.click('#signInBtn'); await p.waitForTimeout(200); await p.fill('#siEmail',e); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200); };
  await p.evaluate(()=>{ window.__mockEscrow=true; }); await p.evaluate(()=>window.__reloadEscrow()); await p.waitForTimeout(400);
  await p.goto(url+'#settings'); await p.waitForTimeout(300); await p.click('.snav[data-set="payout"]'); await p.waitForTimeout(200);
  ok(await p.locator('#stripeBox').isVisible() && (await p.textContent('#stripeBox')).includes('Not connected'),'editor sees Stripe box: not connected');
  await p.click('#stripeConnectBtn'); await p.waitForTimeout(1200);
  ok((await p.textContent('#stripeBox')).includes('Ready to receive'),'after Stripe onboarding: ready');
  await p.goto(url+'#home'); await p.waitForTimeout(500); await p.click('#contactList .contact'); await p.waitForTimeout(800);
  await p.click('.chat-window .open-contract'); await p.waitForTimeout(400);
  ok((await p.textContent('#modalRoot')).includes('Payment is protected'),'proposal explains protected payment');
  await p.fill('#ctTitle','Reel edit'); await p.fill('#ctPrice','200'); await p.click('#ctSend'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts.at(-1); return c.payment_mode==='escrow' && c.amount_cents===20000; }),'escrow contract proposed (€200)');
  await signin('jonas@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  await p.click('[data-caction="accept"]'); await p.waitForTimeout(700);
  ok((await p.textContent('#modalRoot')).includes('Pay securely') && (await p.textContent('#modalRoot')).includes('€6.25'),'client sees Pay securely with €6.25 card fee');
  await p.click('[data-caction="pay"]'); await p.waitForTimeout(2500);
  ok(await p.evaluate(()=>window.__mockdb.contracts.at(-1).status==='funded'),'contract funded after checkout');
  ok((await p.textContent('#modalRoot')).includes('Money held by Cuvori'),'client sees money held');
  await signin('maya@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  ok(await p.locator('[data-caction="deliver"]').count()===1,'editor sees Mark as delivered');
  await p.click('[data-caction="deliver"]'); await p.waitForTimeout(300); await p.fill('#dvUrl','https://drive.test/final'); await p.fill('#dvNote','Final cut v1'); await p.click('#dvGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.contracts.at(-1).status==='delivered'),'delivered');
  ok((await p.textContent('#modalRoot')).includes('released to you automatically'),'editor sees auto-release date');
  await signin('jonas@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  ok((await p.textContent('#modalRoot')).includes('drive.test/final'),'client sees delivery link');
  await p.click('[data-caction="changes"]'); await p.waitForTimeout(300); await p.fill('#chNote','Please fix the colour in the intro'); await p.click('#chGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.contracts.at(-1).status==='funded' && window.__mockdb.messages.some(m=>m.kind==='change_request'&&m.body.includes('colour'))),'changes requested -> back to funded, note in chat');
  await signin('maya@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  await p.click('[data-caction="deliver"]'); await p.waitForTimeout(300); await p.fill('#dvUrl','https://drive.test/final-v2'); await p.click('#dvGo'); await p.waitForTimeout(800);
  ok(await p.locator('[data-caction="dispute"]').count()===1,'editor has "client isn’t responding" button');
  await p.click('[data-caction="dispute"]'); await p.waitForTimeout(300); await p.fill('#dsNote','Delivered v2 exactly as agreed, client silent for days'); await p.click('#dsGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts.at(-1); return c.status==='disputed' && c.dispute_by===c.editor; }),'editor opened dispute');
  ok((await p.textContent('#modalRoot')).includes('Cuvori is reviewing'),'dispute state shown');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.goto(url+'#account'); await p.waitForTimeout(400); await p.click('#adminBtn'); await p.waitForTimeout(600); await p.click('.admin-tab[data-atab="contracts"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Dispute by editor') && (await p.textContent('#adminBody')).includes('client silent'),'admin sees the dispute with reason');
  await p.locator('.admin-row.is-banned [data-res="split"]').click(); await p.waitForTimeout(300); await p.fill('#resPct','70'); await p.fill('#resNote','Work delivered, minor issues'); await p.click('#resGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts.at(-1); const s=window.__fakeStripe; return c.status==='completed' && c.split_editor_cents===14000 && s.transfers.at(-1).amount===14000 && s.refunds.at(-1).amount===6000; }),'admin split 70/30 executed');
  ok(await p.evaluate(()=>window.__mockdb.messages.some(m=>m.body&&m.body.startsWith('Cuvori decision'))),'decision note posted to chat');
  // ---------- bad actors ----------
  await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Nobody on the list'),'bad actors list empty after a split');
  await p.click('.admin-tab[data-atab="users"]'); await p.waitForTimeout(600);
  await p.locator('.admin-row').filter({hasText:'jonas@test.com'}).locator('[data-aflag]').click(); await p.waitForTimeout(300);
  await p.selectOption('#flKind','scam'); await p.fill('#flReason','Tried to pay outside Cuvori'); await p.click('#flGo'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.user_flags.length===1 && window.__mockdb.user_flags[0].kind==='scam'),'manual flag saved');
  ok((await p.textContent('#adminBody')).includes('1 flag'),'users list shows flag count');
  await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Jonas') && (await p.textContent('#adminBody')).includes('Tried to pay outside'),'bad actors list shows Jonas with reason');
  await p.click('[data-unflag]'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>window.__mockdb.user_flags.length===0) && (await p.textContent('#adminBody')).includes('Nobody on the list'),'flag removed');
  // ---------- identifiers: returning bad actor is recognised ----------
  // flag Jonas as scam, then a "new" account (Tomas) that pays out to Jonas's PayPal gets auto-matched
  await p.click('.admin-tab[data-atab="users"]'); await p.waitForTimeout(500);
  await p.locator('.admin-row').filter({hasText:'jonas@test.com'}).locator('[data-aflag]').click(); await p.waitForTimeout(300);
  await p.selectOption('#flKind','scam'); await p.fill('#flReason','Chargeback after delivery'); await p.click('#flGo'); await p.waitForTimeout(600);
  await p.evaluate(()=>{ const j=window.__mockdb.profiles.find(x=>x.email==='jonas@test.com'); window.__recId(j.id,'paypal','jonas.pay@paypal.com','paypal ••.com'); });
  await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('On record:') && (await p.textContent('#adminBody')).includes('E-mail: jonas@test.com'),'bad actor row shows identifiers on record');
  await signin('jonas@test.com'); await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.evaluate(()=>{ window.__savedReviews=JSON.parse(JSON.stringify(window.__mockdb.reviews)); });
  // Jonas deletes his own account -> fingerprints kept as ghost
  await p.goto(url+'#settings'); await p.waitForTimeout(400); await p.click('#deleteAccountBtn'); await p.waitForTimeout(300); await p.fill('#dzWord','DELETE'); await p.click('#dzGo'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>window.__mockdb.deleted_user_identifiers.length>=2),'identifiers kept after a flagged user deletes the account');
  // new editor account using the same PayPal for payouts
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signup"]'); await p.fill('#suName','Tomas'); await p.fill('#suEmail','tomas@test.com'); await p.fill('#suPass','password123'); await p.check('#suAgree'); await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.evaluate(()=>{ const me=window.__mockdb.profiles.find(x=>x.email==='tomas@test.com'); me.role='editor'; });
  await signin('tomas@test.com'); await p.evaluate(()=>{ window.__mockEscrow=false; }); await p.evaluate(()=>window.__reloadEscrow());
  await p.goto(url+'#settings'); await p.waitForTimeout(400); await p.click('.snav[data-set="payout"]'); await p.click('#addPayoutBtn'); await p.locator('#payoutRows .po-type').first().selectOption('paypal'); await p.fill('#payoutRows .po-details','Jonas.Pay@paypal.com'); await p.click('#savePayoutBtn'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>{ const me=window.__mockdb.profiles.find(x=>x.email==='tomas@test.com'); return window.__mockdb.user_flags.some(f=>f.user_id===me.id&&f.kind==='match'&&f.reason.includes('deleted account')); }),'new account auto-flagged: same PayPal as deleted scammer');
  await signin('maya@test.com'); await p.goto(url+'#account'); await p.waitForTimeout(400); await p.click('#adminBtn'); await p.waitForTimeout(600); await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Tomas') && (await p.textContent('#adminBody')).includes('Matches a flagged account'),'Tomas appears in Bad actors as a match');
  // clean up for the remaining tests: remove Tomas, re-create Jonas as client with a conversation
  await p.evaluate(()=>{ const db=window.__mockdb; const t=db.profiles.find(x=>x.email==='tomas@test.com'); db.profiles=db.profiles.filter(x=>x!==t); db.user_flags=[]; db.user_identifiers=db.user_identifiers.filter(i=>i.user_id!==t.id); db.payout_details=db.payout_details.filter(x=>x.id!==t.id); db.deleted_user_identifiers=[]; });
  await p.evaluate(()=>{ window.__mockEscrow=true; }); await p.evaluate(()=>window.__reloadEscrow());
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML=''); await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signup"]'); await p.fill('#suName','Jonas'); await p.fill('#suEmail','jonas@test.com'); await p.fill('#suPass','password123'); await p.check('#suAgree'); await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.goto(url+'#home'); await p.waitForTimeout(600); await p.click('.real-card .message-person'); await p.waitForTimeout(800); await p.fill('.chat-window input','Hi again'); await p.keyboard.press('Enter'); await p.waitForTimeout(500);
  await p.evaluate(()=>{ const j=window.__mockdb.profiles.find(x=>x.email==='jonas@test.com'); window.__mockdb.reviews=(window.__savedReviews||[]).map(r=>({...r, client:j.id})); });
  await signin('maya@test.com');
  // second escrow contract: approve early
  await p.goto(url+'#home'); await p.waitForTimeout(500); await p.click('#contactList .contact'); await p.waitForTimeout(800); await p.click('.chat-window .open-contract'); await p.waitForTimeout(400);
  await p.fill('#ctTitle','Teaser'); await p.fill('#ctPrice','50'); await p.click('#ctSend'); await p.waitForTimeout(800);
  await signin('jonas@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  await p.click('[data-caction="accept"]'); await p.waitForTimeout(600); await p.click('[data-caction="pay"]'); await p.waitForTimeout(2500);
  await p.click('[data-caction="release"]'); await p.waitForTimeout(300); await p.click('#rlGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts.at(-1); return c.status==='completed' && window.__fakeStripe.transfers.at(-1).amount===5000; }),'client approved early -> €50 released');
  ok((await p.textContent('#modalRoot')).includes('released to the editor'),'completed state text');
  // third escrow contract: client disputes, admin refunds -> editor auto-flagged
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.goto(url+'#home'); await p.waitForTimeout(500); await p.click('#contactList .contact'); await p.waitForTimeout(800); await p.click('.chat-window .open-contract'); await p.waitForTimeout(400);
  await p.fill('#ctTitle','Logo sting'); await p.fill('#ctPrice','40'); await p.click('#ctSend'); await p.waitForTimeout(800);
  await signin('maya@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500); await p.click('[data-caction="accept"]'); await p.waitForTimeout(600);
  await signin('jonas@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500); await p.click('[data-caction="pay"]'); await p.waitForTimeout(2500);
  await p.click('[data-caction="dispute"]'); await p.waitForTimeout(300); await p.fill('#dsNote','Nothing delivered after 3 weeks'); await p.click('#dsGo'); await p.waitForTimeout(800);
  await signin('maya@test.com'); await p.goto(url+'#account'); await p.waitForTimeout(400); await p.click('#adminBtn'); await p.waitForTimeout(600); await p.click('.admin-tab[data-atab="contracts"]'); await p.waitForTimeout(600);
  await p.locator('.admin-row.is-banned [data-res="refund"]').click(); await p.waitForTimeout(300); await p.click('#resGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const f=window.__mockdb.user_flags; const ed=window.__mockdb.profiles.find(p=>p.email==='maya@test.com'); return f.length===1 && f[0].kind==='dispute_lost' && f[0].user_id===ed.id; }),'editor auto-flagged after losing dispute (refund)');
  await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Lost a dispute') && (await p.textContent('#adminBody')).includes('disputes lost 1'),'bad actors shows lost-dispute entry');
  await p.evaluate(()=>{ window.__mockdb.user_flags=[]; });
  // ---------- editor sees review on account, admin panel ----------
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#account'); await p.waitForTimeout(500);
  ok((await p.textContent('#accountReviews')).includes('Jonas'),'editor account shows received review');
  ok(await p.locator('#adminBtn').isVisible(),'admin sees Admin panel button');
  await p.click('#adminBtn'); await p.waitForTimeout(700);
  ok(await p.locator('#page-admin').evaluate(e=>e.classList.contains('active')),'admin page opens');
  await p.click('.admin-tab[data-atab="users"]'); await p.waitForTimeout(600);
  ok(await p.locator('.admin-row').count()===2,'admin lists 2 users');
  // ban Jonas
  const jonasRow=p.locator('.admin-row').filter({hasText:'jonas@test.com'});
  await jonasRow.locator('[data-aban]').click(); await p.waitForTimeout(300); await p.fill('#banReason','spam'); await p.click('#banGo'); await p.waitForTimeout(400);
  ok(await p.evaluate(()=>window.__mockdb.profiles.find(x=>x.email==='jonas@test.com').banned!==true),'a ban without a real reason is refused');
  await p.fill('#banReason','spamming clients with fake offers'); await p.click('#banGo'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.profiles.find(x=>x.email==='jonas@test.com').banned===true),'ban saved to DB');
  ok((await p.textContent('#adminBody')).includes('BANNED: spam'),'banned shown in list');
  await p.locator('.admin-row').filter({hasText:'jonas@test.com'}).locator('[data-aunban]').click(); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.profiles.find(x=>x.email==='jonas@test.com').banned===false),'unban works');
  // invites
  await p.click('.admin-tab[data-atab="invites"]'); await p.waitForTimeout(500);
  await p.fill('#invNote','for Tom'); await p.click('#invCreate'); await p.waitForTimeout(600);
  const code=(await p.textContent('#codeBox')).trim(); ok(/^CUV-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code),'new invite code shown once: '+code);
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML=''); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('for Tom'),'invite listed with note');
  // reviews tab
  await p.click('.admin-tab[data-atab="reviews"]'); await p.waitForTimeout(500);
  ok((await p.textContent('#adminBody')).includes('Great colour work'),'admin sees reviews');
  // delete Jonas entirely
  await p.click('.admin-tab[data-atab="users"]'); await p.waitForTimeout(500);
  await p.locator('.admin-row').filter({hasText:'jonas@test.com'}).locator('[data-adelete]').click(); await p.waitForTimeout(300);
  ok(await p.locator('#dzGo').isDisabled(),'delete needs typed confirmation');
  await p.fill('#dzWord','DELETE'); await p.click('#dzGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.profiles.length===1 && window.__mockdb.reviews.length===0 && window.__mockdb.conversations.length===0),'user + all data deleted');
  ok(await p.locator('.admin-row').count()===1,'admin list refreshed');
  // ---------- self delete ----------
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signup"]'); await p.waitForTimeout(200);
  await p.fill('#suName','Tom'); await p.fill('#suEmail','tom@test.com'); await p.fill('#suPass','password123'); await p.check('#suAgree'); await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.goto(url+'#join-editor'); await p.waitForTimeout(300); await p.fill('#inviteCode',code); await p.click('#inviteBtn'); await p.waitForTimeout(1800);
  ok(await p.evaluate(()=>window.__mockdb.profiles.find(x=>x.email==='tom@test.com').role==='editor'),'admin-created invite code works');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.goto(url+'#settings'); await p.waitForTimeout(400);
  ok(await p.locator('#deleteAccountBtn').isVisible(),'Delete my account visible in settings');
  await p.click('#deleteAccountBtn'); await p.waitForTimeout(300); await p.fill('#dzWord','DELETE'); await p.click('#dzGo'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>!window.__mockdb.profiles.some(x=>x.email==='tom@test.com')),'self-delete removed the account');
  ok(await p.locator('#signInBtn').isVisible(),'signed out after deleting');
  await p.screenshot({path:'shots/real-final.png'});

  // ---------- rules, privacy notice, reports ----------
  await p.goto(url+'#rules'); await p.waitForTimeout(500);
  ok(await p.locator('#page-rules').evaluate(e=>e.classList.contains('active')),'rules page opens');
  const rulesText = await p.textContent('#page-rules');
  ok(rulesText.includes('What Cuvori is') && rulesText.includes('Things that get you removed'),'rules page shows all the sections');
  ok(!/\{[a-z]+\}/i.test(rulesText),'no unfilled placeholders left in the rules');
  ok(/@/.test(rulesText) && rulesText.includes(await p.evaluate(()=>window.CUVORI_LEGAL.email)),'rules show the real contact address, whatever it is set to');
  await p.goto(url+'#privacy'); await p.waitForTimeout(400);
  ok((await p.textContent('#page-privacy')).includes('What is stored'),'privacy notice opens');
  // the same, in the language the person signed up in
  await p.evaluate(()=>localStorage.setItem('cuvoriLanguage','lt'));
  await p.goto(url+'#rules'); await p.reload(); await p.waitForTimeout(900);
  const ltText = await p.textContent('#page-rules');
  ok(!ltText.includes('What Cuvori is') && ltText.length > 4000,'rules are translated, not English fallback');
  await p.evaluate(()=>localStorage.setItem('cuvoriLanguage','en'));
  // sign up: the tick is required and is recorded
  await p.goto(url+'#create-account'); await p.reload(); await p.waitForTimeout(700); await p.click('#authSeg [data-auth="signup"]'); await p.waitForTimeout(200);
  await p.uncheck('#suAgree');
  await p.fill('#suName','Rita'); await p.fill('#suEmail','rita@test.com'); await p.fill('#suPass','password123');
  await p.click('[data-auth-signup]'); await p.waitForTimeout(400);
  ok(await p.evaluate(()=>!window.__mockdb.profiles.some(x=>x.email==='rita@test.com')),'no account without agreeing to the rules');
  await p.check('#suAgree'); await p.click('[data-auth-signup]'); await p.waitForTimeout(1200);
  ok(await p.evaluate(()=>{const r=window.__mockdb.profiles.find(x=>x.email==='rita@test.com'); return !!(r && r.rules_version && r.rules_accepted_at);}),'the version agreed to is stored against the account');
  // an older agreement is asked for again the next time she signs in
  await p.evaluate(()=>{ const me=window.__mockdb.profiles.find(x=>x.email==='rita@test.com'); me.rules_version='2019-01'; });
  await p.goto(url+'#account'); await p.waitForTimeout(400); await p.click('#signOutBtn'); await p.waitForTimeout(500);
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signin"]'); await p.waitForTimeout(200);
  await p.fill('#siEmail','rita@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1400);
  ok((await p.textContent('#modalRoot')).includes('rules have changed'),'a changed version is put in front of the person again');
  await p.click('#raYes'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>window.__mockdb.profiles.find(x=>x.email==='rita@test.com').rules_version!=='2019-01'),'agreeing again is recorded');
  // ---------- a report reaches the administrator ----------
  // Rita is the administrator here; Vida is an ordinary user with a problem
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(500);
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signup"]'); await p.waitForTimeout(200);
  await p.fill('#suName','Vida'); await p.fill('#suEmail','vida@test.com'); await p.fill('#suPass','password123'); await p.check('#suAgree');
  await p.click('[data-auth-signup]'); await p.waitForTimeout(1200);
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.goto(url+'#rules'); await p.waitForTimeout(500);
  await p.click('[data-legal-report]'); await p.waitForTimeout(400);
  await p.fill('#rpBody','short'); await p.click('#rpSend'); await p.waitForTimeout(300);
  ok(await p.evaluate(()=>(window.__mockdb.reports||[]).length===0),'an empty report is refused');
  await p.selectOption('#rpKind','scam');
  await p.fill('#rpBody','This profile asked me to pay outside Cuvori and then disappeared.');
  await p.click('#rpSend'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{const r=(window.__mockdb.reports||[])[0]; return !!(r && r.kind==='scam' && r.status==='open');}),'a report is stored and waiting for an answer');
  ok(await p.evaluate(()=>{
    const db=window.__mockdb, admin=db.profiles.find(x=>x.is_admin), me=db.profiles.find(x=>x.email==='vida@test.com');
    const c=db.conversations.find(c=>[c.user_a,c.user_b].includes(admin.id) && [c.user_a,c.user_b].includes(me.id));
    return !!(c && db.messages.some(m=>m.conversation_id===c.id && m.sender===me.id && m.body.startsWith('Report · scam')));
  }),'the report is delivered to the administrator as a message');
  // the administrator signs in and finds it in the messenger, with the bell showing it
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(500);
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signin"]'); await p.waitForTimeout(200);
  await p.fill('#siEmail','rita@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1600);
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  ok(!await p.locator('#notifBadge').evaluate(e=>e.classList.contains('hidden')),'the administrator has a notification waiting');
  await p.click('#messagesBtn'); await p.waitForTimeout(800);
  ok((await p.textContent('#contactList')).includes('Vida'),'the person who reported shows up in the messenger');
  await p.click('#closeSidebar').catch(()=>{}); await p.waitForTimeout(300);
  await p.click('#notificationsBtn'); await p.waitForTimeout(900);
  ok((await p.textContent('#modalRoot')).includes('Reports waiting: 1'),'the bell says how many reports are waiting');
  await p.locator('[data-notif-target]').first().click(); await p.waitForTimeout(1200);
  ok((await p.textContent('.chat-window')).includes('Report · scam'),'the notification opens the chat with the report in it');
  ok((await p.textContent('.chat-window')).includes('pay outside Cuvori'),'the whole message came through');
  await p.click('#notificationsBtn'); await p.waitForTimeout(900);
  await p.click('[data-notif-reports]'); await p.waitForTimeout(1000);
  ok((await p.textContent('#adminBody')).includes('pay outside Cuvori'),'it opens straight into the report queue');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.screenshot({path:'shots/rules.png'});
  } catch(e){ log.push('EXCEPTION '+e.message.split('\n')[0]); await p.screenshot({path:'shots/real-fail.png'}); }
  await b.close(); console.log(log.join('\n')); console.log(errs.length?('ERRORS:\n'+errs.join('\n')):'no page errors');
})();
