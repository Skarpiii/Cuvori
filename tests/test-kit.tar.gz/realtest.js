const { chromium } = require('playwright'); const fs=require('fs');
const log=[]; const ok=(c,m)=>log.push((c?'PASS ':'FAIL ')+m);
const mock=fs.readFileSync(__dirname+'/mock-supabase.js','utf8');
(async () => {
  const b = await chromium.launch(); const ctx=await b.newContext({viewport:{width:1400,height:900}});
  const errs=[];
  const url='file://'+process.cwd()+'/index.html';
  await ctx.addInitScript(mock);
  await ctx.route('**/supabase.min.js', r=>r.fulfill({status:200,body:'/* mocked */',contentType:'application/javascript'}));
  const p = await ctx.newPage(); p.on('pageerror',e=>errs.push('P1 '+e.message));
  try {
  await p.goto(url); await p.waitForTimeout(500);
  ok(await p.locator('.profile-card:not(.real-card)').first().isVisible(),'no real editors yet: example cards shown');
  ok(await p.locator('#exampleNote').count()===1,'example note shown');
  ok(await p.locator('#jobsEmptyReal').count()===0 || true,'jobs page loads');
  // --- editor signs up, redeems invite, creates public profile with project ---
  await p.goto(url+'#create-account'); await p.waitForTimeout(300);
  await p.fill('#suName','Maya'); await p.fill('#suEmail','maya@test.com'); await p.fill('#suPass','password123'); await p.click('[data-auth-signup]'); await p.waitForTimeout(800);
  await p.goto(url+'#join-editor'); await p.waitForTimeout(300); await p.fill('#inviteCode','CUV-2026-EDIT'); await p.click('#inviteBtn'); await p.waitForTimeout(1800);
  ok(await p.locator('#page-profile').evaluate(e=>e.classList.contains('active')),'invite accepted -> jumps to own profile');
  ok(await p.locator('#epSave').count()===1,'edit-profile form opens automatically');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML=''); await p.waitForTimeout(300);
  await p.goto(url+'#account'); await p.waitForTimeout(400);
  ok(await p.locator('#myProfileBtn').isVisible(),'editor sees My editor profile');
  await p.click('#myProfileBtn'); await p.waitForTimeout(800);
  ok(await p.locator('#page-profile').evaluate(e=>e.classList.contains('active')),'own profile page opens (draft)');
  ok(await p.locator('[data-edit-profile]').count()>=1,'Edit profile button for owner');
  ok((await p.textContent('#page-profile')).includes('Set up your editor profile'),'setup steps shown on draft profile');
  await p.locator('[data-edit-profile]').first().click(); await p.waitForTimeout(400);
  await p.fill('#epName','Maya Klein'); await p.fill('#epCity','Munich'); await p.fill('#epCountry','Germany'); await p.fill('#epLangs','English, German'); await p.fill('#epTools','DaVinci Resolve, Premiere Pro');
  await p.click('.ep-spec[data-c="catCommercial"]'); await p.fill('#epBio','Story-focused editor.'); await p.fill('#epRate','35'); await p.check('#epPublic');
  await p.click('#epSave'); await p.waitForTimeout(1000);
  ok((await p.textContent('#page-profile')).includes('Maya Klein') && (await p.textContent('#page-profile')).includes('Munich, Germany'),'profile saved and re-rendered from DB');
  ok(await p.locator('#page-profile .notice').count()===0,'no draft notice after publishing');
  // add project via link -> DB
  await p.click('[data-pf-add]'); await p.waitForTimeout(300);
  await p.fill('#npUrl','https://www.youtube.com/watch?v=dQw4w9WgXcQ'); await p.fill('#npTitle','Brand film'); await p.fill('#npTags','wedding'); await p.click('#npSave'); await p.waitForTimeout(800);
  const dbp=await p.evaluate(()=>window.__mockdb.projects.length); ok(dbp===1,`project saved to DB (${dbp})`);
  // training & credentials: course by Casey Faris linked to the project; chips for programs/skills/languages
  await p.locator('[data-edit-profile]').first().click(); await p.waitForTimeout(400);
  ok(await p.locator('.ep-lang.selected').count()===2 && await p.locator('.ep-skill.selected').count()===2,'saved languages/programs shown as selected chips');
  await p.click('.ep-skill[data-s="Color grading"]'); await p.click('.ep-lang[data-s="Lithuanian"]');
  await p.click('#epAddCred'); await p.waitForTimeout(200);
  await p.selectOption('.cred-row .cr-kind','course'); await p.fill('.cred-row .cr-title','Resolve Masterclass'); await p.fill('.cred-row .cr-by','Casey Faris'); await p.fill('.cred-row .cr-year','2025'); await p.fill('.cred-row .cr-link','caseyfaris.com/resolve');
  await p.locator('.cred-row .cr-proj').selectOption({index:1});
  await p.click('#epSave'); await p.waitForTimeout(1000);
  ok(await p.evaluate(()=>{ const e=window.__mockdb.editor_profiles[0]; return e.credentials.length===1 && e.credentials[0].by==='Casey Faris' && e.credentials[0].link==='https://caseyfaris.com/resolve' && !!e.credentials[0].project_id && e.tools.includes('Color grading') && e.languages.includes('Lithuanian'); }),'credentials + chip picks saved to DB');
  await p.click('.ep-tab[data-tab="about"]'); await p.waitForTimeout(200);
  ok((await p.textContent('[data-pane="about"]')).includes('Casey Faris') && (await p.textContent('[data-pane="about"]')).includes('Brand film'),'about tab shows training with linked project');
  // browse shows real card, hides demo
  await p.goto(url+'#home'); await p.waitForTimeout(900);
  ok(await p.locator('.real-card').count()===1,'real editor card on browse');
  ok(await p.locator('.profile-card:not(.real-card)').first().isHidden(),'example cards hidden once a real editor exists');
  ok((await p.textContent('.real-card .price')).includes('€35'),'price-first card shows €35');
  ok(await p.locator('.real-card .card-gallery .car-item').count()===1,'card gallery has the 1 real video');
  ok((await p.textContent('.real-card')).includes('Casey Faris'),'card shows training line');
  await p.hover('.real-card .car-item'); await p.waitForTimeout(700);
  ok(await p.locator('.real-card .hover-embed').count()===1 && (await p.getAttribute('.real-card .hover-embed','src')).includes('autoplay=1&mute=1'),'hovering a card video starts a muted YouTube preview');
  await p.mouse.move(5,5); await p.waitForTimeout(200);
  ok(await p.locator('.real-card .hover-embed').count()===0,'preview stops when the mouse leaves');
  await p.click('#allFiltersBtn'); await p.waitForTimeout(300);
  ok(await p.locator('.modal-filter[data-filter="YouTube long-form"]').count()===1 && await p.locator('.modal-filter[data-filter="price:30-60"]').count()===1,'all-filters has new categories, role and price');
  await p.click('.modal-filter[data-filter="Commercial"]'); await p.click('.modal-filter[data-filter="Editor"]'); await p.click('.modal-filter[data-filter="price:30-60"]'); await p.click('#applyFilters'); await p.waitForTimeout(300);
  ok(await p.locator('.real-card').first().isVisible(),'real card matches Commercial + Editor + €30–60');
  await p.click('#allFiltersBtn'); await p.waitForTimeout(300); await p.click('.modal-filter[data-filter="price:30-60"]'); await p.click('.modal-filter[data-filter="price:60-"]'); await p.click('#applyFilters'); await p.waitForTimeout(300);
  ok(await p.locator('.real-card').first().isHidden(),'price filter €60+ hides the €35 card');
  await p.click('#allFiltersBtn'); await p.waitForTimeout(300); await p.$$eval('.modal-filter.selected',els=>els.forEach(e=>e.click())); await p.click('#applyFilters'); await p.waitForTimeout(300);
  ok(await p.locator('.real-card').first().isVisible(),'filters cleared');
  // post a job as editor? (any account can) — post as this user
  await p.goto(url+'#post-job'); await p.waitForTimeout(300);
  await p.fill('#jobTitle','Need a colour grade'); await p.fill('#jobDesc','Short brand film'); await p.fill('#jobBudget','€300'); await p.click('#publishJob'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.jobs.length)===1,'job saved to DB');
  ok(await p.locator('.real-job').count()===1,'real job listed');
  ok(await p.locator('.job[data-job]:not(.real-job)').first().isHidden(),'demo jobs hidden');
  await p.click('#signOutBtn').catch(()=>{}); await p.goto(url+'#account'); await p.waitForTimeout(300); if(await p.locator('#signOutBtn').isVisible()){ await p.click('#signOutBtn'); await p.waitForTimeout(400); }
  // --- client signs up, messages editor ---
  await p.goto(url+'#create-account'); await p.waitForTimeout(300);
  await p.fill('#suName','Jonas'); await p.fill('#suEmail','jonas@test.com'); await p.fill('#suPass','password123'); await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.goto(url+'#home'); await p.waitForTimeout(600);
  await p.click('.real-card .message-person'); await p.waitForTimeout(800);
  ok(await p.locator('.chat-window').count()===1,'client opens chat with real editor');
  ok((await p.textContent('.chat-window .chat-head')).includes('Maya Klein'),'chat header shows editor name');
  ok(await p.locator('.chat-window .send-report').count()===0,'client has no Send update button');
  await p.fill('.chat-window input','Hi Maya, can you grade my film?'); await p.keyboard.press('Enter'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>window.__mockdb.messages.length)===1,'message saved to DB');
  ok(await p.locator('.chat-window .bubble.mine').count()===1,'message shown once (no duplicate from realtime)');
  ok(await p.locator('#contactList .contact').count()===1,'sidebar lists the conversation');
  // --- editor logs back in, sees message, sends progress update ---
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1000);
  ok(await p.locator('#contactList .contact').count()===1,'editor sees conversation with Jonas');
  await p.click('#notificationsBtn'); await p.waitForTimeout(600);
  ok((await p.textContent('#modalRoot')).includes('New message from Jonas'),'notification for new message');
  await p.click('#modalRoot [data-notif-target]'); await p.waitForTimeout(800);
  ok((await p.textContent('.chat-window .chat-messages')).includes('grade my film'),'editor sees client message');
  ok(await p.locator('.chat-window .send-report').count()===1,'editor has Send update button');
  await p.click('.chat-window .send-report'); await p.waitForTimeout(400);
  await p.fill('#rText','First cut ready'); await p.fill('#rLink','https://youtu.be/dQw4w9WgXcQ'); await p.click('#sendProgress'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.messages.filter(m=>m.kind==='report').length)===1,'progress report saved to DB');
  ok(await p.locator('.chat-window .report-card').count()===1,'report card in chat');
  ok(await p.locator('.reco-card').count()===0 && (await p.evaluate(()=>Object.keys(window.__cuv||{}).length))>=0,'no reminder right after sending');
  // client reviews and approves
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','jonas@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1000);
  await p.click('#contactList .contact'); await p.waitForTimeout(800);
  await p.click('.chat-window .report-card'); await p.waitForTimeout(600);
  ok(await p.locator('#approveVersion').count()===1,'client opens review modal');
  await p.click('#approveVersion'); await p.waitForTimeout(500);
  ok(await p.evaluate(()=>window.__mockdb.messages.find(m=>m.kind==='report').payload.status==='approved'),'approval saved to DB');
  // reminder for editor after 9 days
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.evaluate(()=>{ const m=window.__mockdb.messages.find(m=>m.kind==='report'); m.created_at=new Date(Date.now()-9*86400000).toISOString(); });
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#account'); await p.waitForTimeout(600);
  ok(await p.locator('.reco-card').count()===1,'editor gets 9-day reminder based on real messages');
  ok((await p.textContent('.reco-card')).includes('Jonas'),'reminder names the real client');
  // ---------- reviews: client reviews editor ----------
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','jonas@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1000);
  await p.goto(url+'#home'); await p.waitForTimeout(700);
  await p.click('.real-card .view-profile'); await p.waitForTimeout(600);
  await p.click('.ep-tab[data-tab="reviews"]'); await p.waitForTimeout(200);
  ok(await p.locator('[data-review]').count()===1,'client sees Leave a review button');
  await p.click('[data-review]'); await p.waitForTimeout(500);
  ok(await p.locator('#rvSave').count()===1,'review modal opens (has a conversation)');
  await p.click('.star-pick[data-star="4"]'); await p.fill('#rvText','Great colour work, fast.'); await p.click('#rvSave'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>window.__mockdb.reviews.length)===1,'review saved to DB');
  ok((await p.textContent('#page-profile')).includes('Great colour work'),'review shown on profile');
  ok((await p.textContent('#page-profile')).includes('4.0'),'profile rating 4.0');
  await p.goto(url+'#home'); await p.waitForTimeout(600);
  ok((await p.textContent('.real-card .status')).includes('4.0'),'card shows rating');
  ok(await p.locator('#adminBtn').isHidden(),'client has no admin button');
  // ---------- contracts + direct payment ----------
  await p.goto(url+'#home'); await p.waitForTimeout(600); await p.click('.real-card .message-person'); await p.waitForTimeout(900);
  ok(await p.locator('.chat-window .open-contract').count()===1,'chat has Contract button');
  await p.click('.chat-window .open-contract'); await p.waitForTimeout(400);
  ok(await p.locator('#ctSend').count()===1,'propose-contract form opens');
  await p.fill('#ctTitle','Brand film edit'); await p.fill('#ctDesc','4 min cut, 2 versions'); await p.fill('#ctPrice','300'); await p.click('#ctSend'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>window.__mockdb.contracts.length===1 && window.__mockdb.contracts[0].client!==window.__mockdb.contracts[0].editor),'contract saved with client/editor roles');
  ok(await p.locator('.chat-window .contract-card').count()===1,'contract card appears in chat');
  await p.click('.chat-window .contract-card'); await p.waitForTimeout(500);
  ok((await p.textContent('#modalRoot')).includes('Waiting for the other side'),'proposer sees waiting state');
  ok(await p.locator('[data-caction="accept"]').count()===0 && await p.locator('[data-caction="cancel"]').count()===1,'proposer cannot accept own proposal');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  // editor: payout details, accept
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#settings'); await p.waitForTimeout(400);
  ok(await p.locator('.snav[data-set="payout"]').isVisible(),'editor sees Payout details in settings');
  await p.click('.snav[data-set="payout"]'); await p.click('#addPayoutBtn'); await p.waitForTimeout(200);
  await p.fill('#payoutRows .po-details','LT12 3456 7890 1234 5678'); await p.fill('#payoutNote','Write the contract title as reference'); await p.click('#savePayoutBtn'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>window.__mockdb.payout_details.length===1 && window.__mockdb.payout_details[0].methods[0].type==='bank'),'payout details saved');
  await p.goto(url+'#contracts'); await p.waitForTimeout(700);
  ok(await p.locator('#contractsList .c-row').count()===1,'contracts page lists the contract');
  await p.click('#contractsList .c-row'); await p.waitForTimeout(500);
  ok(await p.locator('[data-caction="accept"]').count()===1,'editor can accept');
  await p.click('[data-caction="accept"]'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.contracts[0].status==='accepted'),'contract accepted');
  ok((await p.textContent('#modalRoot')).includes('Waiting for the client to pay'),'editor sees waiting-for-payment');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  // client: sees payout info, marks paid
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','jonas@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.click('#contractsList .c-row'); await p.waitForTimeout(600);
  ok((await p.textContent('#modalRoot')).includes('LT12 3456'),'client sees editor IBAN after acceptance');
  ok((await p.textContent('#modalRoot')).includes('Cuvori is not involved'),'direct-payment note shown');
  await p.click('[data-caction="mark_paid"]'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.contracts[0].status==='paid_marked'),'client marked as paid');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  ok(await p.evaluate(()=>window.__mockdb.messages.filter(m=>m.kind==='contract').length===3),'each step posted a contract event in chat');
  // editor: confirm + complete
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.click('#contractsList .c-row'); await p.waitForTimeout(600);
  await p.click('[data-caction="confirm_paid"]'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.contracts[0].status==='paid'),'editor confirmed payment');
  await p.click('[data-caction="complete"]'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.contracts[0].status==='completed'),'contract completed');
  ok(await p.locator('[data-caction]').count()===0,'no more actions on a completed contract');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  // ---------- escrow (Stripe) flow ----------
  const signin=async(e)=>{ await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML=''); await p.goto(url+'#account'); await p.waitForTimeout(300); if(await p.locator('#signOutBtn').isVisible()){ await p.click('#signOutBtn'); await p.waitForTimeout(400);} await p.click('#signInBtn'); await p.waitForTimeout(200); await p.fill('#siEmail',e); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200); };
  await p.evaluate(()=>{ window.__mockEscrow=true; }); await p.evaluate(()=>window.__reloadEscrow()); await p.waitForTimeout(400);
  await p.goto(url+'#settings'); await p.waitForTimeout(300); await p.click('.snav[data-set="payout"]'); await p.waitForTimeout(200);
  ok(await p.locator('#stripeBox').isVisible() && (await p.textContent('#stripeBox')).includes('Not connected'),'editor sees Stripe box: not connected');
  await p.click('#stripeConnectBtn'); await p.waitForTimeout(1200);
  ok((await p.textContent('#stripeBox')).includes('Ready to receive'),'after Stripe onboarding: ready');
  await p.goto(url+'#home'); await p.waitForTimeout(500); await p.click('#contactList .contact'); await p.waitForTimeout(800);
  await p.click('.chat-window .open-contract'); await p.waitForTimeout(400);
  ok((await p.textContent('#modalRoot')).includes('Payment is protected'),'proposal explains protected payment');
  await p.fill('#ctTitle','Reel edit'); await p.fill('#ctPrice','200'); await p.click('#ctSend'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts.at(-1); return c.payment_mode==='escrow' && c.amount_cents===20000; }),'escrow contract proposed (€200)');
  await signin('jonas@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  await p.click('[data-caction="accept"]'); await p.waitForTimeout(700);
  ok((await p.textContent('#modalRoot')).includes('Pay securely') && (await p.textContent('#modalRoot')).includes('€6.25'),'client sees Pay securely with €6.25 card fee');
  await p.click('[data-caction="pay"]'); await p.waitForTimeout(2500);
  ok(await p.evaluate(()=>window.__mockdb.contracts.at(-1).status==='funded'),'contract funded after checkout');
  ok((await p.textContent('#modalRoot')).includes('Money held by Cuvori'),'client sees money held');
  await signin('maya@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  ok(await p.locator('[data-caction="deliver"]').count()===1,'editor sees Mark as delivered');
  await p.click('[data-caction="deliver"]'); await p.waitForTimeout(300); await p.fill('#dvUrl','https://drive.test/final'); await p.fill('#dvNote','Final cut v1'); await p.click('#dvGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.contracts.at(-1).status==='delivered'),'delivered');
  ok((await p.textContent('#modalRoot')).includes('released to you automatically'),'editor sees auto-release date');
  await signin('jonas@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  ok((await p.textContent('#modalRoot')).includes('drive.test/final'),'client sees delivery link');
  await p.click('[data-caction="changes"]'); await p.waitForTimeout(300); await p.fill('#chNote','Please fix the colour in the intro'); await p.click('#chGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.contracts.at(-1).status==='funded' && window.__mockdb.messages.some(m=>m.kind==='change_request'&&m.body.includes('colour'))),'changes requested -> back to funded, note in chat');
  await signin('maya@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  await p.click('[data-caction="deliver"]'); await p.waitForTimeout(300); await p.fill('#dvUrl','https://drive.test/final-v2'); await p.click('#dvGo'); await p.waitForTimeout(800);
  ok(await p.locator('[data-caction="dispute"]').count()===1,'editor has "client isn’t responding" button');
  await p.click('[data-caction="dispute"]'); await p.waitForTimeout(300); await p.fill('#dsNote','Delivered v2 exactly as agreed, client silent for days'); await p.click('#dsGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts.at(-1); return c.status==='disputed' && c.dispute_by===c.editor; }),'editor opened dispute');
  ok((await p.textContent('#modalRoot')).includes('Cuvori is reviewing'),'dispute state shown');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.goto(url+'#account'); await p.waitForTimeout(400); await p.click('#adminBtn'); await p.waitForTimeout(600); await p.click('.admin-tab[data-atab="contracts"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Dispute by editor') && (await p.textContent('#adminBody')).includes('client silent'),'admin sees the dispute with reason');
  await p.locator('.admin-row.is-banned [data-res="split"]').click(); await p.waitForTimeout(300); await p.fill('#resPct','70'); await p.fill('#resNote','Work delivered, minor issues'); await p.click('#resGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts.at(-1); const s=window.__fakeStripe; return c.status==='completed' && c.split_editor_cents===14000 && s.transfers.at(-1).amount===14000 && s.refunds.at(-1).amount===6000; }),'admin split 70/30 executed');
  ok(await p.evaluate(()=>window.__mockdb.messages.some(m=>m.body&&m.body.startsWith('Cuvori decision'))),'decision note posted to chat');
  // ---------- bad actors ----------
  await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Nobody on the list'),'bad actors list empty after a split');
  await p.click('.admin-tab[data-atab="users"]'); await p.waitForTimeout(600);
  await p.locator('.admin-row').filter({hasText:'jonas@test.com'}).locator('[data-aflag]').click(); await p.waitForTimeout(300);
  await p.selectOption('#flKind','scam'); await p.fill('#flReason','Tried to pay outside Cuvori'); await p.click('#flGo'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.user_flags.length===1 && window.__mockdb.user_flags[0].kind==='scam'),'manual flag saved');
  ok((await p.textContent('#adminBody')).includes('1 flag'),'users list shows flag count');
  await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Jonas') && (await p.textContent('#adminBody')).includes('Tried to pay outside'),'bad actors list shows Jonas with reason');
  await p.click('[data-unflag]'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>window.__mockdb.user_flags.length===0) && (await p.textContent('#adminBody')).includes('Nobody on the list'),'flag removed');
  // ---------- identifiers: returning bad actor is recognised ----------
  // flag Jonas as scam, then a "new" account (Tomas) that pays out to Jonas's PayPal gets auto-matched
  await p.click('.admin-tab[data-atab="users"]'); await p.waitForTimeout(500);
  await p.locator('.admin-row').filter({hasText:'jonas@test.com'}).locator('[data-aflag]').click(); await p.waitForTimeout(300);
  await p.selectOption('#flKind','scam'); await p.fill('#flReason','Chargeback after delivery'); await p.click('#flGo'); await p.waitForTimeout(600);
  await p.evaluate(()=>{ const j=window.__mockdb.profiles.find(x=>x.email==='jonas@test.com'); window.__recId(j.id,'paypal','jonas.pay@paypal.com','paypal ••.com'); });
  await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('On record:') && (await p.textContent('#adminBody')).includes('E-mail: jonas@test.com'),'bad actor row shows identifiers on record');
  await signin('jonas@test.com'); await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.evaluate(()=>{ window.__savedReviews=JSON.parse(JSON.stringify(window.__mockdb.reviews)); });
  // Jonas deletes his own account -> fingerprints kept as ghost
  await p.goto(url+'#settings'); await p.waitForTimeout(400); await p.click('#deleteAccountBtn'); await p.waitForTimeout(300); await p.fill('#dzWord','DELETE'); await p.click('#dzGo'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>window.__mockdb.deleted_user_identifiers.length>=2),'identifiers kept after a flagged user deletes the account');
  // new editor account using the same PayPal for payouts
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signup"]'); await p.fill('#suName','Tomas'); await p.fill('#suEmail','tomas@test.com'); await p.fill('#suPass','password123'); await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.evaluate(()=>{ const me=window.__mockdb.profiles.find(x=>x.email==='tomas@test.com'); me.role='editor'; });
  await signin('tomas@test.com'); await p.evaluate(()=>{ window.__mockEscrow=false; }); await p.evaluate(()=>window.__reloadEscrow());
  await p.goto(url+'#settings'); await p.waitForTimeout(400); await p.click('.snav[data-set="payout"]'); await p.click('#addPayoutBtn'); await p.locator('#payoutRows .po-type').first().selectOption('paypal'); await p.fill('#payoutRows .po-details','Jonas.Pay@paypal.com'); await p.click('#savePayoutBtn'); await p.waitForTimeout(600);
  ok(await p.evaluate(()=>{ const me=window.__mockdb.profiles.find(x=>x.email==='tomas@test.com'); return window.__mockdb.user_flags.some(f=>f.user_id===me.id&&f.kind==='match'&&f.reason.includes('deleted account')); }),'new account auto-flagged: same PayPal as deleted scammer');
  await signin('maya@test.com'); await p.goto(url+'#account'); await p.waitForTimeout(400); await p.click('#adminBtn'); await p.waitForTimeout(600); await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Tomas') && (await p.textContent('#adminBody')).includes('Matches a flagged account'),'Tomas appears in Bad actors as a match');
  // clean up for the remaining tests: remove Tomas, re-create Jonas as client with a conversation
  await p.evaluate(()=>{ const db=window.__mockdb; const t=db.profiles.find(x=>x.email==='tomas@test.com'); db.profiles=db.profiles.filter(x=>x!==t); db.user_flags=[]; db.user_identifiers=db.user_identifiers.filter(i=>i.user_id!==t.id); db.payout_details=db.payout_details.filter(x=>x.id!==t.id); db.deleted_user_identifiers=[]; });
  await p.evaluate(()=>{ window.__mockEscrow=true; }); await p.evaluate(()=>window.__reloadEscrow());
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML=''); await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signup"]'); await p.fill('#suName','Jonas'); await p.fill('#suEmail','jonas@test.com'); await p.fill('#suPass','password123'); await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.goto(url+'#home'); await p.waitForTimeout(600); await p.click('.real-card .message-person'); await p.waitForTimeout(800); await p.fill('.chat-window input','Hi again'); await p.keyboard.press('Enter'); await p.waitForTimeout(500);
  await p.evaluate(()=>{ const j=window.__mockdb.profiles.find(x=>x.email==='jonas@test.com'); window.__mockdb.reviews=(window.__savedReviews||[]).map(r=>({...r, client:j.id})); });
  await signin('maya@test.com');
  // second escrow contract: approve early
  await p.goto(url+'#home'); await p.waitForTimeout(500); await p.click('#contactList .contact'); await p.waitForTimeout(800); await p.click('.chat-window .open-contract'); await p.waitForTimeout(400);
  await p.fill('#ctTitle','Teaser'); await p.fill('#ctPrice','50'); await p.click('#ctSend'); await p.waitForTimeout(800);
  await signin('jonas@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500);
  await p.click('[data-caction="accept"]'); await p.waitForTimeout(600); await p.click('[data-caction="pay"]'); await p.waitForTimeout(2500);
  await p.click('[data-caction="release"]'); await p.waitForTimeout(300); await p.click('#rlGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const c=window.__mockdb.contracts.at(-1); return c.status==='completed' && window.__fakeStripe.transfers.at(-1).amount===5000; }),'client approved early -> €50 released');
  ok((await p.textContent('#modalRoot')).includes('released to the editor'),'completed state text');
  // third escrow contract: client disputes, admin refunds -> editor auto-flagged
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.goto(url+'#home'); await p.waitForTimeout(500); await p.click('#contactList .contact'); await p.waitForTimeout(800); await p.click('.chat-window .open-contract'); await p.waitForTimeout(400);
  await p.fill('#ctTitle','Logo sting'); await p.fill('#ctPrice','40'); await p.click('#ctSend'); await p.waitForTimeout(800);
  await signin('maya@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500); await p.click('[data-caction="accept"]'); await p.waitForTimeout(600);
  await signin('jonas@test.com'); await p.goto(url+'#contracts'); await p.waitForTimeout(700); await p.locator('#contractsList .c-row').first().click(); await p.waitForTimeout(500); await p.click('[data-caction="pay"]'); await p.waitForTimeout(2500);
  await p.click('[data-caction="dispute"]'); await p.waitForTimeout(300); await p.fill('#dsNote','Nothing delivered after 3 weeks'); await p.click('#dsGo'); await p.waitForTimeout(800);
  await signin('maya@test.com'); await p.goto(url+'#account'); await p.waitForTimeout(400); await p.click('#adminBtn'); await p.waitForTimeout(600); await p.click('.admin-tab[data-atab="contracts"]'); await p.waitForTimeout(600);
  await p.locator('.admin-row.is-banned [data-res="refund"]').click(); await p.waitForTimeout(300); await p.click('#resGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>{ const f=window.__mockdb.user_flags; const ed=window.__mockdb.profiles.find(p=>p.email==='maya@test.com'); return f.length===1 && f[0].kind==='dispute_lost' && f[0].user_id===ed.id; }),'editor auto-flagged after losing dispute (refund)');
  await p.click('.admin-tab[data-atab="bad"]'); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('Lost a dispute') && (await p.textContent('#adminBody')).includes('disputes lost 1'),'bad actors shows lost-dispute entry');
  await p.evaluate(()=>{ window.__mockdb.user_flags=[]; });
  // ---------- editor sees review on account, admin panel ----------
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.click('#signInBtn'); await p.waitForTimeout(300); await p.fill('#siEmail','maya@test.com'); await p.fill('#siPass','password123'); await p.click('[data-auth-signin]'); await p.waitForTimeout(1200);
  await p.goto(url+'#account'); await p.waitForTimeout(500);
  ok((await p.textContent('#accountReviews')).includes('Jonas'),'editor account shows received review');
  ok(await p.locator('#adminBtn').isVisible(),'admin sees Admin panel button');
  await p.click('#adminBtn'); await p.waitForTimeout(700);
  ok(await p.locator('#page-admin').evaluate(e=>e.classList.contains('active')),'admin page opens');
  await p.click('.admin-tab[data-atab="users"]'); await p.waitForTimeout(600);
  ok(await p.locator('.admin-row').count()===2,'admin lists 2 users');
  // ban Jonas
  const jonasRow=p.locator('.admin-row').filter({hasText:'jonas@test.com'});
  await jonasRow.locator('[data-aban]').click(); await p.waitForTimeout(300); await p.fill('#banReason','spam'); await p.click('#banGo'); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.profiles.find(x=>x.email==='jonas@test.com').banned===true),'ban saved to DB');
  ok((await p.textContent('#adminBody')).includes('BANNED: spam'),'banned shown in list');
  await p.locator('.admin-row').filter({hasText:'jonas@test.com'}).locator('[data-aunban]').click(); await p.waitForTimeout(700);
  ok(await p.evaluate(()=>window.__mockdb.profiles.find(x=>x.email==='jonas@test.com').banned===false),'unban works');
  // invites
  await p.click('.admin-tab[data-atab="invites"]'); await p.waitForTimeout(500);
  await p.fill('#invNote','for Tom'); await p.click('#invCreate'); await p.waitForTimeout(600);
  const code=(await p.textContent('#codeBox')).trim(); ok(/^CUV-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code),'new invite code shown once: '+code);
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML=''); await p.waitForTimeout(600);
  ok((await p.textContent('#adminBody')).includes('for Tom'),'invite listed with note');
  // reviews tab
  await p.click('.admin-tab[data-atab="reviews"]'); await p.waitForTimeout(500);
  ok((await p.textContent('#adminBody')).includes('Great colour work'),'admin sees reviews');
  // delete Jonas entirely
  await p.click('.admin-tab[data-atab="users"]'); await p.waitForTimeout(500);
  await p.locator('.admin-row').filter({hasText:'jonas@test.com'}).locator('[data-adelete]').click(); await p.waitForTimeout(300);
  ok(await p.locator('#dzGo').isDisabled(),'delete needs typed confirmation');
  await p.fill('#dzWord','DELETE'); await p.click('#dzGo'); await p.waitForTimeout(800);
  ok(await p.evaluate(()=>window.__mockdb.profiles.length===1 && window.__mockdb.reviews.length===0 && window.__mockdb.conversations.length===0),'user + all data deleted');
  ok(await p.locator('.admin-row').count()===1,'admin list refreshed');
  // ---------- self delete ----------
  await p.goto(url+'#account'); await p.waitForTimeout(300); await p.click('#signOutBtn'); await p.waitForTimeout(400);
  await p.goto(url+'#create-account'); await p.waitForTimeout(300); await p.click('#authSeg [data-auth="signup"]'); await p.waitForTimeout(200);
  await p.fill('#suName','Tom'); await p.fill('#suEmail','tom@test.com'); await p.fill('#suPass','password123'); await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.goto(url+'#join-editor'); await p.waitForTimeout(300); await p.fill('#inviteCode',code); await p.click('#inviteBtn'); await p.waitForTimeout(1800);
  ok(await p.evaluate(()=>window.__mockdb.profiles.find(x=>x.email==='tom@test.com').role==='editor'),'admin-created invite code works');
  await p.evaluate(()=>document.querySelector('#modalRoot').innerHTML='');
  await p.goto(url+'#settings'); await p.waitForTimeout(400);
  ok(await p.locator('#deleteAccountBtn').isVisible(),'Delete my account visible in settings');
  await p.click('#deleteAccountBtn'); await p.waitForTimeout(300); await p.fill('#dzWord','DELETE'); await p.click('#dzGo'); await p.waitForTimeout(900);
  ok(await p.evaluate(()=>!window.__mockdb.profiles.some(x=>x.email==='tom@test.com')),'self-delete removed the account');
  ok(await p.locator('#signInBtn').isVisible(),'signed out after deleting');
  await p.screenshot({path:'shots/real-final.png'});
  } catch(e){ log.push('EXCEPTION '+e.message.split('\n')[0]); await p.screenshot({path:'shots/real-fail.png'}); }
  await b.close(); console.log(log.join('\n')); console.log(errs.length?('ERRORS:\n'+errs.join('\n')):'no page errors');
})();
