  // ---------- a typed field that turns matches into tags: "Lith" → Lithuanian ----------
  // options: [{key, labels}] · selected: keys · allowFree: an unknown word can be added as its own tag
  function tagInputHtml(id, opts){
    const o=opts||{}; const sel=(o.selected||[]);
    const labelOf=k=>{ const x=(o.options||[]).find(y=>y.key===k); return x?pl(x.labels):k; };
    return `<div class="taginput" id="${escapeHtml(id)}" data-free="${o.allowFree?"1":"0"}">
      <span class="tags">${sel.map(k=>`<span class="tag" data-k="${escapeHtml(k)}">${escapeHtml(labelOf(k))}<button type="button" class="tag-x" aria-label="remove">×</button></span>`).join("")}</span>
      <input type="text" autocomplete="off" placeholder="${escapeHtml(o.placeholder||"")}" maxlength="40">
      <div class="tag-suggest hidden"></div></div>`;
  }
  function tagInputBind(root, id, options){
    const box=$("#"+id, root); if(!box) return; const input=$("input",box), sug=$(".tag-suggest",box), tags=$(".tags",box);
    const opts=options||[]; const labelOf=k=>{ const x=opts.find(y=>y.key===k); return x?pl(x.labels):k; };
    const have=()=>$$(".tag",tags).map(t0=>t0.dataset.k);
    const add=k=>{ if(!k||have().includes(k)) return; tags.insertAdjacentHTML("beforeend",`<span class="tag" data-k="${escapeHtml(k)}">${escapeHtml(labelOf(k))}<button type="button" class="tag-x" aria-label="remove">×</button></span>`); input.value=""; hide(); };
    const hide=()=>{ sug.classList.add("hidden"); sug.innerHTML=""; };
    const matches=q=>{ q=q.trim().toLowerCase(); if(!q) return []; const h=have();
      return opts.filter(x=>!h.includes(x.key)).map(x=>({x, names:[...new Set(Object.values(x.labels||{}))]}))
        .filter(m=>m.names.some(n=>n.toLowerCase().startsWith(q)) || m.names.some(n=>n.toLowerCase().includes(q)))
        .sort((a,b)=>{ const as=a.names.some(n=>n.toLowerCase().startsWith(q))?0:1, bs=b.names.some(n=>n.toLowerCase().startsWith(q))?0:1; return as-bs; }).slice(0,8).map(m=>m.x); };
    const show=()=>{ const m=matches(input.value); const free=box.dataset.free==="1" && input.value.trim() && !m.length && !/[<>]/.test(input.value);
      if(!m.length && !free){ hide(); return; }
      sug.innerHTML=m.map((x,i)=>`<button type="button" class="tag-opt${i===0?" active":""}" data-k="${escapeHtml(x.key)}">${escapeHtml(pl(x.labels))}</button>`).join("")+(free?`<button type="button" class="tag-opt${m.length?"":" active"}" data-k="${escapeHtml(input.value.trim())}">${escapeHtml(t("ti_addOwn").replace("{w}",input.value.trim()))}</button>`:"");
      sug.classList.remove("hidden"); };
    const freeOk=v=>box.dataset.free==="1" && v.trim() && !/[<>]/.test(v);
    // a pasted "a, b, c" in a free field becomes tags as it arrives; the part after the last comma stays editable
    input.addEventListener("input",()=>{ if(box.dataset.free==="1" && input.value.includes(",")){ const parts=input.value.split(","); const rest=parts.pop(); parts.map(x=>x.trim()).filter(x=>freeOk(x)).forEach(add); input.value=rest.replace(/^\s+/,""); } show(); });
    input.addEventListener("focus",show);
    input.addEventListener("keydown",e=>{
      const act=$(".tag-opt.active",sug), all=$$(".tag-opt",sug);
      if(e.key==="Enter"){ e.preventDefault(); if(act) add(act.dataset.k); else if(all[0]) add(all[0].dataset.k); else if(box.dataset.free==="1" && input.value.trim() && !/[<>]/.test(input.value)) add(input.value.trim()); }
      else if(e.key==="ArrowDown"||e.key==="ArrowUp"){ if(!all.length) return; e.preventDefault(); let i=all.indexOf(act); i=e.key==="ArrowDown"?Math.min(all.length-1,i+1):Math.max(0,i-1); all.forEach((b,j)=>b.classList.toggle("active",j===i)); }
      else if(e.key==="Backspace" && !input.value){ const last=$$(".tag",tags).pop(); if(last) last.remove(); }
      else if(e.key==="Escape") hide();
      else if(e.key==="," ){ e.preventDefault(); const first=$(".tag-opt",sug); if(first) add(first.dataset.k); }
    });
    sug.addEventListener("mousedown",e=>{ const b=e.target.closest(".tag-opt"); if(b){ e.preventDefault(); add(b.dataset.k); input.focus(); } });
    tags.addEventListener("click",e=>{ const x=e.target.closest(".tag-x"); if(x){ x.closest(".tag").remove(); input.focus(); } });
    box.addEventListener("click",e=>{ if(e.target===box||e.target===tags) input.focus(); });
    // typing something and clicking Save straight away must not lose it
    input.addEventListener("blur",()=>{ if(freeOk(input.value)) add(input.value.trim()); setTimeout(hide,150); });
  }
  function tagInputValues(root, id){ const box=$("#"+id, root); return box ? $$(".tag",box).map(t0=>t0.dataset.k) : []; }
