// In-memory Supabase mock injected before page scripts (test only).
(() => {
  const db = { profiles:[], editor_profiles:[], projects:[], jobs:[], conversations:[], messages:[], reviews:[], invites:[], contracts:[], payout_details:[], user_flags:[], user_identifiers:[], deleted_user_identifiers:[] };
  const users = {}; let session = null; const listeners = []; const invites = {"CUV-2026-EDIT":null,"CUV-MAYA-0001":null};
  const channels = [];
  const norm=v=>String(v||"").toLowerCase().replace(/[\s\-\.]/g,"");
  const recId=(uid,kind,value,label)=>{ if(!uid||!value||norm(value).length<4) return; const h="h:"+norm(value); if(!db.user_identifiers.some(i=>i.user_id===uid&&i.kind===kind&&i.value_hash===h)) db.user_identifiers.push({user_id:uid,kind,value_hash:h,label:label||"",created_at:new Date().toISOString()});
    db.user_identifiers.filter(i=>i.kind===kind&&i.value_hash===h&&i.user_id!==uid).forEach(i=>{ const p=db.profiles.find(x=>x.id===i.user_id); if(p&&(p.banned||db.user_flags.some(f=>f.user_id===p.id))&&!db.user_flags.some(f=>f.user_id===uid&&f.kind==="match"&&f.reason.includes(p.id))) db.user_flags.push({id:uuid(),user_id:uid,kind:"match",reason:"Same "+kind+" ("+label+") as flagged user "+(p.first_name||p.email)+" ["+p.id+"]",created_at:new Date().toISOString()}); });
    db.deleted_user_identifiers.filter(g=>g.kind===kind&&g.value_hash===h).forEach(g=>{ if(!db.user_flags.some(f=>f.user_id===uid&&f.reason.includes(g.id))) db.user_flags.push({id:uuid(),user_id:uid,kind:"match",reason:"Same "+kind+" ("+label+") as a deleted account that was flagged: "+g.note+" [deleted account "+g.id+"]",created_at:new Date().toISOString()}); }); };
  window.__recId=recId;
  const evt=(c,ev)=>{ const row={id:uuid(),conversation_id:c.conversation_id,sender:uid(),kind:"contract",body:c.title,payload:{contract_id:c.id,event:ev,title:c.title,price:c.price,currency:c.currency,pricing:c.pricing,status:c.status},created_at:new Date().toISOString()}; db.messages.push(row); const cv=db.conversations.find(x=>x.id===c.conversation_id); if(cv) cv.last_message_at=row.created_at; setTimeout(()=>channels.forEach(ch=>ch.fire("INSERT","messages",row)),0); };
  const uuid = () => "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => { const r = Math.random()*16|0; return (c==="x"?r:(r&0x3|0x8)).toString(16); });
  const emit = ev => listeners.forEach(f => f(ev, session));
  const uid = () => session ? session.user.id : null;

  function query(table){
    const st = { filters:[], order:null, limit:null, op:"select", vals:null, single:false, maybe:false, sel:"*" };
    const rows = () => db[table];
    const match = r => st.filters.every(f => f.kind==="eq" ? String(r[f.k])===String(f.v) : f.kind==="in" ? f.v.map(String).includes(String(r[f.k])) : true);
    const q = {
      select(sel){ if(st.op==="select") st.sel=sel||"*"; st.wantReturn=true; return q; },
      eq(k,v){ st.filters.push({kind:"eq",k,v}); return q; },
      in(k,v){ st.filters.push({kind:"in",k,v}); return q; },
      order(k,o){ st.order={k,asc:!o||o.ascending!==false}; return q; },
      limit(n){ st.limit=n; return q; },
      single(){ st.single=true; return q; },
      maybeSingle(){ st.maybe=true; return q; },
      insert(vals){ st.op="insert"; st.vals=Array.isArray(vals)?vals:[vals]; return q; },
      upsert(vals,opts){ st.op="upsert"; st.vals=Array.isArray(vals)?vals:[vals]; st.conflict=opts&&opts.onConflict?opts.onConflict.split(","):["id"]; return q; },
      update(vals){ st.op="update"; st.vals=vals; return q; },
      delete(){ st.op="delete"; return q; },
      then(res, rej){
        let out=null, error=null;
        try{
          if(st.op==="select"){
            let r = rows().filter(match);
            // RLS-ish: editor_profiles only public or own; projects only of public editors or own; invites hidden
            if(table==="editor_profiles") r = r.filter(x => (x.is_public && !(db.profiles.find(p=>p.id===x.id)||{}).banned) || x.id===uid());
            if(table==="projects") r = r.filter(x => x.owner===uid() || db.editor_profiles.some(e=>e.id===x.owner && e.is_public));
            if(table==="conversations") r = r.filter(x => uid() && (x.user_a===uid()||x.user_b===uid()));
            if(table==="contracts") r = r.filter(x => uid() && (x.editor===uid()||x.client===uid()));
            if(table==="payout_details") r = r.filter(x => x.id===uid());
            if(table==="messages") r = r.filter(x => db.conversations.some(c=>c.id===x.conversation_id && uid() && (c.user_a===uid()||c.user_b===uid())));
            if(st.order) r = r.slice().sort((a,b)=> (a[st.order.k]>b[st.order.k]?1:a[st.order.k]<b[st.order.k]?-1:0) * (st.order.asc?1:-1));
            if(st.limit) r = r.slice(0, st.limit);
            out = (st.single||st.maybe) ? (r[0]||null) : r;
            if(st.single && !out) error={message:"no rows"};
          } else if(st.op==="insert" || st.op==="upsert"){
            const ins = st.vals.map(v => { const row={...v}; if(!row.id) row.id=uuid(); if(!row.created_at) row.created_at=new Date().toISOString(); return row; });
            for(const row of ins){
              if(table==="messages"){ const c=db.conversations.find(c=>c.id===row.conversation_id); if(c) c.last_message_at=row.created_at; setTimeout(()=>channels.forEach(ch=>ch.fire("INSERT",table,row)),0); }
              if(table==="payout_details"){ (row.methods||[]).forEach(m=>{ let k=m.type==='bank'?'iban':(['paypal','revolut','wise'].includes(m.type)?m.type:'other'); recId(row.id,k,m.details,k+' ••'+String(m.details||'').replace(/\s/g,'').slice(-4)); }); }
              if(st.op==="upsert"){ const i=rows().findIndex(x=>st.conflict.every(k=>x[k]===row[k])); if(i>=0){ rows()[i]={...rows()[i],...row}; continue; } }
              rows().push(row);
            }
            out = st.single ? ins[0] : ins;
          } else if(st.op==="update"){
            const r = rows().filter(match); r.forEach(x=>Object.assign(x, st.vals));
            if(table==="messages") r.forEach(x=>setTimeout(()=>channels.forEach(ch=>ch.fire("UPDATE",table,x)),0));
            out = r;
          } else if(st.op==="delete"){
            const keep = rows().filter(x=>!match(x)); db[table].length=0; keep.forEach(x=>db[table].push(x)); out=null;
          }
        }catch(e){ error={message:e.message}; }
        return Promise.resolve({ data:out, error }).then(res, rej);
      }
    };
    return q;
  }

  const client = {
    auth:{
      async getSession(){ return {data:{session}}; },
      onAuthStateChange(f){ listeners.push(f); return {data:{subscription:{unsubscribe(){}}}}; },
      async signUp({email,password,options}){ if(users[email]) return {data:{},error:{message:"User already registered"}}; const id=uuid(); users[email]={id,password}; db.profiles.push({id,email,first_name:options.data.first_name,role:"client",is_admin:Object.keys(users).length===1,banned:false,created_at:new Date().toISOString()}); recId(id,"email",email,email); session={user:{id,email,user_metadata:{first_name:options.data.first_name}}}; setTimeout(()=>emit("SIGNED_IN"),0); return {data:{session},error:null}; },
      async signInWithPassword({email,password}){ const u=users[email]; if(!u||u.password!==password) return {data:{},error:{message:"Invalid login credentials"}}; session={user:{id:u.id,email,user_metadata:{}}}; setTimeout(()=>emit("SIGNED_IN"),0); return {data:{session},error:null}; },
      async signOut(){ session=null; setTimeout(()=>emit("SIGNED_OUT"),0); return {error:null}; },
      async resetPasswordForEmail(){ return {error:null}; },
      async updateUser(){ return {error:null}; }
    },
    from(table){ return query(table); },
    rpc(fn, args){
      const pr=this.rpcImpl(fn, args||{});
      pr.maybeSingle=()=>pr.then(r=>({...r, data:Array.isArray(r.data)?(r.data[0]||null):r.data}));
      pr.single=pr.maybeSingle;
      return pr;
    },
    async rpcImpl(fn, args){
      if(fn==="my_profile"){ if(!uid()) return {data:[]}; return {data: db.profiles.filter(p=>p.id===uid()).map(p=>({...p}))}; }
      if(fn==="redeem_invite"){ const code=args.code; if(!uid()) return {data:"not_signed_in"}; if(!(code in invites)) return {data:"invalid"}; if(invites[code]) return {data:"used"}; invites[code]=uid(); const inv=db.invites.find(i=>i.code===code); if(inv){ inv.used_by=uid(); inv.used_at=new Date().toISOString(); } db.profiles.find(p=>p.id===uid()).role="editor"; return {data:"ok"}; }
      if(fn==="open_conversation"){ const other=args.other; if(!uid()) return {error:{message:"not signed in"}}; const [a,b]=[uid(),other].sort(); let c=db.conversations.find(c=>c.user_a===a&&c.user_b===b);
        const meP=db.profiles.find(p=>p.id===uid()), oP=db.profiles.find(p=>p.id===other);
        if(!c && meP && meP.banned) return {error:{message:"banned"}};
        if(!c && (!oP || oP.banned || !(meP&&meP.is_admin || db.editor_profiles.some(e=>e.id===other&&e.is_public) || db.jobs.some(j=>j.owner===other&&j.status==="open")))) return {error:{message:"not_available"}};
        if(!c){ c={id:uuid(),user_a:a,user_b:b,created_at:new Date().toISOString(),last_message_at:new Date().toISOString()}; db.conversations.push(c); } return {data:c.id}; }
      const me=()=>db.profiles.find(p=>p.id===uid()); const adm=()=>me()&&me().is_admin;
      const purge=(t)=>{ const p0=db.profiles.find(p=>p.id===t); if(p0&&(p0.banned||db.user_flags.some(f=>f.user_id===t))){ const note=db.user_flags.filter(f=>f.user_id===t).map(f=>f.kind+': '+f.reason).join(' | ')||'banned'; db.user_identifiers.filter(i=>i.user_id===t).forEach(i=>db.deleted_user_identifiers.push({id:uuid(),kind:i.kind,value_hash:i.value_hash,label:i.label,note})); } db.user_identifiers=db.user_identifiers.filter(i=>i.user_id!==t); db.user_flags=db.user_flags.filter(f=>f.user_id!==t); db.reviews=db.reviews.filter(r=>r.client!==t&&r.editor!==t); db.messages=db.messages.filter(m=>m.sender!==t); db.conversations=db.conversations.filter(c=>c.user_a!==t&&c.user_b!==t); db.jobs=db.jobs.filter(j=>j.owner!==t); db.projects=db.projects.filter(p=>p.owner!==t); db.editor_profiles=db.editor_profiles.filter(e=>e.id!==t); db.profiles=db.profiles.filter(p=>p.id!==t); for(const e in users) if(users[e].id===t) delete users[e]; };
      if(fn==="payout_info"){ const ed=args.ed; if(!uid()) return {data:null}; const ok=uid()===ed||db.contracts.some(k=>k.editor===ed&&k.client===uid()&&(k.payment_mode||"direct")==="direct"&&["accepted","paid_marked","paid","completed"].includes(k.status)); if(!ok) return {data:null}; const p=db.payout_details.find(x=>x.id===ed); return {data:p?{methods:p.methods,note:p.note}:null}; }
      if(fn==="propose_contract"){ const cv=db.conversations.find(c=>c.id===args.conv&&(c.user_a===uid()||c.user_b===uid())); if(!cv) return {error:{message:"not your conversation"}}; const isEd=id=>(db.profiles.find(p=>p.id===id)||{}).role==="editor"; let ed,cl; if(isEd(cv.user_a)&&!isEd(cv.user_b)){ed=cv.user_a;cl=cv.user_b;} else if(isEd(cv.user_b)&&!isEd(cv.user_a)){ed=cv.user_b;cl=cv.user_a;} else if(isEd(cv.user_a)&&isEd(cv.user_b)){ cl=uid(); ed=uid()===cv.user_a?cv.user_b:cv.user_a; } else return {error:{message:"no editor in this conversation"}}; if(db.contracts.some(x=>x.conversation_id===args.conv&&["proposed","accepted","paid_marked","paid","funded","delivered","disputed"].includes(x.status))) return {error:{message:"active_contract_exists"}}; const c={id:uuid(),conversation_id:args.conv,editor:ed,client:cl,proposed_by:uid(),title:args.title,description:args.description||"",price:args.price,currency:"EUR",pricing:args.pricing||"project",deadline:args.deadline,revisions:args.revisions==null?2:args.revisions,status:"proposed",payment_mode:args.mode==="escrow"?"escrow":"direct",amount_cents:Math.round(args.price*100),created_at:new Date().toISOString()}; db.contracts.push(c); evt(c,"proposed"); return {data:c.id}; }
      if(fn==="contract_action"){ const c=db.contracts.find(x=>x.id===args.cid&&(x.editor===uid()||x.client===uid())); if(!c) return {data:"not_found"}; const a=args.action, me=uid(); const no={data:"not_allowed"};
        if(a==="accept"){ if(c.status!=="proposed"||c.proposed_by===me) return no; c.status="accepted"; }
        else if(a==="decline"){ if(c.status!=="proposed"||c.proposed_by===me) return no; c.status="declined"; }
        else if(a==="cancel"){ if(!["proposed","accepted"].includes(c.status)) return no; c.status="cancelled"; }
        else if(a==="mark_paid"){ if(c.status!=="accepted"||me!==c.client) return no; c.status="paid_marked"; }
        else if(a==="confirm_paid"){ if(!["accepted","paid_marked"].includes(c.status)||me!==c.editor) return no; c.status="paid"; }
        else if(a==="complete"){ if(c.status!=="paid") return no; c.status="completed"; }
        else if(a==="deliver"){ if(c.payment_mode!=="escrow"||c.status!=="funded"||me!==c.editor) return no; c.status="delivered"; c.delivered_at=new Date().toISOString(); c.delivery_note=args.note; c.delivery_url=args.link; c.auto_release_at=new Date(Date.now()+7*86400000).toISOString(); }
        else if(a==="request_changes"){ if(c.payment_mode!=="escrow"||c.status!=="delivered"||me!==c.client) return no; c.status="funded"; c.auto_release_at=null; if(args.note) db.messages.push({id:uuid(),conversation_id:c.conversation_id,sender:me,kind:"change_request",body:args.note,created_at:new Date().toISOString()}); }
        else if(a==="dispute"){ if(c.payment_mode!=="escrow"||!["funded","delivered"].includes(c.status)) return no; c.status="disputed"; c.dispute_by=me; c.dispute_reason=args.note; c.disputed_at=new Date().toISOString(); }
        else return {data:"bad_action"};
        evt(c,a); return {data:"ok"}; }
      if(fn==="admin_flag_user"){ if(!adm()) return {data:"forbidden"}; db.user_flags.push({id:uuid(),user_id:args.target,kind:args.kind||"other",reason:args.reason||"",contract_id:args.contract||null,created_by:uid(),created_at:new Date().toISOString()}); return {data:"ok"}; }
      if(fn==="admin_unflag"){ if(!adm()) return {data:"forbidden"}; db.user_flags=db.user_flags.filter(f=>f.id!==args.flag); return {data:"ok"}; }
      if(fn==="admin_list_bad_actors"){ if(!adm()) return {data:[]}; return {data: db.profiles.filter(p=>p.banned||db.user_flags.some(f=>f.user_id===p.id)).map(p=>{ const fl=db.user_flags.filter(f=>f.user_id===p.id).sort((a,b)=>b.created_at.localeCompare(a.created_at)); const e=db.editor_profiles.find(x=>x.id===p.id); const lost=db.contracts.filter(c=>c.disputed_at&&["completed","refunded"].includes(c.status)&&((c.editor===p.id&&c.resolution==="refund")||(c.client===p.id&&c.resolution==="release"))).length; const won=db.contracts.filter(c=>c.disputed_at&&["completed","refunded"].includes(c.status)&&((c.editor===p.id&&c.resolution==="release")||(c.client===p.id&&c.resolution==="refund"))).length; const open=db.contracts.filter(c=>c.status==="disputed"&&(c.editor===p.id||c.client===p.id)).length; return {...p, display_name:e?e.display_name:null, flag_count:fl.length, last_flag:fl[0]?fl[0].created_at:null, disputes_lost:lost, disputes_won:won, disputes_open:open, flags:fl, identifiers:db.user_identifiers.filter(i=>i.user_id===p.id).map(i=>({kind:i.kind,label:i.label,shared:db.user_identifiers.filter(j=>j.kind===i.kind&&j.value_hash===i.value_hash&&j.user_id!==p.id).length}))}; })}; }
      if(fn==="editor_can_receive"){ const p=db.payout_details.find(x=>x.id===args.ed); return {data:!!(p&&p.stripe_payouts_enabled)}; }
      if(fn==="admin_list_contracts"){ if(!adm()) return {data:[]}; return {data: db.contracts.map(c=>({...c, editor_name:(db.editor_profiles.find(e=>e.id===c.editor)||{}).display_name, client_name:(db.profiles.find(p=>p.id===c.client)||{}).first_name})).sort((a,b)=>(b.status==="disputed")-(a.status==="disputed"))}; }
      if(fn==="can_review"){ const ed=args.ed; return {data: !!uid() && uid()!==ed && db.profiles.some(p=>p.id===ed&&p.role==="editor") && db.conversations.some(c=>(c.user_a===uid()&&c.user_b===ed)||(c.user_b===uid()&&c.user_a===ed))}; }
      const held=(t)=>db.contracts.some(k=>(k.editor===t||k.client===t)&&["funded","delivered","disputed","releasing","resolving"].includes(k.status));
      if(fn==="delete_my_account"){ if(!uid()) return {data:"not_signed_in"}; if(held(uid())) return {data:"active_payments"}; purge(uid()); return {data:"ok"}; }
      if(fn==="admin_list_users"){ if(!adm()) return {data:[]}; return {data: db.profiles.map(p=>{ const e=db.editor_profiles.find(x=>x.id===p.id); const rv=db.reviews.filter(r=>r.editor===p.id); return {...p, display_name:e?e.display_name:null, is_public:!!(e&&e.is_public), projects:db.projects.filter(x=>x.owner===p.id).length, reviews:rv.length, avg_stars: rv.length? +(rv.reduce((a,r)=>a+r.stars,0)/rv.length).toFixed(1):null, flags:db.user_flags.filter(f=>f.user_id===p.id).length}; })}; }
      if(fn==="admin_set_ban"){ if(!adm()) return {data:"forbidden"}; if(args.target===uid()) return {data:"cannot_ban_self"}; const p=db.profiles.find(p=>p.id===args.target); p.banned=args.ban; p.ban_reason=args.ban?args.reason:null; return {data:"ok"}; }
      if(fn==="admin_delete_user"){ if(!adm()) return {data:"forbidden"}; if(args.target===uid()) return {data:"cannot_delete_self"}; if(held(args.target)) return {data:"active_payments"}; purge(args.target); return {data:"ok"}; }
      if(fn==="admin_set_role"){ if(!adm()) return {data:"forbidden"}; db.profiles.find(p=>p.id===args.target).role=args.new_role; return {data:"ok"}; }
      if(fn==="admin_create_invite"){ if(!adm()) return {error:{message:"forbidden"}}; const code="CUV-"+Math.random().toString(36).slice(2,6).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(); invites[code]=null; db.invites.push({code_hash:"h"+code,label:code.slice(0,8)+"****",note:args.note,created_at:new Date().toISOString(),used_at:null,used_by:null,code}); return {data:code}; }
      if(fn==="admin_list_invites"){ if(!adm()) return {data:[]}; return {data: db.invites.map(i=>({...i, used_by_name: i.used_by? (db.profiles.find(p=>p.id===i.used_by)||{}).first_name : null}))}; }
      if(fn==="admin_delete_invite"){ if(!adm()) return {data:"forbidden"}; const i=db.invites.find(x=>x.code_hash===args.hash); if(i&&!i.used_by){ db.invites=db.invites.filter(x=>x!==i); delete invites[i.code]; } return {data:"ok"}; }
      if(fn==="admin_list_reviews"){ if(!adm()) return {data:[]}; return {data: db.reviews.map(r=>({...r, editor_name:(db.editor_profiles.find(e=>e.id===r.editor)||{}).display_name, client_name:(db.profiles.find(p=>p.id===r.client)||{}).first_name}))}; }
      return {data:null,error:{message:"unknown rpc"}};
    },
    channel(name){ const ch={ handlers:[], on(ev,cfg,fn){ ch.handlers.push({cfg,fn}); return ch; }, subscribe(){ channels.push(ch); return ch; }, fire(event,table,row){ ch.handlers.forEach(h=>{ if(h.cfg.table===table && h.cfg.event===event){ const f=h.cfg.filter; if(!f || f===`conversation_id=eq.${row.conversation_id}`) h.fn({new:row}); } }); } }; return ch; },
    removeChannel(ch){ const i=channels.indexOf(ch); if(i>=0) channels.splice(i,1); },
    storage:{ from(){ return { async upload(path){ return {error:null,data:{path}}; }, getPublicUrl(path){ return {data:{publicUrl:"https://storage.test/"+path}}; } }; } }
  };
  window.__mockdb = db;
  window.__mockEscrow = false; const FAKE_STRIPE={ transfers:[], refunds:[] }; window.__fakeStripe=FAKE_STRIPE;
  const realFetch = window.fetch.bind(window);
  window.fetch = async (url, init={}) => {
    const u=String(url); if(!u.includes("/.netlify/functions/")) return realFetch(url, init);
    const name=u.split("/.netlify/functions/")[1].split("?")[0]; const body=init.body?JSON.parse(init.body):{}; const method=init.method||"GET";
    const res=(status,data)=>new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json"}});
    const me=uid()?db.profiles.find(p=>p.id===uid()):null;
    if(name==="stripe-status") return res(200,{escrow:window.__mockEscrow,feePercent:3,feeFixedCents:25,autoReleaseDays:7});
    if(!window.__mockEscrow) return res(503,{error:"Escrow payments are not configured yet"});
    if(!me) return res(401,{error:"Sign in first"});
    if(name==="stripe-connect"){ if(me.role!=="editor") return res(403,{error:"Only editors"}); let p=db.payout_details.find(x=>x.id===me.id); if(method==="GET") return res(200,{connected:!!(p&&p.stripe_account_id),payouts_enabled:!!(p&&p.stripe_payouts_enabled)}); if(!p){ p={id:me.id,methods:[],note:""}; db.payout_details.push(p);} p.stripe_account_id=p.stripe_account_id||"acct_"+me.id.slice(0,6); p.stripe_payouts_enabled=true; /* pretend onboarding completes instantly */ return res(200,{url:"#settings?stripe=return"}); }
    if(name==="stripe-checkout"){ const c=db.contracts.find(x=>x.id===body.contract_id); if(!c||c.client!==me.id) return res(403,{error:"Not your contract"}); if(c.status!=="accepted") return res(400,{error:"not accepted"}); const p=db.payout_details.find(x=>x.id===c.editor); if(!p||!p.stripe_payouts_enabled) return res(409,{error:"editor not ready"}); const fee=Math.round(c.amount_cents*0.03)+25; c.fee_cents=fee; /* simulate the webhook right away */ c.status="funded"; c.funded_at=new Date().toISOString(); c.stripe_payment_intent="pi_"+c.id.slice(0,6); evt(c,"funded"); return res(200,{url:"#contracts?paid="+c.id,amount:c.amount_cents,fee}); }
    if(name==="stripe-release"){ const c=db.contracts.find(x=>x.id===body.contract_id); if(!c||c.client!==me.id) return res(403,{error:"Not your contract"}); if(!["funded","delivered"].includes(c.status)) return res(409,{error:"nothing to release"}); FAKE_STRIPE.transfers.push({contract:c.id,amount:c.amount_cents}); c.status="completed"; c.resolution="release"; evt(c,"approve"); return res(200,{ok:true}); }
    if(name==="stripe-resolve"){ if(!me.is_admin) return res(403,{error:"Admins only"}); const c=db.contracts.find(x=>x.id===body.contract_id); if(!c||!["funded","delivered","disputed"].includes(c.status)) return res(409,{error:"not holding"}); const total=c.amount_cents; let ed=0; if(body.decision==="release") ed=total; else if(body.decision==="split") ed=Math.round(total*body.editor_percent/100); const rf=total-ed; if(ed) FAKE_STRIPE.transfers.push({contract:c.id,amount:ed}); if(rf) FAKE_STRIPE.refunds.push({contract:c.id,amount:rf}); const wasDisputed=c.status==="disputed"; c.status=ed?"completed":"refunded"; c.resolution=body.decision; c.split_editor_cents=ed; evt(c,"resolved_"+body.decision); if(wasDisputed){ const loser=body.decision==="refund"?c.editor:body.decision==="release"?c.client:null; if(loser) db.user_flags.push({id:uuid(),user_id:loser,kind:"dispute_lost",reason:"Lost dispute on \""+c.title+"\"",contract_id:c.id,created_by:me.id,created_at:new Date().toISOString()}); } if(body.note) db.messages.push({id:uuid(),conversation_id:c.conversation_id,sender:me.id,kind:"text",body:"Cuvori decision: "+body.note,created_at:new Date().toISOString()}); return res(200,{ok:true}); }
    return res(404,{error:"unknown function"});
  };
  window.supabase = { createClient(){ return client; } };
  const cfg={supabaseUrl:"https://x.supabase.co",supabaseAnonKey:"key"}; Object.defineProperty(window,"CUVORI_CONFIG",{get(){return cfg;},set(){}});
})();
