  // =====================================================================
  // Professions as data: the selector, the filters, the search
  // Configuration comes from profession_config() (or the built-in copy when there is no
  // database). Stable keys are identity; every label is looked up per language.
  // =====================================================================
  const PROF = { groups:[], professions:[], filters:[], byKey:{}, pfs:[], units:{}, shared:["price","languages","location","availability"], loaded:false };
  function pl(labels){ if(!labels) return ""; return labels[state.language] || labels.en || Object.values(labels)[0] || ""; }
  function profBySlug(slug){ return PROF.professions.find(p=>p.slug===slug)||null; }
  function profName(slug){ const p=profBySlug(slug); return p ? pl(p.labels) : String(slug||""); }
  function filterDef(key){ return PROF.byKey[key]||null; }
  function filterName(key){ const f=filterDef(key); return f ? pl(f.labels) : key; }
  function optName(key, opt){ const f=filterDef(key); const o=f && (f.options||[]).find(x=>x.key===opt); return o ? pl(o.labels) : (key==="video_specialty" && typeof CAT_KEYS!=="undefined" && CAT_KEYS.includes(opt) ? t(opt) : String(opt)); }
  function unitName(u){ return PROF.units[u] ? pl(PROF.units[u]) : (UNIT_TO_KEY[u] ? t(UNIT_TO_KEY[u]) : String(u||"")); }
  function applyProfConfig(cfg){
    if(!cfg) return;
    PROF.groups=cfg.groups||[]; PROF.professions=cfg.professions||[]; PROF.filters=cfg.filters||[]; PROF.pfs=cfg.profession_filters||[]; PROF.units=cfg.units||{};
    PROF.byKey={}; PROF.filters.forEach(f=>PROF.byKey[f.key]=f);
    if(cfg.shared) PROF.shared=cfg.shared;
    PROF.loaded=true;
  }
  async function loadProfessionConfig(){
    applyProfConfig(window.CUVORI_PROFESSIONS);                 // the built-in copy: instant first paint, and the whole thing in demo mode
    if(!REAL) return;
    try{ const { data, error } = await sb.rpc("profession_config"); if(!error && data && data.professions) applyProfConfig(data); }catch(e){ console.warn("profession_config", e); }
  }
  // the professions a client can pick: open for joining and with at least one public professional
  function visibleProfessions(){
    const live=PROF.professions.filter(p=>p.active && (REAL ? (p.professional_count||0)>0 : ["video-editor","videographer","photographer"].includes(p.slug)));
    return live.sort((a,b)=>(a.sort_order-b.sort_order)||a.slug.localeCompare(b.slug));
  }
  // the professions a professional can join (open for recruiting, public or not yet)
  function joinableProfessions(){ return PROF.professions.filter(p=>p.active).sort((a,b)=>a.sort_order-b.sort_order); }
  function profFilters(slug){
    if(!slug) return PROF.shared.map(k=>({ key:k, primary_filter:true, profile_field:false, def:filterDef(k) })).filter(x=>x.def);
    return PROF.pfs.filter(x=>x.profession_slug===slug).sort((a,b)=>a.sort_order-b.sort_order).map(x=>({ ...x, key:x.filter_key, def:filterDef(x.filter_key) })).filter(x=>x.def);
  }
  function primaryMultiKey(slug){ const f=profFilters(slug).find(x=>x.primary_filter && x.def.kind==="multi"); return f ? f.key : null; }

  // ---------- search state ----------
  state.ps = { profession:null, q:"", f:{} };
  function psSet(key, value){ const f={...state.ps.f}; if(value==null || (Array.isArray(value)&&!value.length) || value===false || value==="") delete f[key]; else f[key]=value; state.ps.f=f; }
  function psToggleOpt(key, opt){ const cur=(state.ps.f[key]||[]).slice(); const i=cur.indexOf(opt); if(i>=0) cur.splice(i,1); else cur.push(opt); psSet(key, cur); }
  function psHasOpt(key, opt){ return (state.ps.f[key]||[]).includes(opt); }
  function psActiveCount(){ return Object.keys(state.ps.f).length + (state.ps.q ? 1 : 0); }
  function setProfession(slug, opts){
    slug = slug && profBySlug(slug) ? slug : null;
    if(state.ps.profession!==slug){ state.ps.profession=slug; state.ps.f={}; }   // filters belong to a profession; changing it clears them
    renderFilterBar();
    if(!(opts&&opts.silent)) runProfileSearch();
    if(!(opts&&opts.noRoute)){ const h=slug?"#professionals/"+slug:"#home"; if(location.hash!==h) history.replaceState(null,"",h); }
  }

  // ---------- the bar: profession row + chips ----------
  const PRICE_BANDS=[[0,30],[30,60],[60,null]];
  function priceBandLabel([lo,hi]){ return hi==null ? "€"+lo+"+" : (lo===0 ? "≤ €"+hi : "€"+lo+"–"+hi); }
  function renderFilterBar(){
    const row=$("#profRow"), chips=$("#filterRow"); if(!row||!chips) return;
    const vis=visibleProfessions();
    row.innerHTML = `<span class="filter-label">${escapeHtml(t("pf_who"))}</span>` +
      `<button class="chip prof-chip${state.ps.profession?"":" selected"}" data-prof="">${escapeHtml(t("pf_all"))}</button>` +
      vis.map(p=>`<button class="chip prof-chip${state.ps.profession===p.slug?" selected":""}" data-prof="${escapeHtml(p.slug)}">${escapeHtml(pl(p.labels))}</button>`).join("");
    $$(".prof-chip",row).forEach(b=>b.addEventListener("click",()=>setProfession(b.dataset.prof||null)));
    const parts=[];
    for(const x of profFilters(state.ps.profession)){
      if(!x.primary_filter) continue; const d=x.def;
      if(d.kind==="availability") parts.push(`<button class="chip${state.ps.f.availability==="open"?" selected":""}" data-fk="availability" data-fv="open">${escapeHtml(t("av_filterOpen"))}</button>`);
      else if(d.kind==="price") parts.push(...PRICE_BANDS.map(b=>{ const cur=state.ps.f.price; const on=cur && cur.min===b[0] && (cur.max??null)===(b[1]??null) && !cur.unit; return `<button class="chip${on?" selected":""}" data-fk="price" data-fv="${b[0]}-${b[1]??""}">${escapeHtml(priceBandLabel(b))}</button>`; }));
      else if(d.kind==="bool") parts.push(`<button class="chip${state.ps.f[d.key]?" selected":""}" data-fk="${escapeHtml(d.key)}" data-fv="1">${escapeHtml(pl(d.labels))}</button>`);
      else if(d.kind==="multi") parts.push(...(d.options||[]).slice(0,8).map(o=>`<button class="chip${psHasOpt(d.key,o.key)?" selected":""}" data-fk="${escapeHtml(d.key)}" data-fv="${escapeHtml(o.key)}">${escapeHtml(pl(o.labels))}</button>`));
    }
    const n=psActiveCount();
    chips.innerHTML = `<span class="filter-label">${escapeHtml(t("addFiltersLabel"))}</span>` + parts.join("") +
      `<button class="chip link" id="allFiltersBtn"><span>${escapeHtml(t("allFilters"))}</span> +${n?` <b class="chip-count">${n}</b>`:""}</button>` +
      (n?`<button class="chip link" id="clearFiltersBtn">${escapeHtml(t("pf_clear"))}</button>`:"");
    $$("[data-fk]",chips).forEach(b=>b.addEventListener("click",()=>{
      const k=b.dataset.fk, v=b.dataset.fv, d=filterDef(k);
      if(k==="availability") psSet("availability", state.ps.f.availability==="open"?null:"open");
      else if(k==="price"){ const [lo,hi]=v.split("-"); const cur=state.ps.f.price; const same=cur&&cur.min===+lo&&(cur.max??null)===(hi===""?null:+hi); psSet("price", same?null:{min:+lo, max:hi===""?null:+hi}); }
      else if(d&&d.kind==="bool") psSet(k, !state.ps.f[k]);
      else psToggleOpt(k, v);
      renderFilterBar(); runProfileSearch();
    }));
    $("#allFiltersBtn",chips).addEventListener("click",openAllFilters);
    $("#clearFiltersBtn",chips)?.addEventListener("click",()=>{ state.ps.f={}; state.ps.q=""; const s=$("#homeSearch"); if(s) s.value=""; renderFilterBar(); runProfileSearch(); });
  }

  // ---------- "View all filters": every filter the profession has, drawn from its definition ----------
  function openAllFilters(){
    const prof=state.ps.profession; const p=profBySlug(prof); const list=profFilters(prof);
    const units=p ? p.pricing_units : Object.keys(PROF.units);
    const f=state.ps.f;
    const block=(title, inner)=>`<div class="fblock"><strong>${escapeHtml(title)}</strong>${inner}</div>`;
    const html=list.map(x=>{ const d=x.def, k=d.key;
      if(d.kind==="price"){ const pr=f.price||{}; return block(pl(d.labels), `<div class="frow"><input type="number" min="0" id="fPriceMin" placeholder="${escapeHtml(t("pf_min"))}" value="${pr.min??""}"><span>–</span><input type="number" min="0" id="fPriceMax" placeholder="${escapeHtml(t("pf_max"))}" value="${pr.max??""}"><select id="fPriceUnit"><option value="">${escapeHtml(t("pf_anyUnit"))}</option>${units.map(u=>`<option value="${u}" ${pr.unit===u?"selected":""}>${escapeHtml(unitName(u))}</option>`).join("")}</select></div>`); }
      if(d.kind==="languages") return block(pl(d.labels), `<div class="chips" style="justify-content:flex-start">${(d.options||[]).map(o=>`<button type="button" class="chip fopt${psHasOpt(k,o.key)?" selected":""}" data-k="${k}" data-v="${escapeHtml(o.key)}">${escapeHtml(pl(o.labels))}</button>`).join("")}</div>`);
      if(d.kind==="location"){ const l=f.location||{}; return block(pl(d.labels), `<div class="frow"><input id="fCountry" placeholder="${escapeHtml(t("d_country"))}" value="${escapeHtml(l.country||"")}"><input id="fCity" placeholder="${escapeHtml(t("d_city"))}" value="${escapeHtml(l.city||"")}"></div>`); }
      if(d.kind==="availability") return block(pl(d.labels), `<label class="switch-row" style="border:0;padding:6px 0"><span>${escapeHtml(t("av_filterOpen"))}</span><input type="checkbox" class="switch fbool" data-k="availability" ${f.availability==="open"?"checked":""}></label>`);
      if(d.kind==="bool") return block(pl(d.labels), `<label class="switch-row" style="border:0;padding:6px 0"><span>${escapeHtml(pl(d.labels))}</span><input type="checkbox" class="switch fbool" data-k="${k}" ${f[k]?"checked":""}></label>`);
      if(d.kind==="multi") return block(pl(d.labels), `<div class="chips" style="justify-content:flex-start">${(d.options||[]).map(o=>`<button type="button" class="chip fopt${psHasOpt(k,o.key)?" selected":""}" data-k="${k}" data-v="${escapeHtml(o.key)}">${escapeHtml(pl(o.labels))}</button>`).join("")}</div>`);
      if(d.kind==="single") return block(pl(d.labels), `<div class="chips" style="justify-content:flex-start">${(d.options||[]).map(o=>`<button type="button" class="chip fone${f[k]===o.key?" selected":""}" data-k="${k}" data-v="${escapeHtml(o.key)}">${escapeHtml(pl(o.labels))}</button>`).join("")}</div>`);
      if(d.kind==="range"){ const r=f[k]||{}; return block(pl(d.labels)+(d.unit?" ("+escapeHtml(d.unit)+")":""), `<div class="frow"><input type="number" class="frange" data-k="${k}" data-b="min" min="${d.min_value??0}" max="${d.max_value??""}" placeholder="${escapeHtml(t("pf_min"))}" value="${r.min??""}"><span>–</span><input type="number" class="frange" data-k="${k}" data-b="max" min="${d.min_value??0}" max="${d.max_value??""}" placeholder="${escapeHtml(t("pf_max"))}" value="${r.max??""}"></div>`); }
      if(d.kind==="tags") return block(pl(d.labels), `<input class="ftags" data-k="${k}" placeholder="${escapeHtml(t("pf_tagsPh"))}" value="${escapeHtml((f[k]||[]).join(", "))}">`);
      return "";
    }).join("");
    openModal(t("allFiltersModalTitle") + (p ? " · " + pl(p.labels) : ""), html +
      `<div class="two-col" style="gap:8px;margin-top:16px"><button class="primary" id="applyFilters">${escapeHtml(t("applyFiltersBtn"))}</button><button class="secondary" id="resetFilters">${escapeHtml(t("pf_clear"))}</button></div>`, root=>{
        $$(".fopt",root).forEach(b=>b.addEventListener("click",()=>b.classList.toggle("selected")));
        $$(".fone",root).forEach(b=>b.addEventListener("click",()=>{ const on=b.classList.contains("selected"); $$(`.fone[data-k="${b.dataset.k}"]`,root).forEach(x=>x.classList.remove("selected")); if(!on) b.classList.add("selected"); }));
        $("#resetFilters",root).addEventListener("click",()=>{ state.ps.f={}; closeModal(); renderFilterBar(); runProfileSearch(); });
        $("#applyFilters",root).addEventListener("click",()=>{
          const nf={};
          const pm=$("#fPriceMin",root), px=$("#fPriceMax",root), pu=$("#fPriceUnit",root);
          if(pm&&(pm.value!==""||px.value!==""||pu.value)){ const o={}; if(pm.value!=="") o.min=Math.max(0,+pm.value); if(px.value!=="") o.max=Math.max(0,+px.value); if(pu.value) o.unit=pu.value; if(Object.keys(o).length) nf.price=o; }
          const byK={}; $$(".fopt.selected",root).forEach(b=>{ (byK[b.dataset.k]=byK[b.dataset.k]||[]).push(b.dataset.v); }); Object.assign(nf, byK);
          $$(".fone.selected",root).forEach(b=>{ nf[b.dataset.k]=b.dataset.v; });
          const co=$("#fCountry",root), ci=$("#fCity",root); if(co&&(co.value.trim()||ci.value.trim())) nf.location={ country:co.value.trim().slice(0,80), city:ci.value.trim().slice(0,80) };
          $$(".fbool",root).forEach(c=>{ if(!c.checked) return; if(c.dataset.k==="availability") nf.availability="open"; else nf[c.dataset.k]=true; });
          const rg={}; $$(".frange",root).forEach(i=>{ if(i.value==="") return; (rg[i.dataset.k]=rg[i.dataset.k]||{})[i.dataset.b]=+i.value; }); Object.assign(nf, rg);
          $$(".ftags",root).forEach(i=>{ const v=i.value.split(",").map(s=>s.trim()).filter(Boolean).slice(0,10); if(v.length) nf[i.dataset.k]=v; });
          state.ps.f=nf; closeModal(); renderFilterBar(); runProfileSearch();
        });
      }, "wide");
  }

  // ---------- the search box understands professions, options and languages ----------
  function parseSearch(raw){
    let q=" "+String(raw||"").toLowerCase().replace(/\s+/g," ").trim()+" ";
    const out={ profession:null, f:{}, q:"" };
    const eat=(needle)=>{ const n=" "+needle.toLowerCase()+" "; if(q.includes(n)){ q=q.replace(n," "); return true; } return false; };
    const cands=visibleProfessions().flatMap(p=>[...Object.values(p.labels||{}), ...(p.synonyms||[])].map(s=>[s,p.slug])).sort((a,b)=>b[0].length-a[0].length);
    for(const [name,slug] of cands){ if(name && eat(name)){ out.profession=slug; break; } }
    const prof=out.profession||state.ps.profession;
    // an option matches on its whole label, or on a word of it: "wedding" finds "Weddings & events"
    const words=s=>String(s).toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(w=>w.length>=4);
    for(const x of profFilters(prof)){ const d=x.def; if(d.kind!=="multi"&&d.kind!=="languages") continue;
      for(const o of (d.options||[])){ const names=[...new Set(Object.values(o.labels||{}))];
        let hit=names.some(n=>n&&eat(n));
        if(!hit){ const lw=new Set(names.flatMap(words)); for(const tok of words(q)){ if([...lw].some(w=>w===tok||w.startsWith(tok)||tok.startsWith(w))){ eat(tok); hit=true; break; } } }
        if(hit) (out.f[d.key]=out.f[d.key]||[]).push(o.key); } }
    out.q=q.trim();
    return out;
  }
  function submitSearch(){
    const parsed=parseSearch($("#homeSearch").value);
    if(parsed.profession && parsed.profession!==state.ps.profession) setProfession(parsed.profession,{silent:true,noRoute:false});
    Object.entries(parsed.f).forEach(([k,v])=>psSet(k, [...new Set([...(state.ps.f[k]||[]), ...v])]));
    state.ps.q=parsed.q; $("#homeSearch").value=parsed.q;
    renderFilterBar(); runProfileSearch();
  }

  // ---------- running the search ----------
  let psTimer=null, psSeq=0;
  function runProfileSearch(){
    const box=$("#homeSearch"); if(box) state.ps.q=box.value.trim();
    runDemoSearch();                                   // the sample cards, when no real professional is public yet
    if(!REAL) return;
    clearTimeout(psTimer); psTimer=setTimeout(runRealSearch, 120);
  }
  function svcFromRow(r){ return { id:r.service_id, profile_id:r.profile_id, profession_slug:r.profession_slug, rate_amount:r.rate_amount, rate_unit:r.rate_unit, headline:r.headline||"", values:r.values||{} }; }
  function editorFromRow(r){ return { id:r.profile_id, display_name:r.display_name, role_label:r.role_label, city:r.city, country:r.country, languages:r.languages||[], bio:r.bio, tools:r.tools||[], specializations:r.specializations||[], credentials:r.credentials, responds_hours:r.responds_hours, turnaround_days:r.turnaround_days, revisions:r.revisions, availability:r.availability, free_from:r.free_from, availability_set_at:r.availability_set_at, last_active_on:r.last_active_on, is_public:r.is_public, created_at:r.created_at, rate_amount:r.rate_amount, rate_unit:r.rate_unit }; }
  function attachService(p, svc){ p.services=p.services||[]; const i=p.services.findIndex(s=>s.profession_slug===svc.profession_slug); if(i>=0) p.services[i]=svc; else p.services.push(svc); }
  async function runRealSearch(){
    const seq=++psSeq;
    const { data, error } = await sb.rpc("search_professionals", { p_profession:state.ps.profession, p_filters:state.ps.f, p_q:state.ps.q, p_limit:60, p_offset:0 });
    if(seq!==psSeq) return;                            // a newer search finished first
    if(error){ console.error(error); return; }
    const rows=data||[]; const ids=[...new Set(rows.map(r=>r.profile_id))];
    let projects=[]; if(ids.length){ const { data:pj } = await sb.from("projects").select("*").in("owner",ids).order("position"); projects=pj||[]; }
    if(seq!==psSeq) return;
    const keys=[];
    rows.forEach(r=>{ const key="u:"+r.profile_id; const prev=PROFILES[key]; const p=rowToProfile(editorFromRow(r), projects.filter(x=>x.owner===r.profile_id));
      if(prev&&prev.services) p.services=prev.services; if(prev&&prev.reviews&&prev.reviews.length){ p.reviews=prev.reviews; }
      attachService(p, svcFromRow(r)); p.rating=r.rating!=null?Number(r.rating).toFixed(1):"–"; p.reviewCount=Number(r.review_count)||0;
      PROFILES[key]=p; state.people[r.profile_id]={name:r.display_name}; if(!keys.includes(key)) keys.push(key); });
    state.searchKeys=keys; state.searchTotal=rows.length?Number(rows[0].total_count):0;
    renderRealCards();
    if(!rows.length && psActiveCount()) renderEmptyState(); else $("#emptyState")?.remove();
  }
  // the service a card should speak for: the chosen profession's, else the main one
  function svcFor(p){ const list=p.services||[]; if(!list.length) return null; return list.find(s=>s.profession_slug===state.ps.profession) || list.slice().sort((a,b)=>(a.sort_order||0)-(b.sort_order||0))[0]; }
  function svcPrice(p){ const s=svcFor(p); const amt=s?s.rate_amount:(p.raw||{}).rate_amount; const unit=s?s.rate_unit:(p.raw||{}).rate_unit||"hour";
    return { text: amt!=null ? "€"+Number(amt).toLocaleString("en-US",{maximumFractionDigits:2}) : "—", unit, unitText: unitName(unit) }; }
  function svcSpecs(p){ const s=svcFor(p); if(!s) return (p.specs||[]).map(k=>({key:k,label:catLabel(k)}));
    const mk=primaryMultiKey(s.profession_slug); const vals=mk ? (s.values[mk]||[]) : []; return vals.map(k=>({key:k,label:optName(mk,k)})); }

  // ---------- an honest empty state ----------
  async function renderEmptyState(){
    const grid=$("#profileGrid"); if(!grid) return; $("#emptyState")?.remove();
    const el=document.createElement("div"); el.id="emptyState"; el.className="empty-state"; el.style.gridColumn="1/-1";
    const chips=[]; if(state.ps.q) chips.push(["q","“"+state.ps.q+"”"]);
    for(const [k,v] of Object.entries(state.ps.f)){ let label=filterName(k); const d=filterDef(k);
      if(k==="price") label+=": "+(v.min!=null?"€"+v.min:"")+(v.max!=null?"–€"+v.max:"+")+(v.unit?" / "+unitName(v.unit):"");
      else if(k==="availability") label=t("av_filterOpen");
      else if(k==="location") label+=": "+[v.country,v.city].filter(Boolean).join(", ");
      else if(d&&(d.kind==="multi"||d.kind==="languages")) label+=": "+v.map(o=>optName(k,o)).join(", ");
      else if(d&&d.kind==="single") label+=": "+optName(k,v);
      else if(d&&d.kind==="range") label+=": "+(v.min??"")+"–"+(v.max??"");
      else if(d&&d.kind==="tags") label+=": "+v.join(", ");
      chips.push([k,label]); }
    el.innerHTML=`<strong>${escapeHtml(t("pf_noneTitle"))}</strong><p class="muted">${escapeHtml(t("pf_noneBody"))}</p>
      <div class="chips" style="justify-content:center">${chips.map(([k,l])=>`<button class="chip selected" data-drop="${escapeHtml(k)}">${escapeHtml(l)} ×</button>`).join("")}</div>
      <div id="emptyHint" class="muted small" style="margin-top:10px"></div>
      <button class="secondary" id="emptyClear" style="margin-top:12px">${escapeHtml(t("pf_clear"))}</button>`;
    grid.appendChild(el);
    const drop=k=>{ if(k==="q"){ state.ps.q=""; $("#homeSearch").value=""; } else psSet(k,null); renderFilterBar(); runProfileSearch(); };
    $$("[data-drop]",el).forEach(b=>b.addEventListener("click",()=>drop(b.dataset.drop)));
    $("#emptyClear",el).addEventListener("click",()=>{ state.ps.f={}; state.ps.q=""; $("#homeSearch").value=""; renderFilterBar(); runProfileSearch(); });
    // which single filter is doing the damage? try the search once without each, and say so
    if(!REAL || chips.length<2) return;
    let best=null;
    for(const [k] of chips){
      const f={...state.ps.f}; let q=state.ps.q; if(k==="q") q=""; else delete f[k];
      const { data } = await sb.rpc("search_professionals",{ p_profession:state.ps.profession, p_filters:f, p_q:q, p_limit:1, p_offset:0 });
      const n=(data&&data[0])?Number(data[0].total_count):0; if(n>0 && (!best||n>best.n)) best={k,n,label:chips.find(c=>c[0]===k)[1]};
    }
    const hint=$("#emptyHint",el); if(!hint) return;
    if(best){ hint.innerHTML=`${escapeHtml(fill(t("pf_tryWithout"),{f:best.label,n:best.n}))} <button class="link-btn" id="emptyDropBest">${escapeHtml(t("pf_dropIt"))}</button>`; $("#emptyDropBest",el).addEventListener("click",()=>drop(best.k)); }
    else hint.textContent=t("pf_noneEven");
  }

  // ---------- open a profile that is not in the current results ----------
  async function ensureEditorLoaded(key){
    if(PROFILES[key] || !REAL || !key.startsWith("u:")) return PROFILES[key]||null;
    const id=key.slice(2);
    const { data:row } = await sb.from("editor_profiles").select("*").eq("id",id).maybeSingle(); if(!row) return null;
    const [{ data:projects },{ data:services }] = await Promise.all([ sb.from("projects").select("*").eq("owner",id).order("position"), sb.from("services").select("*").eq("profile_id",id).order("sort_order") ]);
    const p=rowToProfile(row, projects||[]); p.services=services||[]; PROFILES[key]=p; state.people[id]={name:row.display_name};
    await loadReviewsFor([id]); return p;
  }
