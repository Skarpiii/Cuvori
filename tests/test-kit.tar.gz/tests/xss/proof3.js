const { chromium } = require('playwright'); const fs=require('fs');
const mock=fs.readFileSync(process.cwd()+'/mock-supabase.js','utf8');
const url='file://'+process.cwd()+'/index.html';
const seed=`(()=>{function go(){if(!window.__mockdb)return setTimeout(go,5);const db=window.__mockdb;
  db.profiles.push({id:'atk',email:'atk@a',first_name:'Atk',role:'editor',banned:false,created_at:'2026-01-01T00:00:00Z'});
  db.editor_profiles.push({id:'atk',display_name:'Atk',role_label:'editor',city:'X',country:'Y',languages:['English'],specializations:['catOther'],tools:['T'],
    credentials:[{kind:'course',title:'Cred',by:'By',year:2025,link:'javascript:window.__pwn=1'}],
    bio:'hi',rate_amount:10,rate_unit:'hour',is_public:true,available:true,created_at:'2026-01-01T00:00:00Z'});
}go();})();`;
(async () => {
  const b=await chromium.launch(); const ctx=await b.newContext({viewport:{width:1400,height:900}});
  await ctx.addInitScript(mock); await ctx.addInitScript(seed);
  const p=await ctx.newPage();
  await p.goto(url); await p.waitForTimeout(900);
  await p.click('.real-card'); await p.waitForTimeout(700);
  await p.click('.ep-tab[data-tab="about"]'); await p.waitForTimeout(300);
  const hrefs = await p.evaluate(()=>[...document.querySelectorAll('#page-profile a')].map(a=>a.getAttribute('href')));
  console.log('credential anchor hrefs on profile:', JSON.stringify(hrefs));
  await b.close(); process.exit(0);
})();
