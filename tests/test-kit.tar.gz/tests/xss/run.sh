#!/bin/bash
# Stored-XSS regression: each proof plants a payload in the fake database and checks nothing executes.
cd "$(dirname "$0")/../.."
fail=0
for f in tests/xss/proof*.js; do
  out=$(timeout 180 node "$f" 2>&1)
  if echo "$out" | grep -Eq '__pwn = \{"|javascript:'; then echo "FAIL $f"; echo "$out" | grep -E '__pwn|javascript' | head -5; fail=1; else echo "PASS $f"; fi
done
exit $fail
