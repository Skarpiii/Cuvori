const { chromium } = require('playwright'); const fs=require('fs');
const mock=fs.readFileSync(process.cwd()+'/mock-supabase.js','utf8');
const url='file://'+process.cwd()+'/index.html';
const seed=`(()=>{function go(){if(!window.__mockdb)return setTimeout(go,5);const db=window.__mockdb;
  db.profiles.push({id:'atk',email:'atk@a',first_name:'Atk',role:'editor',banned:false,created_at:'2026-01-01T00:00:00Z'});
  db.editor_profiles.push({id:'atk',display_name:'Atk<img src=z onerror="window.__pwn=Object.assign(window.__pwn||{},{quote:1})">',role_label:'editor',city:'X',country:'Y',languages:['English'],specializations:['catOther'],tools:['T'],credentials:[],bio:'hi',rate_amount:10,rate_unit:'hour',is_public:true,available:true,created_at:'2026-01-01T00:00:00Z'});
}go();})();`;
(async () => {
  const b=await chromium.launch(); const ctx=await b.newContext({viewport:{width:1400,height:900}});
  await ctx.addInitScript(mock); await ctx.addInitScript(seed);
  const p=await ctx.newPage();
  await p.goto(url+'#create-account'); await p.waitForTimeout(500);
  await p.fill('#suName','Vic'); await p.fill('#suEmail','vic@test.com'); await p.fill('#suPass','password123');
  await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  await p.goto(url+'#home'); await p.waitForTimeout(900);
  await p.click('.real-card'); await p.waitForTimeout(700);          // open profile
  await p.click('#epQuote'); await p.waitForTimeout(600);            // Request quote -> modal
  const pwned = await p.evaluate(()=>({...window.__pwn}));
  console.log('window.__pwn =', JSON.stringify(pwned));
  await b.close(); process.exit(0);
})();
