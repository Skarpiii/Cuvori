const { chromium } = require('playwright'); const fs=require('fs');
const mock=fs.readFileSync(process.cwd()+'/mock-supabase.js','utf8');
const url='file://'+process.cwd()+'/index.html';

// each case: a seed function body (string, runs as init script AFTER mock) + how to trigger + flag
function seedScript(rows){
  return `(()=>{ function go(){ if(!window.__mockdb){ return setTimeout(go,5); }
    const db=window.__mockdb; ${rows} }
    go(); })();`;
}

async function run(label, seedRows, opts={}){
  const b = await chromium.launch();
  const ctx = await b.newContext({viewport:{width:1400,height:900}});
  await ctx.addInitScript(mock);
  await ctx.addInitScript(seedScript(seedRows));
  const page = await ctx.newPage();
  const errs=[]; page.on('pageerror',e=>errs.push(e.message));
  await page.goto(url); await page.waitForTimeout(900);
  if(opts.nav){ await page.goto(url+opts.nav); await page.waitForTimeout(900); }
  if(opts.click){ try{ await page.click(opts.click,{timeout:3000}); await page.waitForTimeout(700);}catch(e){ errs.push('click-fail '+e.message);} }
  const pwned = await page.evaluate(()=>({...window.__pwn}));
  const html = opts.dumpSel ? await page.evaluate(s=>{const el=document.querySelector(s);return el?el.innerHTML.slice(0,400):'(no '+s+')';}, opts.dumpSel) : null;
  console.log('\\n=== '+label+' ===');
  console.log('  window.__pwn =', JSON.stringify(pwned));
  if(html) console.log('  '+opts.dumpSel+' =>', html.replace(/\\n/g,' ').slice(0,300));
  await b.close();
  return pwned;
}

(async () => {
  // ---- Case A: projects.thumb_url -> mediaStyle() unescaped inside style="background-image:url('...')" ; browse card, fires on load
  await run('A thumb_url in style attr (browse card, no click)', `
    db.profiles.push({id:'atk',email:'a@a',first_name:'Atk',role:'editor',banned:false,created_at:'2026-01-01T00:00:00Z'});
    db.editor_profiles.push({id:'atk',display_name:'Atk',role_label:'editor',city:'',country:'',languages:[],specializations:['catOther'],tools:[],credentials:[],bio:'',rate_amount:10,rate_unit:'hour',is_public:true,available:true,created_at:'2026-01-01T00:00:00Z'});
    db.projects.push({id:'pj1',owner:'atk',title:'t',category:'catOther',video_url:null,thumb_url:"x'\\\"><img src=y onerror=\\"window.__pwn=Object.assign(window.__pwn||{},{thumb:1})\\">",length_label:'',tags:[],pinned:false,position:0,created_at:'2026-01-01T00:00:00Z'});
  `, {dumpSel:'.real-card .card-gallery'});

  // ---- Case B: editor_profiles.languages[] -> profile page <span>${p.langs}</span> unescaped
  await run('B languages[] on profile page (click card)', `
    db.profiles.push({id:'atk',email:'a@a',first_name:'Atk',role:'editor',banned:false,created_at:'2026-01-01T00:00:00Z'});
    db.editor_profiles.push({id:'atk',display_name:'Atk',role_label:'editor',city:'X',country:'Y',languages:["<img src=z onerror=\\"window.__pwn=Object.assign(window.__pwn||{},{lang:1})\\">"],specializations:['catOther'],tools:[],credentials:[],bio:'',rate_amount:10,rate_unit:'hour',is_public:true,available:true,created_at:'2026-01-01T00:00:00Z'});
  `, {click:'.real-card', dumpSel:'#page-profile .fact-list'});

  // ---- Case C: editor_profiles.specializations[] -> t(k) fallthrough returns raw key -> profile page unescaped
  await run('C specializations[] via t(key) fallthrough (click card)', `
    db.profiles.push({id:'atk',email:'a@a',first_name:'Atk',role:'editor',banned:false,created_at:'2026-01-01T00:00:00Z'});
    db.editor_profiles.push({id:'atk',display_name:'Atk',role_label:'editor',city:'X',country:'Y',languages:['English'],specializations:["<img src=z onerror=\\"window.__pwn=Object.assign(window.__pwn||{},{spec:1})\\">"],tools:[],credentials:[],bio:'',rate_amount:10,rate_unit:'hour',is_public:true,available:true,created_at:'2026-01-01T00:00:00Z'});
  `, {click:'.real-card', dumpSel:'#page-profile .tag-row'});

  // ---- Case D: jobs.category -> t(j.category) fallthrough -> jobs page unescaped, fires on load
  await run('D jobs.category via t(cat) fallthrough (jobs page)', `
    db.profiles.push({id:'atk',email:'a@a',first_name:'Atk',role:'client',banned:false,created_at:'2026-01-01T00:00:00Z'});
    db.jobs.push({id:'jb1',owner:'atk',title:'Job',role_needed:'editor',category:"<img src=z onerror=\\"window.__pwn=Object.assign(window.__pwn||{},{jobcat:1})\\">",description:'d',location:'',remote:true,pricing:'project',budget:'\\u20ac1',deadline:null,status:'open',created_at:'2026-01-01T00:00:00Z'});
  `, {nav:'#jobs', dumpSel:'#jobList'});

  process.exit(0);
})();
