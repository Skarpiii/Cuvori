-- Attack harness: every test runs as a real API role (anon / authenticated with a user id),
-- its effects are rolled back, and a check (run as the owner) decides whether the attack worked.
create schema if not exists t;
drop table if exists t.results;
create table t.results (n serial, grp text, name text, ok boolean, detail text);

-- p_uid null = visitor (anon). p_check gets the attack's returned value as $1 and must return
-- TRUE when the attack SUCCEEDED (bad) / when a legitimate action WORKED (for p_expect = 'allow').
create or replace function t.try(p_grp text, p_name text, p_uid uuid, p_sql text, p_check text, p_expect text default 'block')
returns void language plpgsql as $$
declare err text; worked boolean := false; ret text; harness text;
begin
  begin
    if p_uid is null then
      execute 'set local role anon'; perform set_config('request.jwt.claim.sub', '', true);
    else
      execute 'set local role authenticated'; perform set_config('request.jwt.claim.sub', p_uid::text, true);
    end if;
    begin
      execute p_sql into ret;
    exception when others then err := sqlerrm;
    end;
    execute 'reset role'; perform set_config('request.jwt.claim.sub', '', true);
    execute p_check into worked using ret;
    raise exception 'rollback__';
  exception when others then
    if sqlerrm <> 'rollback__' then harness := sqlerrm; end if;
  end;
  execute 'reset role';
  insert into t.results (grp, name, ok, detail) values (p_grp, p_name,
    case when harness is not null then false
         when p_expect = 'block' then not coalesce(worked, false)
         else coalesce(worked, false) end,
    concat_ws(' | ', case when harness is not null then 'HARNESS: ' || harness end,
                     case when err is not null then 'error: ' || left(err, 140) end,
                     case when ret is not null then 'returned: ' || left(ret, 80) end));
end $$;

create or replace function t.u(n text) returns uuid language sql immutable as $$
  select ('00000000-0000-0000-0000-' || lpad(n, 12, '0'))::uuid $$;
grant usage on schema t to anon, authenticated;
grant execute on function t.u(text) to anon, authenticated;
