-- Actors: 101 client C1, 102 client C2, 201 editor E1 (public), 202 editor E2 (private), 203 editor E3 (public, no chats),
--         301 banned client B, 302 banned editor BE, 401 admin A, 501 newbie client N
insert into auth.users (id, email, raw_user_meta_data) values
 (t.u('101'), 'c1@t.com', '{"first_name":"Cleo"}'), (t.u('102'), 'c2@t.com', '{"first_name":"Carl"}'),
 (t.u('201'), 'e1@t.com', '{"first_name":"Eva"}'),  (t.u('202'), 'e2@t.com', '{"first_name":"Emil"}'),
 (t.u('203'), 'e3@t.com', '{"first_name":"Ena"}'),
 (t.u('301'), 'b@t.com',  '{"first_name":"Bad"}'),  (t.u('302'), 'be@t.com', '{"first_name":"BadEd"}'),
 (t.u('401'), 'admin@t.com', '{"first_name":"Admin"}'), (t.u('501'), 'new@t.com', '{"first_name":"Newbie"}');
update public.profiles set role = 'editor' where id in (t.u('201'), t.u('202'), t.u('203'), t.u('302'));
update public.profiles set banned = true, ban_reason = 'scam' where id in (t.u('301'), t.u('302'));
update public.profiles set is_admin = true where id = t.u('401');

insert into public.editor_profiles (id, display_name, is_public, rate_amount) values
 (t.u('201'), 'Eva Edits', true, 35), (t.u('202'), 'Emil Private', false, 50), (t.u('203'), 'Ena Public', true, 20), (t.u('302'), 'Bad Editor', true, 5);
insert into public.projects (id, owner, title, video_url) values ('70000000-0000-0000-0000-000000000001', t.u('201'), 'Film', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ');
insert into public.jobs (id, owner, title, status) values
 ('60000000-0000-0000-0000-000000000001', t.u('101'), 'Open job', 'open'),
 ('60000000-0000-0000-0000-000000000002', t.u('102'), 'Closed job', 'closed');

insert into public.conversations (id, user_a, user_b) values
 ('10000000-0000-0000-0000-000000000001', t.u('101'), t.u('201')),
 ('10000000-0000-0000-0000-000000000002', t.u('102'), t.u('202')),
 ('10000000-0000-0000-0000-000000000003', t.u('101'), t.u('202')),
 ('10000000-0000-0000-0000-000000000004', t.u('201'), t.u('301')),
 ('10000000-0000-0000-0000-000000000005', t.u('101'), t.u('302')),
 ('10000000-0000-0000-0000-000000000006', t.u('102'), t.u('203'));   -- opened, but nobody wrote anything
insert into public.messages (id, conversation_id, sender, kind, body, payload) values
 ('20000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', t.u('201'), 'text', 'hi from Eva', null),
 ('20000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000001', t.u('101'), 'text', 'hi from Cleo', null),
 ('20000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000001', t.u('201'), 'report', 'Cut 1',
    '{"title":"Cut 1","message":"first cut","video_url":"https://www.youtube.com/watch?v=dQw4w9WgXcQ","comments":[],"status":"new"}'),
 ('20000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000002', t.u('202'), 'text', 'private chat', null),
 ('20000000-0000-0000-0000-000000000005', '10000000-0000-0000-0000-000000000004', t.u('201'), 'text', 'hi bad', null),
 ('20000000-0000-0000-0000-000000000006', '10000000-0000-0000-0000-000000000004', t.u('301'), 'text', 'hi eva', null),
 ('20000000-0000-0000-0000-000000000007', '10000000-0000-0000-0000-000000000003', t.u('202'), 'text', 'hi cleo', null),
 ('20000000-0000-0000-0000-000000000008', '10000000-0000-0000-0000-000000000003', t.u('101'), 'text', 'hi emil', null);

-- 104 client + 205 editor: a delivered escrow contract whose paid revision rounds are used up
insert into auth.users (id, email, raw_user_meta_data) values
 (t.u('104'), 'c4@t.com', '{"first_name":"Cara"}'), (t.u('205'), 'e5@t.com', '{"first_name":"Elan"}');
update public.profiles set role = 'editor' where id = t.u('205');
insert into public.editor_profiles (id, display_name, is_public) values (t.u('205'), 'Elan Edits', true);
insert into public.conversations (id, user_a, user_b) values ('10000000-0000-0000-0000-000000000007', t.u('104'), t.u('205'));
insert into public.contracts (id, conversation_id, editor, client, proposed_by, title, price, status, payment_mode, amount_cents, fee_cents, stripe_payment_intent) values
 ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', t.u('201'), t.u('101'), t.u('201'), 'Direct job', 100, 'accepted', 'direct', 10000, 0, null),
 ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000002', t.u('202'), t.u('102'), t.u('102'), 'Proposed', 80, 'proposed', 'direct', 8000, 0, null),
 ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000003', t.u('202'), t.u('101'), t.u('202'), 'Escrow job', 100, 'funded', 'escrow', 10000, 325, 'pi_test3'),
 ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000004', t.u('201'), t.u('301'), t.u('201'), 'To banned', 50, 'proposed', 'direct', 5000, 0, null),
 ('30000000-0000-0000-0000-000000000005', '10000000-0000-0000-0000-000000000005', t.u('302'), t.u('101'), t.u('101'), 'Banned ed', 60, 'funded', 'escrow', 6000, 205, 'pi_test5'),
 ('30000000-0000-0000-0000-000000000006', '10000000-0000-0000-0000-000000000007', t.u('205'), t.u('104'), t.u('205'), 'No rounds left', 100, 'delivered', 'escrow', 10000, 325, 'pi_test6');
-- delivered, review clock running, all paid revision rounds already used up
update public.contracts set revisions = 0, changes_used = 0, delivered_at = now(), auto_release_at = now() + interval '5 days'
 where id = '30000000-0000-0000-0000-000000000006';

insert into public.reviews (editor, client, stars, body) values (t.u('201'), t.u('101'), 5, 'great');
insert into public.payout_details (id, methods, note) values
 (t.u('201'), '[{"type":"bank","details":"LT12 3456 7890 1234 5678"}]', 'pay me'),
 (t.u('202'), '[{"type":"paypal","details":"emil@pp.com"}]', '');
update public.payout_details set stripe_account_id = 'acct_1EMILEMILEMIL', stripe_payouts_enabled = true where id = t.u('202');
select public.create_invite('CUV-GOOD-0001', 'test');
insert into storage.objects (bucket_id, name, owner) values ('portfolio', '00000000-0000-0000-0000-000000000201/a.mp4', t.u('201'));
-- 35 more public editors (for spam / rate-limit tests)
insert into auth.users (id, email) select t.u((7000 + g)::text), 'bulk' || g || '@t.com' from generate_series(1, 35) g;
update public.profiles set role = 'editor' where email like 'bulk%';
insert into public.editor_profiles (id, display_name, is_public) select id, 'Bulk ' || email, true from public.profiles where email like 'bulk%';
-- a report already waiting, filed by Rasa (105), so the "what happened to mine" route can be tested
insert into auth.users (id, email, raw_user_meta_data) values (t.u('105'), 'c5@t.com', '{"first_name":"Rasa"}');
insert into public.reports (id, reporter, kind, target_kind, target_id, body) values
 ('70000000-0000-0000-0000-000000000001', t.u('105'), 'fake', 'profile', '00000000-0000-0000-0000-000000000302', 'This profile uses someone else''s showreel as its own work.');
-- an editor whose status was set long ago (for the staleness tests)
update public.editor_profiles set availability_set_at = now() - interval '100 days', last_active_on = current_date - 100 where id = t.u('202');
