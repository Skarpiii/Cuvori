#!/bin/bash
# Starts a throw-away local Postgres 16 on a unix socket (used only by these tests).
D="${PGDIR:-/tmp/cuvori-pgtest}"
mkdir -p $D && chown postgres $D
[ -f $D/data/PG_VERSION ] || su postgres -c "/usr/lib/postgresql/16/bin/initdb -D $D/data -U postgres >/dev/null"
su postgres -c "/usr/lib/postgresql/16/bin/pg_ctl -D $D/data -o '-k $D -p 5499 -c listen_addresses=' -l $D/log status >/dev/null || /usr/lib/postgresql/16/bin/pg_ctl -D $D/data -o '-k $D -p 5499 -c listen_addresses=' -l $D/log -w start >/dev/null" && echo "postgres running"
