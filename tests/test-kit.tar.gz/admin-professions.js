  // ---------- admin: professions and filters are data, edited here ----------
  async function adminLoadProfessions(){
    if(!REAL){ ADMIN.pcfg=JSON.parse(JSON.stringify(window.CUVORI_PROFESSIONS)); return; }
    const { data, error } = await sb.rpc("profession_config"); if(error) throw error; ADMIN.pcfg=data;
  }
  function renderAdminProfessions(){
    const host=$("#adminBody"); const c=ADMIN.pcfg; if(!c){ host.innerHTML="…"; return; }
    const en=l=>(l&&(l.en||Object.values(l)[0]))||"";
    const open=ADMIN.pOpen||null;
    const profs=c.professions.slice().sort((a,b)=>a.sort_order-b.sort_order);
    host.innerHTML=`
      <div class="admin-stats"><span><strong>${profs.filter(p=>p.active).length}</strong> open for joining</span><span><strong>${profs.filter(p=>p.active&&p.professional_count>0).length}</strong> visible to clients</span><span><strong>${c.filters.length}</strong> filters</span></div>
      <p class="muted small" style="margin:8px 0 14px">A profession is <b>open</b> when invited professionals may choose it. Clients only see it once at least one real, public professional offers it.</p>
      <div class="admin-table">${profs.map(p=>`
        <div class="admin-row" data-pslug="${escapeHtml(p.slug)}">
          <div class="admin-main">
            <div><strong>${escapeHtml(en(p.labels))}</strong> <span class="muted small">${escapeHtml(p.slug)} · ${escapeHtml(p.group_slug||"—")} · ${p.professional_count||0} public professional(s) · units: ${(p.pricing_units||[]).join(", ")}</span></div>
            <div class="muted small">${p.active?"open for joining":"closed"}${p.invite_only?" · invite only":" · open registration"}${p.active&&p.professional_count>0?" · <b>visible to clients</b>":""}</div>
          </div>
          <div class="admin-actions">
            <button class="link-btn" data-pact="${p.active?"close":"open"}">${p.active?"Close":"Open"}</button>
            <button class="link-btn" data-pinv="${p.invite_only?"0":"1"}">${p.invite_only?"Allow public registration":"Invite only"}</button>
            <label class="muted small">order <input type="number" class="p-sort" value="${p.sort_order}" style="width:70px;padding:4px 6px"></label>
            <button class="link-btn" data-pfilters>${open===p.slug?"Hide filters":"Filters"}</button>
          </div>
          ${open===p.slug?adminProfFiltersHtml(p):""}
        </div>`).join("")}</div>
      <div class="panel" style="margin-top:14px"><strong>Add a profession</strong>
        <div class="frow" style="margin-top:8px"><input id="npSlug" placeholder="slug, e.g. graphic-designer" maxlength="40"><input id="npName" placeholder="English name" maxlength="60"><button class="secondary" id="npAdd">Add (closed)</button></div>
        <div class="muted small" style="margin-top:6px">Add the other languages later by editing labels; English is shown until then.</div></div>
      <div class="panel" style="margin-top:14px"><strong>Filters</strong>
        <div class="muted small" style="margin:4px 0 10px">Options for the list filters. Removing an option someone still uses is refused.</div>
        ${c.filters.filter(f=>["multi","single"].includes(f.kind)).map(f=>`<div class="fblock"><strong>${escapeHtml(en(f.labels))} <span class="muted small">${escapeHtml(f.key)} · ${f.kind}${f.kind==="multi"?" · "+f.match:""}</span></strong>
          <div class="chips" style="justify-content:flex-start">${(f.options||[]).map(o=>`<span class="chip">${escapeHtml(en(o.labels))} <button class="link-btn" data-optrm="${escapeHtml(f.key)}" data-opt="${escapeHtml(o.key)}" title="remove">×</button></span>`).join("")}</div>
          <div class="frow" style="margin-top:6px"><input class="opt-key" data-f="${escapeHtml(f.key)}" placeholder="option key, e.g. drone_footage" maxlength="40"><input class="opt-name" data-f="${escapeHtml(f.key)}" placeholder="English label" maxlength="60"><button class="link-btn" data-optadd="${escapeHtml(f.key)}">Add option</button></div></div>`).join("")}
        <div class="fblock"><strong>New filter</strong><div class="frow" style="margin-top:6px"><input id="nfKey" placeholder="key, e.g. camera_brands" maxlength="40"><input id="nfName" placeholder="English name" maxlength="60"><select id="nfKind"><option value="multi">multi-select</option><option value="single">single-select</option><option value="bool">yes / no</option><option value="range">number</option><option value="tags">free tags</option></select><button class="link-btn" id="nfAdd">Add filter</button></div></div>
      </div>`;
    const rpc=async(fn,args)=>{ const { data, error } = await sb.rpc(fn,args); if(error||data!=="ok"){ toast(String((data&&data!=="ok"?data:error&&error.message)||t("a_error"))); return false; } return true; };
    const reload=async()=>{ await adminLoadProfessions(); renderAdminProfessions(); if(typeof loadProfessionConfig==="function"){ await loadProfessionConfig(); renderFilterBar(); } };
    $$("[data-pslug]",host).forEach(row=>{ const slug=row.dataset.pslug;
      row.querySelector("[data-pact]")?.addEventListener("click",async e=>{ if(await rpc("admin_set_profession",{ p_slug:slug, p_active:e.target.dataset.pact==="open" })) reload(); });
      row.querySelector("[data-pinv]")?.addEventListener("click",async e=>{ if(await rpc("admin_set_profession",{ p_slug:slug, p_invite_only:e.target.dataset.pinv==="1" })) reload(); });
      row.querySelector(".p-sort")?.addEventListener("change",async e=>{ if(await rpc("admin_set_profession",{ p_slug:slug, p_sort:Number(e.target.value)||100 })) reload(); });
      row.querySelector("[data-pfilters]")?.addEventListener("click",()=>{ ADMIN.pOpen = ADMIN.pOpen===slug ? null : slug; renderAdminProfessions(); });
      $$("[data-pfk]",row).forEach(el=>{ const key=el.dataset.pfk;
        el.querySelector("[data-pfprimary]")?.addEventListener("click",async e=>{ if(await rpc("admin_set_profession_filter",{ p_slug:slug, p_key:key, p_attached:true, p_primary:e.target.dataset.pfprimary==="1" })) reload(); });
        el.querySelector("[data-pfprofile]")?.addEventListener("click",async e=>{ if(await rpc("admin_set_profession_filter",{ p_slug:slug, p_key:key, p_attached:true, p_profile:e.target.dataset.pfprofile==="1" })) reload(); });
        el.querySelector(".pf-sort")?.addEventListener("change",async e=>{ if(await rpc("admin_set_profession_filter",{ p_slug:slug, p_key:key, p_attached:true, p_sort:Number(e.target.value)||100 })) reload(); });
        el.querySelector("[data-pfdetach]")?.addEventListener("click",async()=>{ if(await rpc("admin_set_profession_filter",{ p_slug:slug, p_key:key, p_attached:false })) reload(); });
      });
      row.querySelector("[data-pfattach]")?.addEventListener("click",async()=>{ const sel=row.querySelector(".pf-attach"); if(!sel||!sel.value) return; if(await rpc("admin_set_profession_filter",{ p_slug:slug, p_key:sel.value, p_attached:true, p_primary:false, p_sort:900 })) reload(); });
    });
    $("#npAdd",host)?.addEventListener("click",async()=>{ const slug=$("#npSlug",host).value.trim().toLowerCase(), name=$("#npName",host).value.trim(); if(!/^[a-z0-9-]{2,40}$/.test(slug)||!name){ toast("slug: lowercase letters, digits and dashes; and a name"); return; } if(await rpc("admin_set_profession",{ p_slug:slug, p_active:false, p_labels:{ en:name } })) reload(); });
    $$("[data-optadd]",host).forEach(b=>b.addEventListener("click",async()=>{ const f=b.dataset.optadd; const key=$(`.opt-key[data-f="${f}"]`,host).value.trim(), name=$(`.opt-name[data-f="${f}"]`,host).value.trim(); if(!/^[A-Za-z0-9_]{1,40}$/.test(key)||!name){ toast("option key: letters, digits and underscores; and a label"); return; } if(await rpc("admin_set_filter_option",{ p_key:f, p_option:key, p_labels:{ en:name } })) reload(); }));
    $$("[data-optrm]",host).forEach(b=>b.addEventListener("click",async()=>{ if(await rpc("admin_set_filter_option",{ p_key:b.dataset.optrm, p_option:b.dataset.opt, p_remove:true })) reload(); }));
    $("#nfAdd",host)?.addEventListener("click",async()=>{ const key=$("#nfKey",host).value.trim(), name=$("#nfName",host).value.trim(), kind=$("#nfKind",host).value; if(!/^[a-z0-9_]{2,40}$/.test(key)||!name){ toast("key: lowercase letters, digits and underscores; and a name"); return; } if(await rpc("admin_upsert_filter",{ p_key:key, p_kind:kind, p_labels:{ en:name } })) reload(); });
  }
  function adminProfFiltersHtml(p){
    const c=ADMIN.pcfg; const en=l=>(l&&(l.en||Object.values(l)[0]))||"";
    const attached=c.profession_filters.filter(x=>x.profession_slug===p.slug).sort((a,b)=>a.sort_order-b.sort_order);
    const free=c.filters.filter(f=>!attached.some(a=>a.filter_key===f.key));
    return `<div style="flex-basis:100%;margin-top:8px;border-top:1px solid var(--line);padding-top:8px">
      ${attached.map(a=>{ const f=c.filters.find(x=>x.key===a.filter_key)||{labels:{}}; return `<div class="frow" data-pfk="${escapeHtml(a.filter_key)}" style="padding:4px 0">
        <span style="flex:1 1 200px"><b>${escapeHtml(en(f.labels))}</b> <span class="muted small">${escapeHtml(a.filter_key)} · ${escapeHtml(f.kind||"")}</span></span>
        <button class="link-btn" data-pfprimary="${a.primary_filter?"0":"1"}">${a.primary_filter?"primary ✓":"make primary"}</button>
        <button class="link-btn" data-pfprofile="${a.profile_field?"0":"1"}">${a.profile_field?"asked in profile ✓":"not in profile"}</button>
        <label class="muted small">order <input type="number" class="pf-sort" value="${a.sort_order}" style="width:64px;padding:4px 6px"></label>
        <button class="link-btn danger-text" data-pfdetach>detach</button></div>`; }).join("")}
      ${free.length?`<div class="frow" style="margin-top:6px"><select class="pf-attach">${free.map(f=>`<option value="${escapeHtml(f.key)}">${escapeHtml(en(f.labels))} (${escapeHtml(f.key)})</option>`).join("")}</select><button class="link-btn" data-pfattach>Attach</button></div>`:""}
    </div>`;
  }
