  // =====================================================================
  // A professional's services: shown on the profile, edited in Edit profile.
  // Every field is drawn from the profession's filter definitions, so a video editor
  // never sees photography fields and a new profession needs no new form.
  // =====================================================================
  function svcProfileFields(slug){ return profFilters(slug).filter(x=>x.profile_field && !["price","languages","location","availability"].includes(x.def.kind)); }
  function svcValueHtml(d, v){
    if(v==null || v==="" || (Array.isArray(v)&&!v.length)) return "";
    if(d.kind==="multi"||d.kind==="tags") return `<div class="skill-list">${v.map(x=>`<span class="skill">${escapeHtml(d.kind==="multi"?optName(d.key,x):x)}</span>`).join("")}</div>`;
    if(d.kind==="single") return `<span>${escapeHtml(optName(d.key,v))}</span>`;
    if(d.kind==="bool") return `<span>${escapeHtml(v?t("sv_yes"):t("sv_no"))}</span>`;
    if(d.kind==="range") return `<span>${escapeHtml(String(v))}${d.unit?" "+escapeHtml(d.unit):""}</span>`;
    return "";
  }
  function servicesPanelHtml(p){
    const list=(p.services||[]).slice().sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)); if(!list.length) return "";
    return `<div class="panel" style="margin-bottom:14px"><h3 style="margin-bottom:12px">${escapeHtml(t("sv_title"))}</h3>${list.map(s=>{
      const amt=s.rate_amount!=null?"€"+Number(s.rate_amount).toLocaleString("en-US",{maximumFractionDigits:2}):"—";
      const rows=svcProfileFields(s.profession_slug).map(x=>{ const h=svcValueHtml(x.def, s.values[x.key]); return h?`<div class="fact"><span>${escapeHtml(pl(x.def.labels))}</span><span class="fact-v">${h}</span></div>`:""; }).join("");
      return `<div class="svc-card"><div class="svc-head"><strong>${escapeHtml(profName(s.profession_slug))}</strong><span class="svc-price">${amt} <span class="muted">${escapeHtml(unitName(s.rate_unit))}</span></span></div>${s.headline?`<p class="muted" style="margin:4px 0 8px">${escapeHtml(s.headline)}</p>`:""}<div class="fact-list">${rows}</div></div>`; }).join("")}</div>`;
  }

  // ----- the editor -----
  function svcFormHtml(s, i){
    const slug=s.profession_slug; const p=profBySlug(slug); const units=p?p.pricing_units:["hour","project","day"]; const v=s.values||{};
    const fields=svcProfileFields(slug).map(x=>{ const d=x.def, k=d.key, id=`sv${i}_${k}`;
      if(d.kind==="multi") return `<div style="grid-column:1/-1"><label>${escapeHtml(pl(d.labels))}</label><div class="chips" style="justify-content:flex-start">${(d.options||[]).map(o=>`<button type="button" class="chip sv-opt${(v[k]||[]).includes(o.key)?" selected":""}" data-i="${i}" data-k="${k}" data-v="${escapeHtml(o.key)}">${escapeHtml(pl(o.labels))}</button>`).join("")}</div></div>`;
      if(d.kind==="single") return `<div><label>${escapeHtml(pl(d.labels))}</label><select class="sv-single" data-i="${i}" data-k="${k}"><option value="">—</option>${(d.options||[]).map(o=>`<option value="${escapeHtml(o.key)}" ${v[k]===o.key?"selected":""}>${escapeHtml(pl(o.labels))}</option>`).join("")}</select></div>`;
      if(d.kind==="bool") return `<div><label class="switch-row" style="border:0;padding:8px 0"><span>${escapeHtml(pl(d.labels))}</span><input type="checkbox" class="switch sv-bool" data-i="${i}" data-k="${k}" ${v[k]?"checked":""}></label></div>`;
      if(d.kind==="range") return `<div><label>${escapeHtml(pl(d.labels))}${d.unit?" ("+escapeHtml(d.unit)+")":""}</label><input type="number" class="sv-range" data-i="${i}" data-k="${k}" min="${d.min_value??0}" max="${d.max_value??""}" value="${v[k]??""}"></div>`;
      if(d.kind==="tags") return `<div style="grid-column:1/-1"><label>${escapeHtml(pl(d.labels))}</label><input class="sv-tags" data-i="${i}" data-k="${k}" maxlength="400" placeholder="${escapeHtml(t("pf_tagsPh"))}" value="${escapeHtml((v[k]||[]).join(", "))}"></div>`;
      return ""; }).join("");
    // a service that is not saved yet can still change profession; a saved one is fixed (add another instead)
    const head = s.id ? `<strong>${escapeHtml(profName(slug))}</strong>`
      : `<select class="sv-prof" data-i="${i}">${joinableProfessions().map(x=>`<option value="${escapeHtml(x.slug)}" ${x.slug===slug?"selected":""}>${escapeHtml(pl(x.labels))}</option>`).join("")}</select>`;
    return `<div class="svc-form" data-svc="${i}" data-slug="${escapeHtml(slug)}">
      <div class="svc-head">${head}<button type="button" class="link-btn sv-remove" data-i="${i}">${escapeHtml(t("sv_remove"))}</button></div>
      <div class="form-grid">
        <div><label>${escapeHtml(t("d_rate"))} (€)</label><input type="number" class="sv-rate" data-i="${i}" min="0" step="0.01" value="${s.rate_amount!=null?Number(s.rate_amount):""}"></div>
        <div><label>${escapeHtml(t("d_rateUnit"))}</label><select class="sv-unit" data-i="${i}">${units.map(u=>`<option value="${u}" ${s.rate_unit===u?"selected":""}>${escapeHtml(unitName(u))}</option>`).join("")}</select></div>
        <div style="grid-column:1/-1"><label>${escapeHtml(t("sv_headline"))}</label><input class="sv-headline" data-i="${i}" maxlength="120" placeholder="${escapeHtml(t("sv_headlinePh"))}" value="${escapeHtml(s.headline||"")}"></div>
        ${fields}
      </div></div>`;
  }
  function svcPickerHtml(existing){
    const opts=joinableProfessions().filter(p=>!existing.includes(p.slug));
    if(!opts.length) return "";
    return `<div class="svc-add"><select id="svAddSel">${opts.map(p=>`<option value="${escapeHtml(p.slug)}">${escapeHtml(pl(p.labels))}</option>`).join("")}</select><button type="button" class="secondary" id="svAddBtn">${escapeHtml(t("sv_add"))}</button></div>`;
  }
  function svcBlockHtml(services){
    const list=services.slice().sort((a,b)=>(a.sort_order||0)-(b.sort_order||0));
    return `<div style="grid-column:1/-1" id="svBlock"><label>${escapeHtml(t("sv_title"))}</label><div class="muted small" style="margin:-2px 0 8px">${escapeHtml(t("sv_hint"))}</div>
      <div id="svList">${list.map((s,i)=>svcFormHtml(s,i)).join("")||`<div class="muted small" id="svNone">${escapeHtml(t("sv_none"))}</div>`}</div>
      ${svcPickerHtml(list.map(s=>s.profession_slug))}</div>`;
  }
  function svcBind(root){
    const block=$("#svBlock",root); if(!block) return;
    block.addEventListener("change",e=>{
      const sel=e.target.closest(".sv-prof"); if(!sel) return;
      const f=sel.closest(".svc-form"); const i=+sel.dataset.i; const p=profBySlug(sel.value); if(!p) return;
      const rate=($(".sv-rate",f)||{}).value||"";
      f.outerHTML=svcFormHtml({ profession_slug:p.slug, rate_amount:rate===""?null:Number(rate), rate_unit:(p.pricing_units||["hour"])[0], headline:"", values:{}, sort_order:i }, i);
      svcRefreshPicker(root);
    });
    block.addEventListener("click",e=>{
      const opt=e.target.closest(".sv-opt"); if(opt){ opt.classList.toggle("selected"); return; }
      const rm=e.target.closest(".sv-remove"); if(rm){ const f=rm.closest(".svc-form"); if($$(".svc-form",block).length<=1){ toast(t("sv_keepOne")); return; } f.remove(); svcRefreshPicker(root); return; }
      if(e.target.closest("#svAddBtn")){ const slug=$("#svAddSel",root).value; if(!slug) return; const p=profBySlug(slug);
        const i=$$(".svc-form",block).length; $("#svNone",root)?.remove();
        $("#svList",root).insertAdjacentHTML("beforeend", svcFormHtml({ profession_slug:slug, rate_unit:(p.pricing_units||["hour"])[0], values:{}, sort_order:i }, i)); svcRefreshPicker(root); }
    });
  }
  function svcRefreshPicker(root){ const block=$("#svBlock",root); const have=$$(".svc-form",block).map(f=>f.dataset.slug); $(".svc-add",block)?.remove(); block.insertAdjacentHTML("beforeend", svcPickerHtml(have)); }
  function svcRead(root){
    return $$(".svc-form",root).map((f,idx)=>{ const slug=f.dataset.slug; const values={};
      for(const x of svcProfileFields(slug)){ const d=x.def, k=d.key;
        if(d.kind==="multi"){ const v=$$(`.sv-opt[data-k="${k}"].selected`,f).map(b=>b.dataset.v); if(v.length) values[k]=v; }
        else if(d.kind==="single"){ const v=($(`.sv-single[data-k="${k}"]`,f)||{}).value; if(v) values[k]=v; }
        else if(d.kind==="bool"){ const el=$(`.sv-bool[data-k="${k}"]`,f); if(el&&el.checked) values[k]=true; }
        else if(d.kind==="range"){ const el=$(`.sv-range[data-k="${k}"]`,f); if(el&&el.value!==""){ let n=Number(el.value); if(Number.isFinite(n)){ if(d.min_value!=null) n=Math.max(d.min_value,n); if(d.max_value!=null) n=Math.min(d.max_value,n); values[k]=Math.round(n); } } }
        else if(d.kind==="tags"){ const el=$(`.sv-tags[data-k="${k}"]`,f); const v=(el?el.value:"").split(",").map(s=>s.trim().slice(0,40)).filter(s=>s&&!/[<>]/.test(s)).slice(0,30); if(v.length) values[k]=v; } }
      const rate=($(".sv-rate",f)||{}).value; const amt=rate===""||rate==null?null:Math.min(100000,Math.max(0,Number(rate)));
      return { profession_slug:slug, rate_amount:Number.isFinite(amt)?amt:null, rate_unit:($(".sv-unit",f)||{}).value||"hour", headline:(($(".sv-headline",f)||{}).value||"").trim().slice(0,120).replace(/[<>]/g,""), values, sort_order:idx };
    });
  }
  // save: rows that exist are updated, new ones inserted, removed ones deleted
  async function svcSave(list){
    if(!REAL) return true;
    const me=myId();
    const { data:existing } = await sb.from("services").select("id,profession_slug").eq("profile_id",me);
    const have=new Map((existing||[]).map(s=>[s.profession_slug,s.id]));
    for(const s of list){
      const row={ profile_id:me, profession_slug:s.profession_slug, rate_amount:s.rate_amount, rate_unit:s.rate_unit, headline:s.headline, values:s.values, sort_order:s.sort_order, is_public:true, updated_at:new Date().toISOString() };
      const res = have.has(s.profession_slug)
        ? await sb.from("services").update({ rate_amount:row.rate_amount, rate_unit:row.rate_unit, headline:row.headline, values:row.values, sort_order:row.sort_order, updated_at:row.updated_at }).eq("id",have.get(s.profession_slug))
        : await sb.from("services").insert(row);
      if(res.error){ toast(svcErrText(res.error)); console.error(res.error); return false; }
    }
    const keep=new Set(list.map(s=>s.profession_slug));
    for(const [slug,id] of have){ if(!keep.has(slug)){ const { error } = await sb.from("services").delete().eq("id",id); if(error){ toast(errText(error)); return false; } } }
    return true;
  }
  function svcErrText(e){ const m=String((e&&e.message)||""); if(m.includes("profession_not_open")) return t("sv_notOpen"); if(m.startsWith("unknown_option")||m.startsWith("unknown_field")||m.startsWith("out_of_range")||m.startsWith("bad_")) return t("err_invalidInput"); return errText(e); }
