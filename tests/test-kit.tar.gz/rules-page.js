  // ---------- site rules, privacy notice, reports ----------
  const RULES_VERSION = "2026-09";
  const LEGAL = Object.assign({ company:"Cuvori", address:"Lithuania", email:"egidijus.cuvori@gmail.com" }, window.CUVORI_LEGAL||{});
  const RULE_SECTIONS = ["r_s1","r_s2","r_s3","r_s4","r_s5","r_s6","r_s7","r_s8","r_s9","r_s10","r_s11","r_s12","r_s13"];
  const PRIV_SECTIONS = ["pv_s1","pv_s2","pv_s3","pv_s4","pv_s5","pv_s6","pv_s7"];
  const REPORT_KINDS = [["illegal","ra_kindIllegal"],["rights","ra_kindRights"],["scam","ra_kindScam"],["abuse","ra_kindAbuse"],["fake","ra_kindFake"],["other","ra_kindOther"]];

  function legalFill(s){
    return String(s==null?"":s).replace(/\{(\w+)\}/g,(m,k)=>{
      if(k==="ver") return RULES_VERSION;
      if(k==="feePct") return ESCROW.feePercent+"%";
      if(k==="feeFixed") return "€"+(ESCROW.feeFixedCents/100).toFixed(2);
      if(k==="autoDays") return String(ESCROW.days);
      if(k==="d") return RULES_VERSION;
      return Object.prototype.hasOwnProperty.call(LEGAL,k) ? LEGAL[k] : m;
    });
  }
  // "• " starts a bullet; everything else is a paragraph
  function legalBody(txt){
    const out=[]; let ul=[];
    const flush=()=>{ if(ul.length){ out.push("<ul>"+ul.join("")+"</ul>"); ul=[]; } };
    legalFill(txt).split("\n").forEach(raw=>{
      const line=raw.trim(); if(!line) return;
      if(line.startsWith("• ")) ul.push("<li>"+escapeHtml(line.slice(2))+"</li>");
      else { flush(); out.push("<p>"+escapeHtml(line)+"</p>"); }
    });
    flush();
    return out.join("");
  }
  function legalSectionsHtml(ids){
    return ids.map(id=>`<section class="legal-s"><h2>${escapeHtml(legalFill(t(id+"_t")))}</h2>${legalBody(t(id))}</section>`).join("");
  }
  function legalPageHtml(kind){
    const isR = kind==="rules";
    const other = isR ? "privacy" : "rules";
    return `
      <div class="legal-wrap">
        <div class="legal-head">
          <h1>${escapeHtml(t(isR?"r_title":"pv_title"))}</h1>
          <p class="muted">${escapeHtml(legalFill(t(isR?"r_sub":"pv_sub")))}</p>
          <div class="legal-nav">
            <span class="legal-ver">${escapeHtml(legalFill(t("r_version")))}</span>
            <button class="link-btn" data-route="${other}">${escapeHtml(t(isR?"r_toPrivacy":"r_toRules"))}</button>
            <button class="link-btn" data-legal-print="${kind}">${escapeHtml(t("ct_pdf"))}</button>
            <button class="link-btn" data-legal-report="1">${escapeHtml(t("ra_report"))}</button>
          </div>
        </div>
        <div class="legal-doc">${legalSectionsHtml(isR?RULE_SECTIONS:PRIV_SECTIONS)}</div>
        <p class="muted small legal-imprint">${escapeHtml(legalFill(t("ra_imprint")))}</p>
      </div>`;
  }
  function renderLegalPages(){
    ["rules","privacy"].forEach(kind=>{
      const el=$("#page-"+kind); if(!el) return;
      el.innerHTML=legalPageHtml(kind);
      $$("[data-route]",el).forEach(b=>b.addEventListener("click",e=>{ e.preventDefault(); route(b.dataset.route); }));
      $$("[data-legal-print]",el).forEach(b=>b.addEventListener("click",()=>legalPrint(b.dataset.legalPrint)));
      $$("[data-legal-report]",el).forEach(b=>b.addEventListener("click",()=>reportModal("other","")));
    });
    const im=$("#footerImprint"); if(im) im.textContent=legalFill(t("ra_imprint"));
  }
  function legalPrint(kind){
    let host=$("#printDoc"); if(!host){ host=document.createElement("div"); host.id="printDoc"; document.body.append(host); }
    const isR=kind==="rules";
    host.innerHTML=`<div class="ct-doc legal-doc"><h1>${escapeHtml(t(isR?"r_title":"pv_title"))}</h1>
      <p class="muted">${escapeHtml(legalFill(t("r_version")))}</p>
      ${legalSectionsHtml(isR?RULE_SECTIONS:PRIV_SECTIONS)}
      <p class="muted">${escapeHtml(legalFill(t("ra_imprint")))}</p></div>`;
    document.body.classList.add("printing"); window.print();
    setTimeout(()=>{ document.body.classList.remove("printing"); },500);
  }

  // ----- agreeing to the rules -----
  function rulesAccepted(){ const p=state.auth&&state.auth.profile; return !!(p && p.rules_version===RULES_VERSION); }
  async function acceptRules(){
    if(!REAL){ toast(t("ra_accepted")); return true; }
    const { data, error } = await sb.rpc("accept_rules",{ v:RULES_VERSION });
    if(error||data!=="ok"){ toast(errText(error,data)); return false; }
    if(state.auth.profile) state.auth.profile.rules_version=RULES_VERSION;
    toast(t("ra_accepted")); return true;
  }
  function rulesModal(){
    if(state.rulesAsking) return; state.rulesAsking=true;
    openModal(t("ra_updatedTitle"),
      `<p>${escapeHtml(t("ra_updatedBody"))}</p>
       <p style="margin-top:10px"><button class="link-btn" data-route="rules">${escapeHtml(t("r_toRules"))}</button> · <button class="link-btn" data-route="privacy">${escapeHtml(t("r_toPrivacy"))}</button></p>
       <div class="two-col" style="gap:8px;margin-top:16px"><button class="primary" id="raYes">${escapeHtml(t("ra_accept"))}</button><button class="secondary" id="raLater">${escapeHtml(t("ra_later"))}</button></div>`,
      root=>{
        $$("[data-route]",root).forEach(b=>b.addEventListener("click",e=>{ e.preventDefault(); closeModal(); state.rulesAsking=false; route(b.dataset.route); }));
        $("#raYes",root).addEventListener("click",async()=>{ if(await acceptRules()){ closeModal(); state.rulesAsking=false; } });
        $("#raLater",root).addEventListener("click",()=>{ closeModal(); state.rulesAsking=false; route("rules"); });
      });
  }
  function maybeAskRules(){
    if(!REAL || !signedIn() || !state.auth.profile) return;
    if(rulesAccepted() || state.rulesAsking) return;
    if(state.rulesAgreedAtSignup){ state.rulesAgreedAtSignup=false; acceptRules(); return; }
    setTimeout(rulesModal, 400);
  }

  // ----- reporting a problem -----
  function reportModal(targetKind, targetId){
    if(REAL && !signedIn()){
      openModal(t("ra_reportTitle"), `<p>${escapeHtml(legalFill(t("ra_reportSignIn")))}</p>`);
      return;
    }
    const opts=REPORT_KINDS.map(([v,k])=>`<option value="${v}">${escapeHtml(t(k))}</option>`).join("");
    openModal(t("ra_reportTitle"),
      `<label>${escapeHtml(t("ra_reportKind"))}</label><select id="rpKind">${opts}</select>
       <label style="margin-top:12px;display:block">${escapeHtml(t("ra_reportWhat"))}</label>
       <textarea id="rpBody" rows="5" maxlength="4000" placeholder="${escapeHtml(t("ra_reportPh"))}"></textarea>
       <button class="primary" id="rpSend" style="margin-top:14px;width:100%">${escapeHtml(t("ra_reportSend"))}</button>
       <p class="muted small" style="margin-top:10px">${escapeHtml(legalFill(t("ra_reportSignIn")))}</p>
       <div id="rpMine" class="muted small" style="margin-top:12px"></div>`,
      root=>{
        if(REAL) sb.rpc("my_reports").then(({data})=>{
          const mine=(data||[]).slice(0,5); const box=$("#rpMine",root); if(!box||!mine.length) return;
          box.innerHTML=mine.map(r=>`<div style="border-top:1px solid var(--line);padding:6px 0">${escapeHtml(r.kind)} · ${escapeHtml(r.status)}${r.outcome?" — "+escapeHtml(r.outcome):""}</div>`).join("");
        }).catch(()=>{});
        $("#rpSend",root).addEventListener("click",async()=>{
          const body=$("#rpBody",root).value.trim(), kind=$("#rpKind",root).value;
          if(body.length<10){ toast(t("a_fillAll")); return; }
          if(!REAL){ closeModal(); toast(t("ra_reportSent")); return; }
          const { data, error } = await sb.rpc("submit_report",{ p_kind:kind, p_target_kind:targetKind||"other", p_target_id:String(targetId||"").slice(0,200), p_body:body });
          if(error||data!=="ok"){ toast(errText(error,data)); return; }
          closeModal(); toast(t("ra_reportSent"));
        });
      });
  }

  function initRules(){
    renderLegalPages();
    $("#footerReport")?.addEventListener("click",()=>reportModal("other",""));
    $("#suAgree")?.addEventListener("change",()=>{ const n=$("#authNotice"); if(n && $("#suAgree").checked) n.innerHTML=""; });
  }
