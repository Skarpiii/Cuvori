// Zasady serwisu + polityka prywatności — polski. r_* = zasady, pv_* = prywatność, ra_* = interfejs zgody.
// Treść jest zwykłym tekstem; linia zaczynająca się od "• " staje się punktem listy na stronie.
// Zmienne zachowane dokładnie: {email} {company} {address} {feePct} {feeFixed} {autoDays} {ver} {d}
({
  r_title:"Zasady Cuvori",
  r_sub:"Zasady, na które zgadza się każdy użytkownik Cuvori. Prosty język, bez drobnego druku. Za ich złamanie możesz otrzymać ostrzeżenie, zawieszenie konta lub jego usunięcie – a w poważnych przypadkach sprawa trafi też do organów ścigania lub do sądu.",
  r_version:"Wersja {ver}",
  r_toPrivacy:"Polityka prywatności",
  r_toRules:"Zasady",

  r_s1_t:"1. Czym jest Cuvori",
  r_s1:"Cuvori to miejsce, w którym klienci znajdują montażystów wideo, operatorów wideo i fotografów, ustalają zakres pracy i zapisują to w umowie.\n• Cuvori nie jest stroną umowy między klientem a montażystą, nie zatrudnia montażystów i samo nie wykonuje prac montażowych.\n• Cuvori nie obiecuje, że znajdziesz pracę, że znajdziesz kogoś do zatrudnienia, ani że praca będzie dobra. Obiecuje narzędzia: profile, wiadomości, umowy, opinie oraz – tam, gdzie włączone – płatności zabezpieczone.\n• Cuvori nie pobiera prowizji od ceny projektu. Jeśli używana jest płatność zabezpieczona, klient płaci dodatkowo opłatę {feePct}% + {feeFixed} ponad cenę; ta opłata pokrywa obsługę karty i płatności i nie jest zwracana, jeśli pieniądze zostaną później zwrócone lub podzielone.",

  r_s2_t:"2. Kto może korzystać z Cuvori",
  r_s2:"• Musisz mieć co najmniej 18 lat.\n• Używaj prawdziwego imienia i prawdziwych danych. Jedna osoba, jedno konto. Nie zakładaj konta dla kogoś innego i nie podawaj się za kogoś, kim nie jesteś.\n• Zachowaj hasło tylko dla siebie. Za to, co dzieje się na Twoim koncie, odpowiadasz Ty.\n• Jeśli działasz jako firma, zaznacz to w profilu i prowadź porządek w fakturach i podatkach. Każda strona sama rozlicza swoje podatki.",

  r_s3_t:"3. W skrócie",
  r_s3:"Bądź uczciwy, wykonaj pracę, na którą się umówiłeś, i zapłać za otrzymaną pracę. Niemal wszystko poniżej wynika właśnie z tego.",

  r_s4_t:"4. Co przesyłasz i pokazujesz",
  r_s4:"• Prawa do własnej pracy pozostają przy Tobie. Przesyłając ją, dajesz Cuvori pozwolenie na jej przechowywanie i pokazywanie na Cuvori – w Twoim profilu, w wynikach wyszukiwania i osobom, do których piszesz – tak, aby strona mogła działać. To pozwolenie kończy się, gdy usuniesz plik lub konto, z wyjątkiem kopii w kopiach zapasowych, które są usuwane w miarę ich odnawiania.\n• Potwierdzasz, że masz prawa do wszystkiego, co przesyłasz, w tym do muzyki, materiałów stockowych, czcionek i wszystkiego, co dał Ci klient, oraz że pokazywanie tego na Cuvori jest dozwolone. Jeśli naruszone zostają czyjeś prawa, odpowiada za to osoba, która to przesłała.\n• Nie przesyłaj: materiałów, do których nie masz prawa; czyichś prywatnych materiałów opublikowanych bez ich zgody; treści, które są nielegalne, brutalne, pełne nienawiści, treści seksualnych z udziałem małoletnich, lub stworzonych po to, by wprowadzać w błąd.\n• Materiał klienta nie jest Twój do publikowania. Pokazuj gotową pracę w portfolio dopiero, gdy klient sam ją opublikował, albo za zgodą klienta.\n• Jeśli ktoś zgłosi nam, że Twój przesłany materiał narusza jego prawa, możemy go usunąć. Wielokrotne przesyłanie materiału naruszającego prawa kończy się usunięciem konta.",

  r_s5_t:"5. Opinie i wiadomości",
  r_s5:"• Pisz opinie tylko o pracy, w której faktycznie brałeś udział, i pisz o tym, co naprawdę się wydarzyło.\n• Nie kupuj, nie sprzedawaj, nie wymieniaj się opiniami ani o nie nie proś, i nie groź złą opinią, by dostać coś za darmo.\n• Żadnego spamu, żadnych masowych wiadomości, i nie namawiaj do rozmów poza Cuvori, by ominąć obowiązującą tu ochronę.\n• Zachowuj kulturę. Obelgi, nękanie, groźby i dyskryminacja kończą się usunięciem konta.\n• Nie publikuj cudzych danych osobowych w wiadomościach, profilach ani opiniach.",

  r_s6_t:"6. Pieniądze",
  r_s6:"• Płatności bezpośrednie: klient płaci montażyście bezpośrednio. Cuvori nigdy nie przechowuje tych pieniędzy, nic za to nie pobiera i nie może ich dla Ciebie odzyskać, jeśli coś pójdzie nie tak – może natomiast przyjrzeć się sprawie i zapisać swoją opinię.\n• Płatności zabezpieczone: klient wpłaca środki do dostawcy płatności Cuvori, pieniądze są przechowywane i trafiają do montażysty, gdy klient zatwierdzi dostarczoną pracę, albo automatycznie po {autoDays} dniach od dostarczenia, jeśli klient nic nie zrobi. Kliknięcie „Poproś o zmiany” albo otwarcie sporu przed upływem tego czasu zatrzymuje automatyczną wypłatę; sama wiadomość na czacie tego nie robi.\n• Nie używaj płatności tutaj do przesyłania pieniędzy za coś innego niż praca ustalona na Cuvori.\n• Jeśli zamiast skorzystać ze ścieżki sporu cofniesz płatność kartą (chargeback), a ten chargeback okaże się nieuzasadniony, jesteś winien te pieniądze z powrotem, a konto zostaje zawieszone do czasu rozliczenia.\n• Wyświetlone ceny, opłaty i podatki to to, co płacisz. Jeśli coś wygląda źle, powiedz nam przed zapłatą, nie po niej.",

  r_s7_t:"7. Gdy coś pójdzie nie tak",
  r_s7:"• Najpierw porozmawiaj z drugą stroną, w czacie Cuvori, gdzie to później widać.\n• Jeśli to nie pomoże, każda ze stron może otworzyć spór. Cuvori sprawdza umowę, wiadomości i to, co zostało dostarczone, i podejmuje decyzję w ciągu 14 dni, podając powody obu stronom.\n• Gdy płatność jest zabezpieczona, Cuvori wypłaca przechowywane pieniądze zgodnie z tą decyzją: montażyście, z powrotem klientowi, albo dzieląc je odpowiednio do faktycznie wykonanej pracy. Gdy płatność była bezpośrednia, Cuvori nie może przesunąć pieniędzy – jej decyzja staje się wtedy pisemną opinią, zapisaną na obu kontach.\n• Każda ze stron może mimo to iść do sądu; to, co Cuvori już wypłaciło, jest tam brane pod uwagę.\n• Cuvori decyduje na podstawie tego, co widać na stronie. Trzymaj dostarczenia, zatwierdzenia i skargi w czacie.",

  r_s8_t:"8. Co prowadzi do usunięcia konta",
  r_s8:"• Oszustwo: branie pieniędzy bez wykonania pracy, płacenie cudzą kartą, fałszywa tożsamość, fałszywy profil, fałszywe opinie.\n• Wzięcie zaliczki i zniknięcie, albo odebranie dostarczonej pracy i odmowa zapłaty.\n• Zakładanie nowego konta, by wrócić po usunięciu.\n• Przesyłanie materiału, do którego nie masz praw, ponownie po ostrzeżeniu.\n• Groźby, nękanie, dyskryminacja, lub publikowanie czyichś prywatnych informacji.\n• Wszystko, co nielegalne, lub używanie Cuvori, by pomóc komuś innemu w czymś nielegalnym.\n• Próby zaszkodzenia stronie: ataki na nią, wykorzystywanie błędów, zbieranie (scraping) cudzych danych, automatyzacja kont.",

  r_s9_t:"9. Co się dzieje, gdy złamiesz zasady",
  r_s9:"To, co robimy, zależy od tego, co się stało i czy zdarzyło się to ponownie:\n• ostrzeżenie i prośba o naprawienie sytuacji;\n• usunięcie danej treści, zlecenia lub opinii;\n• zawieszenie konta – wtedy możesz nadal czytać i rozliczyć to, co już otwarte, ale nie możesz zaczynać niczego nowego;\n• trwałe usunięcie konta;\n• w poważnych przypadkach – oszustwo, groźby, materiały z udziałem małoletnich – zgłoszenie policji lub innemu organowi oraz dochodzenie należnych pieniędzy przed sądem.\nDowiesz się, co się stało i dlaczego, której zasady to dotyczy, i czy decyzja była automatyczna. Możesz się odwołać, pisząc na {email}, a człowiek przyjrzy się sprawie ponownie. Jeśli powodem jest obowiązek prawny lub wyraźne, poważne ryzyko dla innych osób, działamy najpierw, a wyjaśniamy zaraz potem. Pieniądze już przechowywane w ramach otwartej umowy nie są zatrzymywane z powodu zawieszenia – rozlicza się je w ramach ścieżki sporu.",

  r_s10_t:"10. Zgłaszanie problemu",
  r_s10:"• Użyj przycisku Zgłoś przy profilu, zleceniu, opinii lub wiadomości, albo napisz na {email}.\n• Opisz, na czym polega problem i gdzie się znajduje. Jeśli chodzi o prawa do treści, podaj, czym jest ta treść i jakie prawo narusza.\n• Sprawdzamy każde zgłoszenie, działamy tam, gdzie wymagają tego zasady lub prawo, i mówimy Ci, co zrobiliśmy.\n• Fałszywe i powtarzające się zgłaszanie, by zaszkodzić konkurencji, samo w sobie jest powodem utraty konta.",

  r_s11_t:"11. Za co Cuvori odpowiada, a za co nie",
  r_s11:"• Cuvori odpowiada za uczciwe i staranne prowadzenie strony, za dotrzymywanie obietnic dotyczących płatności zabezpieczonych oraz za rozpatrywanie sporów tak, jak opisano tutaj.\n• Cuvori nie odpowiada za samą pracę, za to, co ludzie do siebie piszą, za to, czy z kimś przyjemnie się współpracuje, ani za umowę podpisaną przez dwie inne osoby.\n• Strona może przestać działać, działać wolno albo się zmienić. Trzymaj własne kopie swoich plików; Cuvori nie jest usługą kopii zapasowych.\n• Tam, gdzie Cuvori ponosi wobec Ciebie odpowiedzialność, jest ona ograniczona do opłat zapłaconych na rzecz Cuvori w poprzednich 12 miesiącach, albo do 500 €, jeśli to więcej, i nie obejmuje strat pośrednich, takich jak utracony zysk. Ten limit nie obowiązuje tam, gdzie nie pozwala na to prawo – w tym przy naszym własnym umyślnym działaniu lub rażącym niedbalstwie, śmierci lub uszkodzeniu ciała, albo przy pieniądzach, które przechowujemy dla Ciebie w ramach płatności zabezpieczonej.\n• Nic w tych zasadach nie odbiera Ci praw, które przysługują Ci jako konsumentowi na mocy prawa kraju, w którym mieszkasz.",

  r_s12_t:"12. Zamknięcie konta i zmiany",
  r_s12:"• Możesz zamknąć konto w dowolnym momencie w Ustawieniach. Umowy, w których nadal przechowywane są pieniądze, muszą wcześniej zostać zakończone lub rozstrzygnięte.\n• Zamknięcie konta usuwa Twój profil, portfolio i opinie. Zapisy umów i płatności są przechowywane tak długo, jak wymaga tego prawo, a zapis o usunięciu za oszustwo lub nadużycie jest przechowywany, aby ta sama osoba nie mogła po prostu wrócić.\n• Te zasady mogą się zmieniać. Jeśli zmiana ma dla Ciebie znaczenie, ogłaszamy ją na stronie co najmniej 15 dni przed jej wejściem w życie; dalsze korzystanie z Cuvori po tym czasie oznacza, że ją akceptujesz. Jeśli nie akceptujesz – zamknij konto.\n• Numer wersji i data znajdują się na górze tej strony, a wersja, na którą się zgodziłeś, jest zapisana przy Twoim koncie.",

  r_s13_t:"13. Prawo, sądy i kim jesteśmy",
  r_s13:"• Te zasady podlegają prawu litewskiemu, a sądy litewskie mają jurysdykcję. Jeśli korzystasz z Cuvori jako konsument, zachowujesz ochronę wynikającą z prawa kraju, w którym mieszkasz, i możesz wnieść sprawę do sądów swojego kraju.\n• Spór konsumencki możesz też skierować do litewskiego Państwowego Urzędu Ochrony Praw Konsumentów albo unijnej platformy internetowego rozstrzygania sporów.\n• Cuvori prowadzi {company}, {address}. Kontakt: {email}.",

  pv_title:"Polityka prywatności",
  pv_sub:"Co Cuvori przechowuje o Tobie, dlaczego, i o co możesz poprosić. Krótko mówiąc: tylko to, czego strona potrzebuje do działania, nigdy nie sprzedawane.",
  pv_s1_t:"Kto odpowiada",
  pv_s1:"Za dane opisane tutaj odpowiada {company}, {address}. Pytania i wnioski: {email}.",
  pv_s2_t:"Co jest przechowywane i dlaczego",
  pv_s2:"• Konto: imię, e-mail, wybrany przez Ciebie język, informacja, czy jesteś klientem czy montażystą, oraz wersja zasad, na którą się zgodziłeś. Potrzebne, aby dać Ci konto – bez tego nie ma usługi.\n• Profil i portfolio: to, co piszesz o sobie, Twoje miasto i kraj, ceny, umiejętności oraz filmy i zdjęcia, które przesyłasz. Sam decydujesz, co tam umieścić, i możesz to zmienić lub usunąć.\n• Wiadomości i umowy: to, co piszecie do siebie nawzajem, warunki umowy, dostawy, daty i kwoty. Potrzebne do prowadzenia usługi i rozstrzygania sporów.\n• Płatności: przy płatnościach zabezpieczonych – kwota, status i identyfikatory ze Stripe. Numery kart nigdy nie są wysyłane do Cuvori ani przez Cuvori przechowywane – zajmuje się tym Stripe. Dane bankowe, które dodajesz do płatności bezpośrednich, są przechowywane, aby klienci, z którymi pracujesz, mogli Ci zapłacić.\n• Zapisy bezpieczeństwa: jeśli konto zostaje usunięte za oszustwo lub nadużycie, zachowujemy o tym notatkę oraz zaszyfrowane (hashowane) postacie użytego e-maila, karty, IBAN lub PayPal, aby ta sama osoba nie mogła od razu wrócić pod nowym nazwiskiem. Przechowujemy to do 24 miesięcy, albo dłużej, jeśli trwa spór lub roszczenie. To nasz uzasadniony interes w utrzymaniu bezpieczeństwa rynku; możesz się temu sprzeciwić, a my ponownie przyjrzymy się Twojej sprawie.\n• Dane techniczne: podstawowe logi serwera i błędów, przechowywane krótko ze względów bezpieczeństwa.\n• Aktywność: jeśli masz publiczny profil montażysty, widać na nim, czy przyjmujesz zlecenia i mniej więcej kiedy byłeś ostatnio aktywny (tylko data, nigdy godzina). Dzięki temu klienci wiedzą, czy warto do Ciebie pisać; możesz to ukryć, ustawiając profil jako prywatny.",
  pv_s3_t:"Kto jeszcze to widzi",
  pv_s3:"• Inni użytkownicy widzą to, co publikujesz: Twój profil, portfolio, opinie oraz to, co do nich piszesz.\n• Dostawcy usług, którzy obsługują części Cuvori: Supabase (baza danych i pliki, UE), Netlify (hosting), Cloudflare (domena i ochrona), Stripe (płatności) oraz nasz dostawca poczty e-mail. Działają zgodnie z naszymi instrukcjami.\n• Organy władzy, gdy wymaga tego prawo.\n• Nigdy nie sprzedajemy Twoich danych i nie wykorzystujemy ich do reklamy.",
  pv_s4_t:"Jak długo przechowujemy dane",
  pv_s4:"• Tak długo, jak istnieje Twoje konto, a po jego zamknięciu są usuwane – z wyjątkiem zapisów umów i płatności, które przechowujemy tak długo, jak wymaga tego prawo podatkowe i rachunkowe, oraz zapisów bezpieczeństwa opisanych powyżej.\n• Kopie zapasowe są odnawiane w ciągu 30 dni.",
  pv_s5_t:"Twoje prawa",
  pv_s5:"Możesz poprosić o kopię swoich danych, poprawić je, usunąć, sprzeciwić się sposobowi ich wykorzystania, albo poprosić, byśmy przesłali je gdzie indziej. Napisz na {email}, a odpowiemy w ciągu miesiąca. Jeśli nie jesteś zadowolony, możesz złożyć skargę do litewskiej Państwowej Inspekcji Ochrony Danych (VDAI) albo do organu w kraju, w którym mieszkasz.",
  pv_s6_t:"Pliki cookie i podobne technologie",
  pv_s6:"Cuvori nie używa reklamowych ani śledzących plików cookie. Przechowuje w Twojej przeglądarce kilka rzeczy, aby strona działała: Twoją sesję logowania i wybór języka. Wyczyszczenie danych przeglądarki je usuwa.",
  pv_s7_t:"Dzieci",
  pv_s7:"Cuvori nie jest przeznaczone dla osób poniżej 18 roku życia i świadomie nie przechowujemy o nich danych. Jeśli sądzisz, że dziecko ma konto, napisz na {email}, a my je usuniemy.",

  ra_agree:"Przeczytałem/-am zasady Cuvori i politykę prywatności i się z nimi zgadzam.",
  ra_must:"Przeczytaj zasady i zaakceptuj je, zanim założysz konto.",
  ra_rules:"zasady",
  ra_privacy:"polityka prywatności",
  ra_updatedTitle:"Zasady się zmieniły",
  ra_updatedBody:"Zaktualizowaliśmy zasady Cuvori i politykę prywatności. Przeczytaj je i potwierdź, aby kontynuować.",
  ra_accept:"Zgadzam się",
  ra_later:"Najpierw przeczytam",
  ra_accepted:"Dziękujemy – zapisano.",
  ra_report:"Zgłoś",
  ra_reportTitle:"Zgłoś problem",
  ra_reportWhat:"Na czym polega problem?",
  ra_reportKind:"Typ",
  ra_kindIllegal:"Nielegalna treść",
  ra_kindRights:"Prawa innej osoby (prawa autorskie, muzyka, materiał wideo)",
  ra_kindScam:"Oszustwo lub wyłudzenie",
  ra_kindAbuse:"Nadużycie, groźby lub nękanie",
  ra_kindFake:"Fałszywy profil lub fałszywe opinie",
  ra_kindOther:"Coś innego",
  ra_reportPh:"Co się stało i gdzie na Cuvori to jest?",
  ra_reportSend:"Wyślij zgłoszenie",
  ra_reportSent:"Zgłoszenie wysłane. Sprawdzamy każde zgłoszenie i powiemy Ci, co zrobiliśmy.",
  ra_reportSignIn:"Zaloguj się, aby coś zgłosić, albo napisz na {email}.",
  ra_banReason:"Podany powód:",
  ra_banObject:"Jeśli uważasz, że to błąd, napisz na {email}, a człowiek przyjrzy się temu ponownie.",
  ra_imprint:"Cuvori prowadzi {company}, {address} · {email}",
  ra_waiting:"Zgłoszenia oczekujące: {n}",
  ra_waitingHint:"Otwórz listę zgłoszeń i powiedz osobie, co zrobiłeś."
})
