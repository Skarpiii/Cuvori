// Svetainės taisyklės + privatumo pranešimas — lietuvių k. r_* = taisyklės, pv_* = privatumas, ra_* = sutikimo sąsaja.
// Tekstai paprasti; eilutė, prasidedanti "• ", puslapyje tampa sąrašo punktu.
// Kintamieji išsaugoti tiksliai: {email} {company} {address} {feePct} {feeFixed} {autoDays} {ver} {d}
({
  r_title:"Cuvori taisyklės",
  r_sub:"Taisyklės, kurioms sutinka visi Cuvori nariai. Paprasta kalba, jokio smulkaus šrifto. Jas pažeidus gali sulaukti įspėjimo, laikino paskyros sustabdymo ar pašalinimo, o rimtais atvejais – ir pranešimo institucijoms ar bylos teisme.",
  r_version:"Versija {ver}",
  r_toPrivacy:"Privatumo pranešimas",
  r_toRules:"Taisyklės",

  r_s1_t:"1. Kas yra Cuvori",
  r_s1:"Cuvori – tai vieta, kur klientai randa vaizdo editorius, videografus ir fotografus, susitaria dėl darbo ir tai užfiksuoja sutartyje.\n• Cuvori nėra sutarties tarp kliento ir editoriaus šalis, nesamdo editorių ir pats nedirba montavimo darbų.\n• Cuvori nežada, kad rasi darbą, rasi ką pasamdyti, ar kad darbas bus geras. Žadamos priemonės: profiliai, žinutės, sutartys, atsiliepimai ir, kur įjungta, apsaugoti mokėjimai.\n• Cuvori neima komisinio nuo projekto kainos. Kai naudojamas apsaugotas mokėjimas, klientas virš kainos moka {feePct}% + {feeFixed} mokėjimo mokestį; šis mokestis dengia kortelės ir mokėjimo apdorojimą ir negrąžinamas, jei pinigai vėliau grąžinami ar dalijami.",

  r_s2_t:"2. Kas gali naudotis Cuvori",
  r_s2:"• Tau turi būti bent 18 metų.\n• Naudok savo tikrą vardą ir tikrus duomenis. Vienas žmogus – viena paskyra. Nekurk paskyros už kitą žmogų ir neapsimesk kažkuo, kuo nesi.\n• Slaptažodį laikyk tik sau. Kas vyksta tavo paskyroje – tavo atsakomybė.\n• Jei dirbi kaip verslas, nurodyk tai profilyje ir tvarkingai vesk sąskaitas bei mokesčius. Kiekviena pusė pati tvarkosi su savo mokesčiais.",

  r_s3_t:"3. Trumpai",
  r_s3:"Būk sąžiningas, atlik darbą, dėl kurio susitarei, ir sumokėk už gautą darbą. Beveik viskas, kas toliau, išplaukia iš to.",

  r_s4_t:"4. Kas nutinka tavo įkeltam turiniui",
  r_s4:"• Teisės į savo darbą lieka tau. Įkeldamas jį suteiki Cuvori leidimą jį saugoti ir rodyti Cuvori svetainėje – tavo profilyje, paieškos rezultatuose ir tiems, kam rašai, – kad svetainė galėtų veikti. Šis leidimas baigiasi, kai ištrini failą ar paskyrą, išskyrus kopijas atsarginėse kopijose – jos ištrinamos, kai tos atsarginės kopijos atnaujinamos.\n• Patvirtini, kad turi teises į viską, ką įkeli, įskaitant muziką, archyvinę medžiagą, šriftus ir viską, ką tau davė klientas, ir kad tai rodyti Cuvori yra leidžiama. Jei taip pažeidžiamos kito asmens teisės, už tai atsako tas, kas įkėlė.\n• Neįkelk: medžiagos, kurios neturi teisės naudoti; kieno nors privačios medžiagos, paskelbtos be jo sutikimo; turinio, kuris yra neteisėtas, smurtinis, kurstantis neapykantą, kuriame yra seksualinio turinio su nepilnamečiais, ar sukurto apgauti.\n• Kliento medžiaga nėra tavo, kad galėtum ją skelbti. Baigtą darbą portfolio rodyk tik tada, kai klientas jį paskelbė pats, arba turėdamas kliento sutikimą.\n• Jei kas nors mums praneša, kad tavo įkelta medžiaga pažeidžia jo teises, galime ją pašalinti. Pakartotinai įkeliant teises pažeidžiančią medžiagą paskyra pašalinama.",

  r_s5_t:"5. Atsiliepimai ir žinutės",
  r_s5:"• Rašyk atsiliepimus tik apie darbą, kuriame tikrai dalyvavai, ir rašyk tai, kas iš tikrųjų įvyko.\n• Neperk, neparduok, nesikeisk atsiliepimais ir jų neprašyk, ir negrasink blogu atsiliepimu, norėdamas gauti ką nors nemokamai.\n• Jokio šlamšto, jokių masinių žinučių, ir nekviesk žmonių bendrauti už Cuvori ribų, kad išvengtum čia taikomos apsaugos.\n• Būk mandagus. Įžeidinėjimai, priekabiavimas, grasinimai ir diskriminacija baigiasi paskyros pašalinimu.\n• Neskelbk kitų žmonių asmens duomenų žinutėse, profiliuose ar atsiliepimuose.",

  r_s6_t:"6. Pinigai",
  r_s6:"• Tiesioginiai mokėjimai: klientas moka editoriui tiesiogiai. Cuvori niekada nelaiko šių pinigų, už tai nieko neima ir, kilus problemai, negali jų susigrąžinti už tave – tai, ką gali padaryti, tai peržiūrėti atvejį ir užfiksuoti savo nuomonę.\n• Apsaugoti mokėjimai: klientas sumoka Cuvori mokėjimo paslaugų teikėjui, pinigai laikomi ir pervedami editoriui, kai klientas patvirtina atliktą darbą, arba automatiškai po {autoDays} d. nuo pristatymo, jei klientas nieko nedaro. Paspaudus „Prašyti pakeitimų” arba pradėjus ginčą prieš pasibaigiant šiam laikotarpiui, automatinis pervedimas sustabdomas; vien žinutė pokalbyje to nesustabdo.\n• Nenaudok čia esančių mokėjimų pinigams pervesti dėl kažko kito, nei Cuvori sutartas darbas.\n• Jei vietoj ginčo proceso užginčiji kortelės mokėjimą bankui (chargeback) ir paaiškėja, kad tai buvo nepagrįsta, tą sumą turi grąžinti, o paskyra sustabdoma, kol tai bus sutvarkyta.\n• Rodomos kainos, rinkliavos ir mokesčiai – tai, ką sumoki. Jei kažkas atrodo negerai, pranešk mums prieš mokėdamas, o ne po to.",

  r_s7_t:"7. Kai kas nors nutinka ne taip",
  r_s7:"• Pirmiausia pasikalbėk su kita puse Cuvori pokalbyje, kur tai vėliau bus matoma.\n• Jei tai nepadeda, bet kuri pusė gali pradėti ginčą. Cuvori peržiūri sutartį, žinutes ir tai, kas buvo pristatyta, ir per 14 dienų priima sprendimą, abiem pusėms nurodydama savo motyvus.\n• Kai mokėjimas apsaugotas, Cuvori pagal šį sprendimą išmoka laikomus pinigus: editoriui, grąžina klientui, arba padalija pagal realiai atliktą darbą. Kai mokėjimas buvo tiesioginis, Cuvori negali pervesti pinigų – jos sprendimas tampa raštišku vertinimu, užfiksuotu abiejose paskyrose.\n• Bet kuri pusė vis tiek gali kreiptis į teismą; į tai, ką Cuvori jau išmokėjo, ten atsižvelgiama.\n• Cuvori sprendžia pagal tai, ką mato svetainėje. Pristatymus, patvirtinimus ir skundus laikyk pokalbyje.",

  r_s8_t:"8. Kas lemia pašalinimą",
  r_s8:"• Sukčiavimas: pinigų paėmimas neatlikus darbo, mokėjimas svetima kortele, netikra tapatybė, netikras profilis, netikri atsiliepimai.\n• Avanso paėmimas ir dingimas, arba darbo priėmimas ir atsisakymas už jį mokėti.\n• Naujos paskyros naudojimas norint sugrįžti po pašalinimo.\n• Medžiagos, į kurią neturi teisių, įkėlimas pakartotinai, po įspėjimo.\n• Grasinimai, priekabiavimas, diskriminacija, ar kito žmogaus privačios informacijos skelbimas.\n• Bet kas neteisėta, arba Cuvori naudojimas padėti kam nors kitam atlikti kažką neteisėto.\n• Bandymas pakenkti svetainei: atakos prieš ją, klaidų išnaudojimas, kitų žmonių duomenų nuskaitymas (scraping), paskyrų automatizavimas.",

  r_s9_t:"9. Kas nutinka pažeidus taisykles",
  r_s9:"Ką darome, priklauso nuo to, kas nutiko ir ar tai kartojasi:\n• įspėjimas ir prašymas tai ištaisyti;\n• turinio, darbo skelbimo ar atsiliepimo, apie kurį kalbama, pašalinimas;\n• paskyros sustabdymas – tuomet vis dar gali skaityti ir sutvarkyti tai, kas jau pradėta, bet negali pradėti nieko naujo;\n• galutinis paskyros pašalinimas;\n• rimtais atvejais – sukčiavimas, grasinimai, medžiaga su nepilnamečiais – pranešimas policijai ar kitai institucijai, ir kreipimasis į teismą dėl priklausančių pinigų.\nTau bus pasakyta, kas nutiko ir kodėl, kurios taisyklės tai liečia, ir ar sprendimas buvo priimtas automatiškai. Gali nesutikti, parašęs {email}, ir žmogus tai peržiūrės iš naujo. Jei priežastis – teisinė pareiga ar aiškus, rimtas pavojus kitiems žmonėms, pirma imamės veiksmų ir tik po to paaiškiname. Pinigai, jau laikomi pagal atvirą sutartį, dėl sustabdymo nesulaikomi – jie sutvarkomi per ginčo procesą.",

  r_s10_t:"10. Kaip pranešti apie problemą",
  r_s10:"• Naudok mygtuką „Pranešti” profilyje, darbo skelbime, atsiliepime ar žinutėje, arba rašyk {email}.\n• Nurodyk, kokia problema ir kur ji yra. Jei tai susiję su teisėmis į turinį, nurodyk, koks tas turinys ir kokią teisę jis pažeidžia.\n• Peržiūrime kiekvieną pranešimą, imamės veiksmų, kai to reikalauja taisyklės ar įstatymas, ir pranešame, ką padarėme.\n• Klaidingų ir pakartotinių pranešimų teikimas norint pakenkti konkurentui pats savaime yra pagrindas prarasti paskyrą.",

  r_s11_t:"11. Už ką Cuvori atsako, o už ką – ne",
  r_s11:"• Cuvori atsako už tai, kad svetainė veiktų sąžiningai ir atsakingai, kad būtų laikomasi pažadų dėl apsaugotų mokėjimų, ir kad ginčai būtų peržiūrimi taip, kaip aprašyta čia.\n• Cuvori neatsako už patį darbą, už tai, ką žmonės vieni kitiems rašo, už tai, ar su kuo nors malonu dirbti, ar už sutartį, kurią pasirašė du kiti žmonės.\n• Svetainė gali neveikti, veikti lėtai ar keistis. Pasilik savo failų kopijas – Cuvori nėra atsarginio kopijavimo paslauga.\n• Kai Cuvori tau atsako, jos atsakomybė ribojama iki mokesčių, kuriuos sumokėjai Cuvori per pastaruosius 12 mėnesių, arba iki 500 €, jei ši suma didesnė, ir ji neapima netiesioginių nuostolių, tokių kaip prarastas pelnas. Ši riba netaikoma tada, kai to neleidžia įstatymas – įskaitant mūsų pačių tyčią ar didelį neatsargumą, mirtį ar sveikatos sužalojimą, arba pinigus, kuriuos laikome tau apsaugotame mokėjime.\n• Niekas šiose taisyklėse neatima teisių, kurias turi kaip vartotojas pagal savo gyvenamosios šalies įstatymus.",

  r_s12_t:"12. Paskyros uždarymas ir pakeitimai",
  r_s12:"• Paskyrą gali uždaryti bet kada, nustatymuose. Sutartys, pagal kurias vis dar laikomi pinigai, pirmiau turi būti užbaigtos ar išspręstos.\n• Uždarius paskyrą, pašalinamas tavo profilis, portfolio ir atsiliepimai. Sutarčių ir mokėjimų įrašai saugomi tiek, kiek reikalauja įstatymas, o įrašas apie pašalinimą dėl sukčiavimo ar piktnaudžiavimo saugomas, kad tas pats žmogus negalėtų tiesiog sugrįžti.\n• Šios taisyklės gali keistis. Jei pakeitimas tau svarbus, paskelbsime apie tai svetainėje bent 15 dienų prieš jam įsigaliojant; jei toliau naudosiesi Cuvori po to, tai reiškia, kad sutinki. Jei nesutinki – uždaryk paskyrą.\n• Versijos numeris ir data nurodyti šio puslapio viršuje, o versija, su kuria sutikai, saugoma prie tavo paskyros.",

  r_s13_t:"13. Teisė, teismai ir kas mes esame",
  r_s13:"• Šioms taisyklėms taikoma Lietuvos teisė, o ginčus nagrinėja Lietuvos teismai. Jei naudojiesi Cuvori kaip vartotojas, išsaugai savo gyvenamosios šalies teisės suteikiamą apsaugą ir gali kreiptis į savo šalies teismus.\n• Vartotojo ginčą taip pat gali perduoti Valstybinei vartotojų teisių apsaugos tarnybai arba ES elektroninio ginčų sprendimo platformai.\n• Cuvori valdo {company}, {address}. Kontaktai: {email}.",

  pv_title:"Privatumo pranešimas",
  pv_sub:"Ką Cuvori apie tave saugo, kodėl, ir ko gali paprašyti. Trumpai: tik tai, ko reikia svetainei veikti, niekada neparduodama.",
  pv_s1_t:"Kas yra atsakingas",
  pv_s1:"Už čia aprašytus duomenis atsako {company}, {address}. Klausimai ir prašymai: {email}.",
  pv_s2_t:"Kas saugoma ir kodėl",
  pv_s2:"• Paskyra: vardas, el. paštas, tavo pasirinkta kalba, ar esi klientas, ar editorius, ir taisyklių versija, kuriai sutikai. Reikalinga, kad turėtum paskyrą – be jos paslaugos nėra.\n• Profilis ir portfolio: kas rašai apie save, tavo miestas ir šalis, kainos, įgūdžiai, ir vaizdo bei nuotraukų failai, kuriuos įkeli. Pats renkiesi, ką ten įdėti, ir gali tai keisti ar ištrinti.\n• Žinutės ir sutartys: kas rašote vieni kitiems, sutarties sąlygos, pristatymai, datos ir sumos. Reikalinga paslaugai teikti ir ginčams spręsti.\n• Mokėjimai: apsaugotų mokėjimų atveju – suma, būsena ir Stripe identifikatoriai. Kortelės numeriai niekada nesiunčiami Cuvori ir Cuvori jų nesaugo – tuo rūpinasi Stripe. Banko duomenys, kuriuos prideda tiesioginiams mokėjimams, saugomi, kad su tavimi dirbantys klientai galėtų tau sumokėti.\n• Saugumo įrašai: jei paskyra pašalinama dėl sukčiavimo ar piktnaudžiavimo, apie tai išsaugome pastabą ir naudoto el. pašto, kortelės, IBAN ar PayPal duomenų sumaišytas (angl. hashed) formas, kad tas pats žmogus negalėtų iškart sugrįžti nauju vardu. Šiuos duomenis saugome iki 24 mėnesių, arba ilgiau, jei yra atviras ginčas ar reikalavimas. Tai mūsų teisėtas interesas išlaikyti prekyvietę saugią; gali dėl to prieštarauti, ir mes tavo atvejį peržiūrėsime iš naujo.\n• Techniniai duomenys: pagrindiniai serverio ir klaidų žurnalai, trumpai saugomi dėl saugumo.\n• Aktyvumas: jei turite viešą editoriaus profilį, jame matyti, ar priimate darbus ir maždaug kada paskutinį kartą lankėtės (tik data, niekada ne laikas). Tai klientams parodo, ar verta jums rašyti; galite tai paslėpti padarę profilį neviešą.",
  pv_s3_t:"Kas dar tai mato",
  pv_s3:"• Kiti naudotojai mato tai, ką skelbi: tavo profilį, portfolio, atsiliepimus ir tai, ką jiems rašai.\n• Paslaugų teikėjai, kurie valdo Cuvori dalis: Supabase (duomenų bazė ir failai, ES), Netlify (talpinimas), Cloudflare (domenas ir apsauga), Stripe (mokėjimai), ir mūsų el. laiškų siuntimo paslauga. Jie veikia pagal mūsų nurodymus.\n• Institucijos, kai to reikalauja įstatymas.\n• Niekada neparduodame tavo duomenų ir nenaudojame jų reklamai.",
  pv_s4_t:"Kiek laiko saugoma",
  pv_s4:"• Kol egzistuoja tavo paskyra, o uždarius ją – ištrinama, išskyrus sutarčių ir mokėjimų įrašus, kurie saugomi tiek, kiek reikalauja mokesčių ir apskaitos įstatymai, bei aukščiau aprašytus saugumo įrašus.\n• Atsarginės kopijos atnaujinamos per 30 dienų.",
  pv_s5_t:"Tavo teisės",
  pv_s5:"Gali paprašyti savo duomenų kopijos, juos ištaisyti, ištrinti, prieštarauti, kaip juos naudojame, arba paprašyti persiųsti kitur. Rašyk {email}, ir atsakysime per mėnesį. Jei liksi nepatenkintas, gali skųstis Valstybinei duomenų apsaugos inspekcijai (VDAI) arba institucijai savo gyvenamojoje šalyje.",
  pv_s6_t:"Slapukai ir panašios technologijos",
  pv_s6:"Cuvori nenaudoja reklaminių ar sekimo slapukų. Naršyklėje saugo kelis dalykus, kad svetainė veiktų: tavo prisijungimo sesiją ir kalbos pasirinkimą. Išvalius naršyklės duomenis, jie pašalinami.",
  pv_s7_t:"Vaikai",
  pv_s7:"Cuvori nėra skirta jaunesniems nei 18 metų asmenims, ir sąmoningai apie juos duomenų nesaugome. Jei manai, kad vaikas turi paskyrą, rašyk {email}, ir ją pašalinsime.",

  ra_agree:"Perskaičiau ir sutinku su Cuvori taisyklėmis bei privatumo pranešimu.",
  ra_must:"Prieš kurdamas paskyrą, perskaityk taisykles ir su jomis sutik.",
  ra_rules:"taisyklės",
  ra_privacy:"privatumo pranešimas",
  ra_updatedTitle:"Taisyklės pasikeitė",
  ra_updatedBody:"Atnaujinome Cuvori taisykles ir privatumo pranešimą. Perskaityk juos ir patvirtink, kad galėtum tęsti.",
  ra_accept:"Sutinku",
  ra_later:"Pirmiau perskaityti",
  ra_accepted:"Ačiū – išsaugota.",
  ra_report:"Pranešti",
  ra_reportTitle:"Pranešti apie problemą",
  ra_reportWhat:"Kokia problema?",
  ra_reportKind:"Tipas",
  ra_kindIllegal:"Neteisėtas turinys",
  ra_kindRights:"Kito asmens teisės (autorių teisės, muzika, vaizdo medžiaga)",
  ra_kindScam:"Sukčiavimas ar apgaulė",
  ra_kindAbuse:"Piktnaudžiavimas, grasinimai ar priekabiavimas",
  ra_kindFake:"Netikras profilis ar netikri atsiliepimai",
  ra_kindOther:"Kas kita",
  ra_reportPh:"Kas nutiko ir kur tai yra Cuvori svetainėje?",
  ra_reportSend:"Siųsti pranešimą",
  ra_reportSent:"Pranešimas išsiųstas. Peržiūrime kiekvieną pranešimą ir pasakysime, ką padarėme.",
  ra_reportSignIn:"Prisijunk, kad galėtum apie ką nors pranešti, arba rašyk {email}.",
  ra_banReason:"Nurodyta priežastis:",
  ra_banObject:"Jei manai, kad tai neteisinga, rašyk {email}, ir žmogus tai peržiūrės iš naujo.",
  ra_imprint:"Cuvori valdo {company}, {address} · {email}",
  ra_waiting:"Laukia pranešimų: {n}",
  ra_waitingHint:"Atidarykite pranešimų sąrašą ir pasakykite žmogui, ką padarėte."
})
