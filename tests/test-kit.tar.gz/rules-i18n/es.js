// Site rules + privacy notice — Spanish. r_* = rules, pv_* = privacy, ra_* = agreement UI.
// Bodies are plain text; a line starting with "• " becomes a bullet on the page.
// Placeholders kept exactly: {email} {company} {address} {feePct} {feeFixed} {autoDays} {ver} {d}
({
  r_title:"Reglas de Cuvori",
  r_sub:"Las reglas que todos en Cuvori aceptan. Lenguaje sencillo, sin letra pequeña. Si las incumples, puedes recibir una advertencia, una suspensión o la eliminación de tu cuenta, y en casos graves ser denunciado ante las autoridades o llevado a los tribunales.",
  r_version:"Versión {ver}",
  r_toPrivacy:"Aviso de privacidad",
  r_toRules:"Reglas",

  r_s1_t:"1. Qué es Cuvori",
  r_s1:"Cuvori es un lugar donde los clientes encuentran freelancers —editores de vídeo, fotógrafos, diseñadores, desarrolladores, redactores y otros profesionales creativos—, acuerdan el trabajo y lo registran en un pedido. Cuando ambas partes lo aceptan, ese pedido es su contrato.\n• Cuvori no es parte del contrato entre un cliente y un freelancer, no emplea a los freelancers y no realiza el trabajo de edición.\n• Cuvori no promete que vayas a encontrar trabajo, que vayas a encontrar a alguien para contratar, ni que el trabajo vaya a ser bueno. Lo que promete son las herramientas: perfiles, mensajes, contratos, reseñas y, cuando está activado, pagos protegidos.\n• Cuvori no cobra comisión sobre el precio del proyecto. Cuando se usa un pago protegido, el cliente paga además el coste de procesamiento del proveedor de pagos, que se muestra como importe exacto antes de pagar; cubre la gestión de la tarjeta y del pago y no se devuelve si el dinero se reembolsa o se divide más adelante.",

  r_s2_t:"2. Quién puede usar Cuvori",
  r_s2:"• Debes tener al menos 18 años.\n• Usa tu nombre real y tus datos reales. Una persona, una cuenta. No crees una cuenta para otra persona ni finjas ser alguien que no eres.\n• No compartas tu contraseña con nadie. Lo que ocurra bajo tu cuenta es tu responsabilidad.\n• Si trabajas como empresa, indícalo en tu perfil y mantén en orden tu facturación e impuestos. Cada parte se ocupa de sus propios impuestos.",

  r_s3_t:"3. La versión breve",
  r_s3:"Sé honesto, haz el trabajo que acordaste y paga por el trabajo que recibiste. Casi todo lo que sigue se deriva de eso.",

  r_s4_t:"4. Lo que subes y muestras",
  r_s4:"• Conservas los derechos sobre tu propio trabajo. Al subirlo, le das a Cuvori permiso para almacenarlo y mostrarlo en Cuvori —en tu perfil, en los resultados de búsqueda y a las personas a las que escribes— para que el sitio pueda funcionar. Ese permiso termina cuando eliminas el archivo o tu cuenta, salvo por las copias en las copias de seguridad, que se eliminan a medida que esas copias de seguridad se renuevan.\n• Confirmas que posees los derechos de todo lo que subes, incluyendo música, material de archivo, tipografías y cualquier cosa que te haya dado un cliente, y que está permitido mostrarlo en Cuvori. Si se infringen los derechos de otra persona, la responsabilidad recae en quien lo subió.\n• No subas: material que no tienes derecho a usar; material privado de alguien publicado sin su consentimiento; contenido que sea ilegal, violento, de odio, contenido sexual que involucre a menores, o creado para engañar.\n• El material de un cliente no es tuyo para publicar. Muestra el trabajo terminado en tu portafolio solo una vez que el cliente lo haya publicado, o con el consentimiento del cliente.\n• Si alguien nos dice que lo que subiste infringe sus derechos, podemos retirarlo. Subir repetidamente material infractor hace que se elimine la cuenta.",

  r_s5_t:"5. Reseñas y mensajes",
  r_s5:"• Escribe reseñas solo sobre trabajos en los que realmente participaste, y describe lo que realmente ocurrió.\n• No compres, vendas, intercambies ni pidas reseñas, y no amenaces con una mala reseña para obtener algo gratis.\n• Nada de spam, nada de mensajes masivos, no lleves a las personas fuera de Cuvori para eludir las protecciones que existen aquí.\n• Sé cívico. Los insultos, el acoso, las amenazas y la discriminación terminan en la eliminación de la cuenta.\n• No publiques datos personales de otras personas en mensajes, perfiles o reseñas.",

  r_s6_t:"6. Dinero",
  r_s6:"• Pagos directos: el cliente paga al freelancer directamente. Cuvori nunca retiene ese dinero, no cobra nada por ello y no puede recuperarlo por ti si algo sale mal; lo que sí puede hacer es revisar el caso y dejar constancia de su opinión.\n• Pagos protegidos: el cliente paga al proveedor de pagos de Cuvori, el dinero queda retenido, y pasa al freelancer cuando el cliente aprueba la entrega, o automáticamente {autoDays} días después de la entrega si el cliente no hace nada. Pulsar \"Solicitar cambios\" o abrir una disputa antes de que terminen esos días detiene la liberación automática; un mensaje en el chat por sí solo no lo hace.\n• No uses los pagos de aquí para mover dinero por algo distinto del trabajo acordado en Cuvori.\n• Si haces un contracargo de un pago con tarjeta en lugar de usar la vía de la disputa, y el contracargo resulta ser infundado, debes devolver ese dinero, y la cuenta queda suspendida hasta que se resuelva.\n• Los precios, comisiones e impuestos mostrados son lo que pagas. Si algo parece incorrecto, dínoslo antes de pagar, no después.",

  r_s7_t:"7. Cuando algo sale mal",
  r_s7:"• Habla primero con la otra parte, en el chat de Cuvori, donde se puede consultar más tarde.\n• Si eso no funciona, cualquiera de las partes puede abrir una disputa. Cuvori revisa el contrato, los mensajes y lo que se entregó, y decide en un plazo de 14 días, explicando sus razones a ambas partes.\n• Cuando el pago está protegido, Cuvori entrega el dinero retenido según esa decisión: al freelancer, de vuelta al cliente, o dividido según el trabajo realmente realizado. Cuando el pago fue directo, Cuvori no puede mover el dinero; su decisión es una opinión por escrito, registrada en ambas cuentas.\n• Cualquiera de las partes puede aun así acudir a los tribunales; lo que Cuvori haya pagado se tiene en cuenta allí.\n• Cuvori decide en función de lo que puede ver en el sitio. Mantén las entregas, aprobaciones y quejas en el chat.",

  r_s8_t:"8. Cosas que hacen que te eliminen la cuenta",
  r_s8:"• Fraude: cobrar dinero sin hacer el trabajo, pagar con la tarjeta de otra persona, identidad falsa, perfil falso, reseñas falsas.\n• Cobrar el anticipo y desaparecer, o aceptar la entrega y negarse a pagar.\n• Usar una cuenta nueva para volver después de haber sido eliminado.\n• Subir material sobre el que no tienes derechos, de nuevo después de haber sido advertido.\n• Amenazas, acoso, discriminación, o publicar información privada de alguien.\n• Cualquier cosa ilegal, o usar Cuvori para ayudar a otra persona a hacer algo ilegal.\n• Intentar dañar el sitio: atacarlo, aprovechar fallos, extraer datos de otras personas, automatizar cuentas.",

  r_s9_t:"9. Qué pasa si incumples las reglas",
  r_s9:"Lo que hacemos depende de lo que haya ocurrido y de si ha vuelto a ocurrir:\n• una advertencia y una solicitud para corregirlo;\n• eliminar el contenido, el trabajo o la reseña en cuestión;\n• suspender la cuenta, de forma que puedas seguir leyendo y resolviendo lo que esté abierto, pero no puedas iniciar nada nuevo;\n• eliminar la cuenta de forma permanente;\n• en casos graves —fraude, amenazas, material que involucre a menores— denunciarlo a la policía u otra autoridad, y acudir a los tribunales para reclamar el dinero adeudado.\nSe te informará de lo que ha ocurrido y por qué, a qué regla se refiere, y si la decisión fue automática. Puedes objetar escribiendo a {email}, y una persona volverá a revisarlo. Si el motivo es una obligación legal o un riesgo claro y grave para otras personas, actuamos primero y lo explicamos justo después. El dinero ya retenido en un contrato abierto no se retiene por causa de una suspensión; se resuelve a través de la vía de la disputa.",

  r_s10_t:"10. Cómo informarnos de un problema",
  r_s10:"• Usa el botón Denunciar en un perfil, trabajo, reseña o mensaje, o escribe a {email}.\n• Indica cuál es el problema y dónde se encuentra. Si se trata de derechos sobre contenido, indica qué es el contenido y qué derecho infringe.\n• Revisamos cada denuncia, actuamos cuando las reglas o la ley lo exigen, y te informamos de lo que hemos hecho.\n• Denunciar cosas de forma falsa y repetida para perjudicar a un competidor es en sí mismo motivo para perder la cuenta.",

  r_s11_t:"11. De qué es responsable Cuvori y de qué no",
  r_s11:"• Cuvori es responsable de gestionar el sitio con honestidad y cuidado, de cumplir sus promesas sobre los pagos protegidos, y de revisar las disputas tal como se describe aquí.\n• Cuvori no es responsable del trabajo en sí, de lo que las personas se escriben entre sí, de si alguien es agradable para trabajar, ni de un contrato firmado por otras dos personas.\n• El sitio puede estar caído, ser lento o cambiar. Guarda tus propias copias de tus archivos; Cuvori no es un servicio de copia de seguridad.\n• Cuando Cuvori es responsable ante ti, su responsabilidad se limita a las comisiones que le has pagado a Cuvori en los 12 meses anteriores, o a 500 €, si esa cantidad es mayor, y no cubre pérdidas indirectas como el lucro cesante. Este límite no se aplica cuando la ley no lo permite, incluyendo el dolo o la negligencia grave por nuestra parte, la muerte o las lesiones personales, o el dinero que retenemos para ti en un pago protegido.\n• Nada en estas reglas elimina los derechos que tienes como consumidor según la ley del país donde vives.",

  r_s12_t:"12. Terminarlo, y cambios",
  r_s12:"• Puedes cerrar tu cuenta en cualquier momento desde Ajustes. Los contratos con dinero todavía retenido deben finalizarse o resolverse primero.\n• Cerrar una cuenta elimina tu perfil, tu portafolio y tus reseñas. Los registros de contratos y pagos se conservan durante el tiempo que exige la ley, y se conserva un registro de una eliminación por fraude o abuso para que la misma persona no pueda simplemente volver.\n• Estas reglas pueden cambiar. Si el cambio te afecta, lo anunciamos en el sitio al menos 15 días antes de que entre en vigor; seguir usando Cuvori después de eso significa que lo aceptas. Si no, cierra la cuenta.\n• En la parte superior de esta página figuran un número de versión y una fecha, y la versión que aceptaste se guarda junto con tu cuenta.",

  r_s13_t:"13. Ley, tribunales y quiénes somos",
  r_s13:"• Estas reglas se rigen por la ley alemana. Si usas Cuvori como consumidor, conservas la protección de la ley del país donde vives y puedes presentar una demanda en los tribunales de tu propio país.\n• Cuvori no está obligada ni dispuesta a participar en procedimientos de resolución de disputas ante una entidad de arbitraje de consumo. Siempre puedes acudir a la organización de consumidores de tu país.\n• Cuvori está gestionada por {company}, {address}. Contacto: {email}.",

  pv_title:"Aviso de privacidad",
  pv_sub:"Qué almacena Cuvori sobre ti, por qué, y qué puedes solicitar. Versión breve: solo lo que el sitio necesita para funcionar, nunca se vende.",
  pv_s1_t:"Quién es responsable",
  pv_s1:"{company}, {address}, es responsable de los datos descritos aquí. Preguntas y solicitudes: {email}.",
  pv_s2_t:"Qué se almacena, y por qué",
  pv_s2:"• Cuenta: nombre, correo electrónico, el idioma que elegiste, si eres cliente o freelancer, y la versión de las reglas que aceptaste. Necesario para darte una cuenta; sin ello no hay servicio.\n• Perfil y portafolio: lo que escribes sobre ti mismo, tu ciudad y país, precios, habilidades, y los vídeos e imágenes que subes. Tú eliges qué poner ahí y puedes modificarlo o eliminarlo.\n• Mensajes y contratos: lo que os escribís entre vosotros, los términos del contrato, las entregas, fechas e importes. Necesario para prestar el servicio y para resolver disputas.\n• Pagos: con los pagos protegidos, el importe, el estado y los identificadores de Stripe. Los números de tarjeta nunca se envían a Cuvori ni Cuvori los almacena; Stripe los gestiona. Los datos bancarios que añades para pagos directos se almacenan para que los clientes con los que trabajas puedan pagarte.\n• Registros de seguridad: si se elimina una cuenta por fraude o abuso, guardamos una nota de ello y formas ofuscadas (con hash) del correo electrónico, la tarjeta, el IBAN o el PayPal utilizados, para que la misma persona no pueda volver de inmediato con un nombre nuevo. Conservamos estos datos hasta 24 meses, o más si hay una disputa o reclamación abierta. Este es nuestro legítimo interés en mantener el mercado seguro; puedes oponerte a ello, y volveremos a revisar tu caso.\n• Técnicos: registros básicos de servidor y de errores conservados durante un breve periodo por motivos de seguridad.\n• Actividad: si tienes un perfil de freelancer público, se ve si aceptas trabajo y aproximadamente cuándo entraste por última vez (solo la fecha, nunca la hora). Sirve para que los clientes sepan si vale la pena escribirte; puedes ocultarlo haciendo privado tu perfil.",
  pv_s3_t:"Quién más lo ve",
  pv_s3:"• Otros usuarios ven lo que publicas: tu perfil, tu portafolio, tus reseñas y lo que les escribes.\n• Proveedores de servicios que gestionan partes de Cuvori: Supabase (base de datos y archivos, UE), Netlify (alojamiento), Cloudflare (dominio y protección), Stripe (pagos), y nuestro proveedor de envío de correo electrónico. Actúan siguiendo nuestras instrucciones.\n• Autoridades, cuando la ley lo exige.\n• Nunca vendemos tus datos, y no los usamos para publicidad.",
  pv_s4_t:"Durante cuánto tiempo se conserva",
  pv_s4:"• Mientras exista tu cuenta, y luego se elimina cuando la cierras, salvo los registros de contratos y pagos, que se conservan durante el tiempo que exige la normativa fiscal y contable, y los registros de seguridad descritos anteriormente.\n• Las copias de seguridad se renuevan en un plazo de 30 días.",
  pv_s5_t:"Tus derechos",
  pv_s5:"Puedes solicitar una copia de tus datos, corregirlos, eliminarlos, oponerte a cómo los usamos, o pedirnos que los enviemos a otro sitio. Escribe a {email} y responderemos en un plazo de un mes. Si no estás satisfecho, puedes presentar una reclamación ante la Autoridad Bávara de Supervisión de Protección de Datos (Bayerisches Landesamt für Datenschutzaufsicht, BayLDA) o ante la autoridad de protección de datos del país donde vives.",
  pv_s6_t:"Cookies y similares",
  pv_s6:"Cuvori no utiliza cookies publicitarias ni de seguimiento. Almacena algunas cosas en tu navegador para que el sitio funcione: tu sesión de inicio de sesión y tu elección de idioma. Al borrar los datos de tu navegador, se eliminan.",
  pv_s7_t:"Menores",
  pv_s7:"Cuvori no es para personas menores de 18 años, y no conservamos deliberadamente datos sobre ellas. Si crees que un menor tiene una cuenta, escribe a {email} y la eliminaremos.",

  ra_agree:"He leído y acepto las reglas de Cuvori y el aviso de privacidad.",
  ra_must:"Por favor, lee y acepta las reglas antes de crear una cuenta.",
  ra_rules:"reglas",
  ra_privacy:"aviso de privacidad",
  ra_updatedTitle:"Las reglas han cambiado",
  ra_updatedBody:"Hemos actualizado las reglas de Cuvori y el aviso de privacidad. Léelos y confirma para continuar.",
  ra_accept:"Acepto",
  ra_later:"Leerlos primero",
  ra_accepted:"Gracias — guardado.",
  ra_report:"Denunciar",
  ra_reportTitle:"Denunciar un problema",
  ra_reportWhat:"¿Cuál es el problema?",
  ra_reportKind:"Tipo",
  ra_kindIllegal:"Contenido ilegal",
  ra_kindRights:"Derechos de otra persona (derechos de autor, música, material audiovisual)",
  ra_kindScam:"Fraude o estafa",
  ra_kindAbuse:"Abuso, amenazas o acoso",
  ra_kindFake:"Perfil falso o reseñas falsas",
  ra_kindOther:"Otra cosa",
  ra_reportPh:"¿Qué pasó, y dónde está en Cuvori?",
  ra_reportSend:"Enviar denuncia",
  ra_reportSent:"Denuncia enviada. Revisamos cada denuncia y te diremos qué hicimos.",
  ra_reportSignIn:"Inicia sesión para denunciar algo, o escribe a {email}.",
  ra_banReason:"Motivo indicado:",
  ra_banObject:"Si crees que esto es un error, escribe a {email} y una persona volverá a revisarlo.",
  ra_imprint:"Cuvori está gestionada por {company}, {address} · {email}",
  ra_waiting:"Informes pendientes: {n}",
  ra_waitingHint:"Abre la lista de informes y dile a la persona qué has hecho."
})
