// Site rules + privacy notice — German (du form). r_* = rules, pv_* = privacy, ra_* = agreement UI.
// Bodies are plain text; a line starting with "• " becomes a bullet on the page.
// Placeholders kept exactly: {email} {company} {address} {feePct} {feeFixed} {autoDays} {ver} {d}
({
  r_title:"Cuvori-Regeln",
  r_sub:"Die Regeln, denen alle bei Cuvori zustimmen. Klare Sprache, kein Kleingedrucktes. Wer dagegen verstößt, kann verwarnt, gesperrt oder entfernt werden – in schweren Fällen auch den Behörden gemeldet oder vor Gericht gebracht.",
  r_version:"Version {ver}",
  r_toPrivacy:"Datenschutzerklärung",
  r_toRules:"Regeln",

  r_s1_t:"1. Was Cuvori ist",
  r_s1:"Cuvori ist ein Ort, an dem Kunden Video-Editoren, Videografen und Fotografen finden, sich über die Arbeit einigen und das in einem Vertrag festhalten.\n• Cuvori ist nicht Vertragspartei zwischen einem Kunden und einem Editor, beschäftigt keine Editoren und führt die Schnittarbeit nicht selbst aus.\n• Cuvori verspricht nicht, dass du Arbeit findest, jemanden zum Beauftragen findest, oder dass die Arbeit gut wird. Versprochen werden die Werkzeuge: Profile, Nachrichten, Verträge, Bewertungen und, wo aktiviert, geschützte Zahlungen.\n• Cuvori nimmt keine Provision vom Projektpreis. Wird eine geschützte Zahlung genutzt, zahlt der Kunde zusätzlich zum Preis eine Zahlungsgebühr von {feePct}% + {feeFixed}; diese Gebühr deckt Karten- und Zahlungsabwicklung und wird nicht erstattet, wenn das Geld später zurückerstattet oder aufgeteilt wird.",

  r_s2_t:"2. Wer Cuvori nutzen darf",
  r_s2:"• Du musst mindestens 18 Jahre alt sein.\n• Nutze deinen echten Namen und echte Angaben. Eine Person, ein Konto. Erstelle kein Konto für jemand anderen und gib dich nicht als jemand anderes aus.\n• Behalte dein Passwort für dich. Was unter deinem Konto passiert, liegt in deiner Verantwortung.\n• Wenn du gewerblich arbeitest, gib das in deinem Profil an und halte Rechnungsstellung und Steuern in Ordnung. Jede Seite kümmert sich um ihre eigenen Steuern.",

  r_s3_t:"3. Kurz gesagt",
  r_s3:"Sei ehrlich, mach die Arbeit, die du zugesagt hast, und bezahl die Arbeit, die du erhalten hast. Fast alles unten folgt daraus.",

  r_s4_t:"4. Was du hochlädst und zeigst",
  r_s4:"• Die Rechte an deiner eigenen Arbeit bleiben bei dir. Mit dem Hochladen erlaubst du Cuvori, sie zu speichern und auf Cuvori zu zeigen – in deinem Profil, in Suchergebnissen und den Personen, denen du schreibst –, damit die Seite funktioniert. Diese Erlaubnis endet, wenn du die Datei oder dein Konto löschst, außer bei Kopien in Backups, die gelöscht werden, sobald diese Backups turnusmäßig ersetzt werden.\n• Du bestätigst, dass du die Rechte an allem besitzt, was du hochlädst, einschließlich Musik, Stockmaterial, Schriftarten und allem, was dir ein Kunde gegeben hat, und dass es erlaubt ist, es auf Cuvori zu zeigen. Werden dabei die Rechte einer anderen Person verletzt, trägt das die Person, die es hochgeladen hat.\n• Lade nicht hoch: Material, an dem du keine Nutzungsrechte hast; privates Material einer Person, das ohne ihre Zustimmung veröffentlicht wurde; Inhalte, die illegal, gewalttätig, hasserfüllt sind, sexuelle Inhalte mit Minderjährigen zeigen, oder zum Täuschen gemacht wurden.\n• Das Material eines Kunden gehört nicht dir zur Veröffentlichung. Zeige fertige Arbeiten in deinem Portfolio erst, wenn der Kunde sie veröffentlicht hat, oder mit der Zustimmung des Kunden.\n• Wenn uns jemand meldet, dass dein Upload seine Rechte verletzt, können wir ihn entfernen. Wer wiederholt rechtsverletzendes Material hochlädt, verliert das Konto.",

  r_s5_t:"5. Bewertungen und Nachrichten",
  r_s5:"• Schreib Bewertungen nur zu Arbeiten, an denen du wirklich beteiligt warst, und schreib, was wirklich passiert ist.\n• Kaufe, verkaufe oder tausche keine Bewertungen und bitte nicht darum, und drohe nicht mit einer schlechten Bewertung, um etwas umsonst zu bekommen.\n• Kein Spam, keine Massennachrichten, und schick niemanden von Cuvori weg, um den Schutz hier zu umgehen.\n• Bleib höflich. Beleidigungen, Belästigung, Drohungen und Diskriminierung führen zur Kontoentfernung.\n• Veröffentliche keine personenbezogenen Daten anderer Personen in Nachrichten, Profilen oder Bewertungen.",

  r_s6_t:"6. Geld",
  r_s6:"• Direkte Zahlungen: Der Kunde zahlt direkt an den Editor. Cuvori hält dieses Geld nie, verlangt dafür nichts, und kann es bei Problemen nicht für dich zurückholen – was Cuvori tun kann, ist den Fall zu prüfen und seine Einschätzung festzuhalten.\n• Geschützte Zahlungen: Der Kunde zahlt an Cuvoris Zahlungsdienstleister, das Geld wird gehalten und geht an den Editor, wenn der Kunde die Lieferung freigibt, oder automatisch {autoDays} Tage nach der Lieferung, wenn der Kunde nichts tut. „Änderungen anfragen” zu klicken oder einen Streitfall zu eröffnen, bevor diese Tage ablaufen, stoppt die automatische Freigabe; eine Nachricht allein im Chat reicht dafür nicht.\n• Nutze die Zahlungen hier nicht, um Geld für etwas anderes als die auf Cuvori vereinbarte Arbeit zu bewegen.\n• Wenn du eine Kartenzahlung per Rückbuchung (Chargeback) statt über den Streitfall-Weg zurückholst und sich die Rückbuchung als unbegründet erweist, schuldest du dieses Geld zurück, und das Konto wird gesperrt, bis das geklärt ist.\n• Angezeigte Preise, Gebühren und Steuern sind das, was du zahlst. Wirkt etwas falsch, sag uns das vor der Zahlung, nicht danach.",

  r_s7_t:"7. Wenn etwas schiefgeht",
  r_s7:"• Sprich zuerst mit der anderen Seite, im Cuvori-Chat, wo es später nachvollziehbar bleibt.\n• Klappt das nicht, eröffnet eine der beiden Seiten einen Streitfall. Cuvori prüft den Vertrag, die Nachrichten und was geliefert wurde, und entscheidet innerhalb von 14 Tagen, mit Begründung an beide Seiten.\n• War die Zahlung geschützt, zahlt Cuvori das gehaltene Geld gemäß dieser Entscheidung aus: an den Editor, zurück an den Kunden, oder aufgeteilt entsprechend der tatsächlich geleisteten Arbeit. War die Zahlung direkt, kann Cuvori kein Geld bewegen – die Entscheidung ist dann eine schriftliche Einschätzung, die bei beiden Konten festgehalten wird.\n• Beide Seiten können trotzdem vor Gericht gehen; was Cuvori ausgezahlt hat, wird dabei berücksichtigt.\n• Cuvori entscheidet nach dem, was auf der Seite sichtbar ist. Halte Lieferungen, Freigaben und Beschwerden im Chat fest.",

  r_s8_t:"8. Was zur Entfernung führt",
  r_s8:"• Betrug: Geld nehmen, ohne die Arbeit zu machen; mit der Karte einer anderen Person zahlen; falsche Identität, falsches Profil, gefälschte Bewertungen.\n• Die Anzahlung nehmen und verschwinden, oder die Lieferung annehmen und die Zahlung verweigern.\n• Ein neues Konto nutzen, um nach einer Entfernung zurückzukommen.\n• Material hochladen, an dem du keine Rechte hast, erneut nach einer Verwarnung.\n• Drohungen, Belästigung, Diskriminierung, oder das Veröffentlichen privater Informationen einer anderen Person.\n• Alles Illegale, oder Cuvori nutzen, um jemand anderem bei etwas Illegalem zu helfen.\n• Versuchen, die Seite zu beschädigen: sie angreifen, Fehler ausnutzen, Daten anderer Personen scrapen, Konten automatisieren.",

  r_s9_t:"9. Was passiert, wenn du gegen die Regeln verstößt",
  r_s9:"Was wir tun, hängt davon ab, was passiert ist und ob es sich wiederholt hat:\n• eine Verwarnung und die Bitte, es zu beheben;\n• das Entfernen des betreffenden Inhalts, Auftrags oder der Bewertung;\n• das Sperren des Kontos, sodass du noch lesen und offene Dinge abschließen, aber nichts Neues starten kannst;\n• das dauerhafte Entfernen des Kontos;\n• in schweren Fällen – Betrug, Drohungen, Material mit Minderjährigen – die Meldung an die Polizei oder eine andere Behörde, und eine Klage auf geschuldetes Geld.\nDu erfährst, was passiert ist und warum, welche Regel betroffen ist, und ob die Entscheidung automatisch getroffen wurde. Du kannst widersprechen, indem du an {email} schreibst, und ein Mensch prüft es erneut. Ist der Grund eine gesetzliche Pflicht oder ein klares, ernstes Risiko für andere Menschen, handeln wir zuerst und erklären es direkt danach. Geld, das bereits in einem offenen Vertrag gehalten wird, wird wegen einer Sperrung nicht einbehalten – es wird über den Streitfall-Weg geklärt.",

  r_s10_t:"10. Ein Problem melden",
  r_s10:"• Nutze den Melden-Button an einem Profil, Auftrag, einer Bewertung oder Nachricht, oder schreib an {email}.\n• Sag, worum es geht und wo es zu finden ist. Geht es um Rechte an Inhalten, sag, um welchen Inhalt es sich handelt und welches Recht verletzt wird.\n• Wir prüfen jede Meldung, handeln, wo die Regeln oder das Gesetz es verlangen, und sagen dir, was wir getan haben.\n• Wer wiederholt und wissentlich falsch meldet, um einem Konkurrenten zu schaden, riskiert damit selbst das Konto.",

  r_s11_t:"11. Wofür Cuvori verantwortlich ist – und wofür nicht",
  r_s11:"• Cuvori ist dafür verantwortlich, die Seite ehrlich und sorgfältig zu betreiben, seine Zusagen zu geschützten Zahlungen einzuhalten, und Streitfälle so zu prüfen, wie hier beschrieben.\n• Cuvori ist nicht verantwortlich für die Arbeit selbst, dafür, was sich Menschen gegenseitig schreiben, dafür, ob jemand angenehm in der Zusammenarbeit ist, oder für einen Vertrag, den zwei andere Personen geschlossen haben.\n• Die Seite kann ausfallen, langsam sein oder sich ändern. Behalte eigene Kopien deiner Dateien; Cuvori ist kein Backup-Dienst.\n• Haftet Cuvori dir gegenüber, ist die Haftung auf die Gebühren begrenzt, die du in den vorangegangenen 12 Monaten an Cuvori gezahlt hast, oder auf 500 €, falls das mehr ist, und sie deckt keine indirekten Schäden wie entgangenen Gewinn. Diese Grenze gilt nicht, wo das Gesetz sie nicht erlaubt – etwa bei eigenem Vorsatz oder grober Fahrlässigkeit, bei Tod oder Personenschaden, oder bei Geld, das wir für dich in einer geschützten Zahlung halten.\n• Nichts in diesen Regeln nimmt dir die Rechte, die du als Verbraucher nach dem Recht deines Wohnsitzlandes hast.",

  r_s12_t:"12. Beenden und Änderungen",
  r_s12:"• Du kannst dein Konto jederzeit in den Einstellungen schließen. Verträge, bei denen noch Geld gehalten wird, müssen vorher abgeschlossen oder geklärt werden.\n• Das Schließen eines Kontos entfernt dein Profil, Portfolio und deine Bewertungen. Aufzeichnungen zu Verträgen und Zahlungen werden so lange aufbewahrt, wie es das Gesetz verlangt, und eine Aufzeichnung über eine Entfernung wegen Betrugs oder Missbrauchs wird aufbewahrt, damit dieselbe Person nicht einfach zurückkehren kann.\n• Diese Regeln können sich ändern. Betrifft dich die Änderung, kündigen wir sie mindestens 15 Tage vor Inkrafttreten auf der Seite an; nutzt du Cuvori danach weiter, gilt das als Zustimmung. Wenn nicht, schließe dein Konto.\n• Eine Versionsnummer und ein Datum stehen oben auf dieser Seite, und die Version, der du zugestimmt hast, wird bei deinem Konto gespeichert.",

  r_s13_t:"13. Recht, Gerichte und wer wir sind",
  r_s13:"• Für diese Regeln gilt litauisches Recht, und litauische Gerichte sind zuständig. Nutzt du Cuvori als Verbraucher, behältst du den Schutz des Rechts deines Wohnsitzlandes und kannst vor den Gerichten deines eigenen Landes klagen.\n• Du kannst eine Verbraucherstreitigkeit auch an die litauische Staatliche Verbraucherschutzbehörde oder die Online-Streitbeilegungsplattform der EU richten.\n• Cuvori wird betrieben von {company}, {address}. Kontakt: {email}.",

  pv_title:"Datenschutzerklärung",
  pv_sub:"Was Cuvori über dich speichert, warum, und was du verlangen kannst. Kurz gesagt: nur, was die Seite zum Funktionieren braucht, niemals verkauft.",
  pv_s1_t:"Wer verantwortlich ist",
  pv_s1:"{company}, {address}, ist für die hier beschriebenen Daten verantwortlich. Fragen und Anfragen: {email}.",
  pv_s2_t:"Was gespeichert wird, und warum",
  pv_s2:"• Konto: Vorname, E-Mail, die von dir gewählte Sprache, ob du Kunde oder Editor bist, und die Version der Regeln, der du zugestimmt hast. Nötig, um dir ein Konto zu geben – ohne das gibt es keinen Dienst.\n• Profil und Portfolio: was du über dich schreibst, deine Stadt und dein Land, Preise, Fähigkeiten, und die Videos und Bilder, die du hochlädst. Du entscheidest, was du dort einstellst, und kannst es ändern oder löschen.\n• Nachrichten und Verträge: was ihr euch gegenseitig schreibt, Vertragsbedingungen, Lieferungen, Daten und Beträge. Nötig, um den Dienst zu betreiben und Streitfälle zu klären.\n• Zahlungen: bei geschützten Zahlungen der Betrag, der Status und Kennungen von Stripe. Kartennummern werden nie an Cuvori gesendet oder von Cuvori gespeichert – das übernimmt Stripe. Bankdaten, die du für direkte Zahlungen hinzufügst, werden gespeichert, damit Kunden, mit denen du arbeitest, dich bezahlen können.\n• Sicherheitsdaten: Wird ein Konto wegen Betrugs oder Missbrauchs entfernt, behalten wir eine Notiz darüber und verschlüsselte (gehashte) Formen der verwendeten E-Mail-, Karten-, IBAN- oder PayPal-Daten, damit dieselbe Person nicht sofort unter neuem Namen zurückkehren kann. Wir bewahren das bis zu 24 Monate auf, oder länger, wenn ein Streitfall oder Anspruch offen ist. Das ist unser berechtigtes Interesse daran, den Marktplatz sicher zu halten; du kannst dem widersprechen, und wir prüfen deinen Fall dann erneut.\n• Technisches: grundlegende Server- und Fehlerprotokolle, kurzzeitig aus Sicherheitsgründen aufbewahrt.\n• Aktivität: Bei einem öffentlichen Editor-Profil ist sichtbar, ob du Aufträge annimmst und ungefähr wann du zuletzt aktiv warst (nur das Datum, nie die Uhrzeit). Das zeigt Kundinnen und Kunden, ob sich eine Anfrage lohnt; du kannst es ausblenden, indem du dein Profil privat stellst.",
  pv_s3_t:"Wer es sonst noch sieht",
  pv_s3:"• Andere Nutzer sehen, was du veröffentlichst: dein Profil, dein Portfolio, deine Bewertungen, und was du ihnen schreibst.\n• Dienstleister, die Teile von Cuvori betreiben: Supabase (Datenbank und Dateien, EU), Netlify (Hosting), Cloudflare (Domain und Schutz), Stripe (Zahlungen), und unser E-Mail-Versand. Sie handeln nach unseren Anweisungen.\n• Behörden, wo es das Gesetz verlangt.\n• Wir verkaufen deine Daten nie und nutzen sie nicht für Werbung.",
  pv_s4_t:"Wie lange es aufbewahrt wird",
  pv_s4:"• Solange dein Konto besteht, und danach gelöscht, wenn du es schließt – außer Vertrags- und Zahlungsaufzeichnungen, die so lange aufbewahrt werden, wie das Steuer- und Buchhaltungsrecht es verlangt, und den oben beschriebenen Sicherheitsdaten.\n• Backups werden innerhalb von 30 Tagen ersetzt.",
  pv_s5_t:"Deine Rechte",
  pv_s5:"Du kannst eine Kopie deiner Daten anfordern, sie berichtigen, löschen, der Nutzung widersprechen, oder verlangen, dass wir sie an eine andere Stelle senden. Schreib an {email}, und wir antworten innerhalb eines Monats. Bist du nicht zufrieden, kannst du dich bei der litauischen Staatlichen Datenschutzinspektion (VDAI) oder der Behörde in deinem Wohnsitzland beschweren.",
  pv_s6_t:"Cookies und Ähnliches",
  pv_s6:"Cuvori nutzt keine Werbe- oder Tracking-Cookies. Es speichert ein paar Dinge in deinem Browser, damit die Seite funktioniert: deine Anmeldesitzung und deine Sprachwahl. Löschst du deine Browserdaten, werden sie entfernt.",
  pv_s7_t:"Kinder",
  pv_s7:"Cuvori ist nicht für Personen unter 18, und wir bewahren wissentlich keine Daten über sie auf. Denkst du, ein Kind hat ein Konto, schreib an {email}, und wir entfernen es.",

  ra_agree:"Ich habe die Cuvori-Regeln und die Datenschutzerklärung gelesen und stimme zu.",
  ra_must:"Bitte lies die Regeln und stimme ihnen zu, bevor du ein Konto erstellst.",
  ra_rules:"Regeln",
  ra_privacy:"Datenschutzerklärung",
  ra_updatedTitle:"Die Regeln haben sich geändert",
  ra_updatedBody:"Wir haben die Cuvori-Regeln und die Datenschutzerklärung aktualisiert. Bitte lies sie und bestätige, um fortzufahren.",
  ra_accept:"Ich stimme zu",
  ra_later:"Erst lesen",
  ra_accepted:"Danke – gespeichert.",
  ra_report:"Melden",
  ra_reportTitle:"Ein Problem melden",
  ra_reportWhat:"Worum geht es?",
  ra_reportKind:"Art",
  ra_kindIllegal:"Illegale Inhalte",
  ra_kindRights:"Rechte einer anderen Person (Urheberrecht, Musik, Aufnahmen)",
  ra_kindScam:"Betrug oder Abzocke",
  ra_kindAbuse:"Missbrauch, Drohungen oder Belästigung",
  ra_kindFake:"Falsches Profil oder gefälschte Bewertungen",
  ra_kindOther:"Etwas anderes",
  ra_reportPh:"Was ist passiert, und wo auf Cuvori?",
  ra_reportSend:"Meldung senden",
  ra_reportSent:"Meldung gesendet. Wir prüfen jede Meldung und sagen dir, was wir getan haben.",
  ra_reportSignIn:"Melde dich an, um etwas zu melden, oder schreib an {email}.",
  ra_banReason:"Angegebener Grund:",
  ra_banObject:"Denkst du, das ist falsch, schreib an {email}, und ein Mensch prüft es erneut.",
  ra_imprint:"Cuvori wird betrieben von {company}, {address} · {email}",
  ra_waiting:"Wartende Meldungen: {n}",
  ra_waitingHint:"Öffne die Meldungsliste und sag der Person, was du getan hast."
})
