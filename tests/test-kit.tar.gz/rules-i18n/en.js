// Site rules + privacy notice — English (source). r_* = rules, pv_* = privacy, ra_* = agreement UI.
// Bodies are plain text; a line starting with "• " becomes a bullet on the page.
// Placeholders kept exactly: {email} {company} {address} {feePct} {feeFixed} {autoDays} {ver} {d}
({
  r_title:"Cuvori rules",
  r_sub:"The rules everyone on Cuvori agrees to. Plain language, no small print. Break them and you can be warned, suspended or removed — and in serious cases reported to the authorities or taken to court.",
  r_version:"Version {ver}",
  r_toPrivacy:"Privacy notice",
  r_toRules:"Rules",

  r_s1_t:"1. What Cuvori is",
  r_s1:"Cuvori is a place where clients find video editors, videographers and photographers, agree the work and record it in a contract.\n• Cuvori is not a party to the contract between a client and an editor, does not employ editors and does not do the editing work.\n• Cuvori does not promise that you will find work, find someone to hire, or that the work will be good. It promises the tools: profiles, messages, contracts, reviews and, where switched on, protected payments.\n• Cuvori takes no commission from the project price. Where a protected payment is used, the client pays a payment fee of {feePct}% + {feeFixed} on top of the price; that fee covers card and payment handling and is not returned if the money is later refunded or split.",

  r_s2_t:"2. Who can use Cuvori",
  r_s2:"• You must be at least 18 years old.\n• Use your real name and real details. One person, one account. Do not create an account for someone else or pretend to be someone you are not.\n• Keep your password to yourself. What happens under your account is your responsibility.\n• If you work as a business, say so in your profile, and keep your invoicing and taxes in order. Each side handles its own taxes.",

  r_s3_t:"3. The short version",
  r_s3:"Be honest, do the work you agreed, and pay for the work you received. Almost everything below follows from that.",

  r_s4_t:"4. What you upload and show",
  r_s4:"• You keep the rights to your own work. By uploading it you give Cuvori permission to store it and show it on Cuvori — in your profile, in search results and to people you write to — so that the site can work. That permission ends when you delete the file or your account, except for copies in backups, which are deleted as those backups roll over.\n• You confirm you hold the rights to everything you upload, including music, stock footage, fonts and anything a client gave you, and that showing it on Cuvori is allowed. If someone else's rights are infringed, that is on the person who uploaded it.\n• Do not upload: material you have no right to use; someone's private material published without their agreement; content that is illegal, violent, hateful, sexual content involving minors, or made to deceive.\n• A client's footage is not yours to publish. Show finished work in your portfolio only once the client has published it, or with the client's agreement.\n• If someone tells us your upload infringes their rights, we may take it down. Repeatedly uploading infringing material gets the account removed.",

  r_s5_t:"5. Reviews and messages",
  r_s5:"• Write reviews only about work you actually took part in, and write what really happened.\n• Do not buy, sell, trade or ask for reviews, and do not threaten a bad review to get something for free.\n• No spam, no mass messaging, no sending people off Cuvori to dodge the protections here.\n• Be civil. Insults, harassment, threats and discrimination end accounts.\n• Do not post other people's personal data in messages, profiles or reviews.",

  r_s6_t:"6. Money",
  r_s6:"• Direct payments: the client pays the editor directly. Cuvori never holds that money, charges nothing for it, and cannot get it back for you if something goes wrong — what it can do is look at the case and record its opinion.\n• Protected payments: the client pays into Cuvori's payment provider, the money is held, and it goes to the editor when the client approves the delivery, or automatically {autoDays} days after delivery if the client does nothing. Pressing \"Request changes\" or opening a dispute before those days end stops the automatic release; a message in the chat alone does not.\n• Do not use the payments here to move money for anything other than the work agreed on Cuvori.\n• If you charge back a card payment instead of using the dispute route, and the chargeback turns out to be unfounded, you owe that money back, and the account is suspended until it is settled.\n• Prices, fees and taxes shown are what you pay. If anything looks wrong, tell us before paying, not after.",

  r_s7_t:"7. When something goes wrong",
  r_s7:"• Talk to the other side first, in the Cuvori chat, where it can be seen later.\n• If that does not work, either side opens a dispute. Cuvori looks at the contract, the messages and what was delivered, and decides within 14 days, giving both sides its reasons.\n• Where the payment is protected, Cuvori pays out the held money according to that decision: to the editor, back to the client, or split to match the work actually done. Where the payment was direct, Cuvori cannot move money — its decision is a written opinion, recorded on both accounts.\n• Either side can still go to court; what Cuvori paid out is taken into account there.\n• Cuvori decides on what it can see on the site. Keep deliveries, approvals and complaints in the chat.",

  r_s8_t:"8. Things that get you removed",
  r_s8:"• Fraud: taking money without doing the work, paying with someone else's card, fake identity, fake profile, fake reviews.\n• Taking the deposit and disappearing, or accepting delivery and refusing to pay.\n• Using a new account to come back after being removed.\n• Uploading material you have no rights to, again after being told.\n• Threats, harassment, discrimination, or publishing someone's private information.\n• Anything illegal, or using Cuvori to help someone else do something illegal.\n• Trying to break the site: attacking it, abusing bugs, scraping other people's data, automating accounts.",

  r_s9_t:"9. What happens if you break the rules",
  r_s9:"What we do depends on what happened and whether it happened again:\n• a warning and a request to fix it;\n• removing the content, the job or the review in question;\n• suspending the account, so you can still read and settle what is open but not start anything new;\n• removing the account permanently;\n• in serious cases — fraud, threats, material involving minors — reporting it to the police or another authority, and going to court for money owed.\nYou will be told what happened and why, which rule it concerns, and whether the decision was automatic. You can object by writing to {email}, and a person will look at it again. If the reason is a legal obligation or a clear, serious risk to other people, we act first and explain straight after. Money already held in an open contract is not kept because of a suspension — it is settled through the dispute route.",

  r_s10_t:"10. Telling us about a problem",
  r_s10:"• Use the Report button on a profile, job, review or message, or write to {email}.\n• Say what the problem is and where it is. If it is about rights in content, say what the content is and what right it infringes.\n• We look at every report, act where the rules or the law require it, and tell you what we did.\n• Reporting things falsely and repeatedly to hurt a competitor is itself a reason to lose the account.",

  r_s11_t:"11. What Cuvori is and is not responsible for",
  r_s11:"• Cuvori is responsible for running the site honestly and carefully, for keeping its promises about protected payments, and for looking at disputes as described here.\n• Cuvori is not responsible for the work itself, for what people write to each other, for whether someone is pleasant to work with, or for a contract two other people signed.\n• The site can be down, slow or changed. Keep your own copies of your files; Cuvori is not a backup service.\n• Where Cuvori is liable to you, its liability is limited to the fees you paid to Cuvori in the 12 months before, or €500 if that is more, and it does not cover indirect losses such as lost profit. This limit does not apply where the law does not allow it to — including our own intent or gross negligence, death or personal injury, or money we hold for you in a protected payment.\n• Nothing in these rules takes away rights you have as a consumer under the law of the country where you live.",

  r_s12_t:"12. Ending it, and changes",
  r_s12:"• You can close your account at any time in Settings. Contracts with money still held have to be finished or resolved first.\n• Closing an account removes your profile, portfolio and reviews. Records of contracts and payments are kept as long as the law requires, and a record of a removal for fraud or abuse is kept so the same person cannot simply return.\n• These rules can change. If the change matters to you, we announce it on the site at least 15 days before it applies; carrying on using Cuvori after that means you accept it. If you do not, close the account.\n• A version number and date are at the top of this page, and the version you agreed to is stored with your account.",

  r_s13_t:"13. Law, courts and who we are",
  r_s13:"• These rules are governed by Lithuanian law, and the Lithuanian courts have jurisdiction. If you use Cuvori as a consumer, you keep the protection of the law of the country where you live and can bring a case in your own country's courts.\n• You can also take a consumer dispute to the Lithuanian State Consumer Rights Protection Authority or the EU online dispute platform.\n• Cuvori is run by {company}, {address}. Contact: {email}.",

  pv_title:"Privacy notice",
  pv_sub:"What Cuvori stores about you, why, and what you can ask for. Short version: only what the site needs to work, never sold.",
  pv_s1_t:"Who is responsible",
  pv_s1:"{company}, {address}, is responsible for the data described here. Questions and requests: {email}.",
  pv_s2_t:"What is stored, and why",
  pv_s2:"• Account: first name, e-mail, the language you chose, whether you are a client or an editor, and the version of the rules you agreed to. Needed to give you an account — without it there is no service.\n• Profile and portfolio: what you write about yourself, your city and country, prices, skills, and the videos and images you upload. You choose what to put there and can change or delete it.\n• Messages and contracts: what you write to each other, contract terms, deliveries, dates and amounts. Needed to run the service and to settle disputes.\n• Payments: with protected payments, the amount, the status and identifiers from Stripe. Card numbers are never sent to or stored by Cuvori — Stripe handles them. Bank details you add for direct payments are stored so clients you are working with can pay you.\n• Safety records: if an account is removed for fraud or abuse, we keep a note of that and scrambled (hashed) forms of the e-mail, card, IBAN or PayPal used, so the same person cannot immediately return under a new name. We keep these for up to 24 months, or longer if there is an open dispute or claim. This is our legitimate interest in keeping the marketplace safe; you can object to it, and we will look again at your case.\n• Technical: basic server and error logs kept for a short time for security.\n• Activity: if you have a public editor profile, it shows whether you are taking work and roughly when you were last active (the date only, never the time). It tells clients whether it is worth writing to you; you can hide it by making your profile private.",
  pv_s3_t:"Who else sees it",
  pv_s3:"• Other users see what you publish: your profile, your portfolio, your reviews, and what you write to them.\n• Service providers that run parts of Cuvori: Supabase (database and files, EU), Netlify (hosting), Cloudflare (domain and protection), Stripe (payments), and our e-mail sender. They act on our instructions.\n• Authorities, where the law requires it.\n• We never sell your data, and we do not use it for advertising.",
  pv_s4_t:"How long it is kept",
  pv_s4:"• While your account exists, and then deleted when you close it — except contract and payment records, which are kept as long as tax and accounting law requires, and the safety records described above.\n• Backups roll over within 30 days.",
  pv_s5_t:"Your rights",
  pv_s5:"You can ask for a copy of your data, correct it, delete it, object to how we use it, or ask us to send it somewhere else. Write to {email} and we answer within a month. If you are not satisfied, you can complain to the Lithuanian State Data Protection Inspectorate (VDAI) or the authority in the country where you live.",
  pv_s6_t:"Cookies and similar",
  pv_s6:"Cuvori does not use advertising or tracking cookies. It stores a few things in your browser so the site works: your sign-in session and your language choice. Clearing your browser data removes them.",
  pv_s7_t:"Children",
  pv_s7:"Cuvori is not for people under 18, and we do not knowingly keep data about them. If you think a child has an account, write to {email} and we will remove it.",

  ra_agree:"I have read and agree to the Cuvori rules and the privacy notice.",
  ra_must:"Please read and agree to the rules before creating an account.",
  ra_rules:"rules",
  ra_privacy:"privacy notice",
  ra_updatedTitle:"The rules have changed",
  ra_updatedBody:"We have updated the Cuvori rules and the privacy notice. Please read them and confirm to carry on.",
  ra_accept:"I agree",
  ra_later:"Read them first",
  ra_accepted:"Thank you — saved.",
  ra_report:"Report",
  ra_reportTitle:"Report a problem",
  ra_reportWhat:"What is the problem?",
  ra_reportKind:"Type",
  ra_kindIllegal:"Illegal content",
  ra_kindRights:"Someone else's rights (copyright, music, footage)",
  ra_kindScam:"Fraud or scam",
  ra_kindAbuse:"Abuse, threats or harassment",
  ra_kindFake:"Fake profile or fake reviews",
  ra_kindOther:"Something else",
  ra_reportPh:"What happened, and where on Cuvori is it?",
  ra_reportSend:"Send report",
  ra_reportSent:"Report sent. We look at every report and will tell you what we did.",
  ra_reportSignIn:"Sign in to report something, or write to {email}.",
  ra_banReason:"Reason given:",
  ra_banObject:"If you think this is wrong, write to {email} and a person will look at it again.",
  ra_imprint:"Cuvori is run by {company}, {address} · {email}",
  ra_waiting:"Reports waiting: {n}",
  ra_waitingHint:"Open the report queue and tell the person what you did."
})
