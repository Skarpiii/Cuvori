  // ---------- is this editor actually taking work? ----------
  // A status nobody has touched for 30 days stops counting: an abandoned profile
  // must not keep telling clients it is free.
  const AV_STALE_DAYS = 30;
  const AV_ORDER = { open:0, soon:1, busy:2, stale:3, closed:4 };

  function avToday(){ const d=new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
  function avParse(d){ if(!d) return null; const x=new Date(d); return isNaN(x) ? null : x; }
  function avDaysSince(d){ const x=avParse(d); return x ? (Date.now()-x.getTime())/86400000 : 1e9; }
  function avRaw(p){
    const r=(p&&p.raw)||{};
    return { status:["open","busy","closed"].includes(r.availability)?r.availability:"open",
             freeFrom:r.free_from||null, setAt:r.availability_set_at||null, lastActive:r.last_active_on||null };
  }
  // open = taking work · soon = busy but free within two weeks · busy · closed · stale
  function avState(p){
    const a=avRaw(p);
    // no stored status at all (an example profile, or a row from before this existed): treat it as normal, not stale
    if(a.setAt && avDaysSince(a.setAt) > AV_STALE_DAYS) return "stale";
    if(a.status==="closed") return "closed";
    if(a.status==="busy"){
      const f=avParse(a.freeFrom); if(!f) return "busy";
      if(f <= avToday()) return "open";                       // the date passed: free again
      return (f - avToday())/86400000 <= 14 ? "soon" : "busy";
    }
    return "open";
  }
  function avDateText(d){
    const x=avParse(d); if(!x) return "";
    try{ return x.toLocaleDateString(state.language,{day:"numeric",month:"short"}); }catch(e){ return x.toISOString().slice(0,10); }
  }
  function avSeenText(p){
    const a=avRaw(p); const n=avDaysSince(a.lastActive);
    if(n <= 7) return t("av_seenWeek");
    if(n <= 31) return t("av_seenMonth");
    const x=avParse(a.lastActive); if(!x) return t("av_seenLong");
    try{ return fill(t("av_seenOn"),{d:x.toLocaleDateString(state.language,{month:"long",year:"numeric"})}); }
    catch(e){ return t("av_seenLong"); }
  }
  function avText(p){
    const s=avState(p), a=avRaw(p);
    if(s==="open")   return t("av_open");
    if(s==="soon" || s==="busy") return fill(t("av_busyUntil"),{d:avDateText(a.freeFrom)});
    if(s==="closed") return t("av_closed");
    return avSeenText(p);
  }
  function avBadge(p){
    const s=avState(p);
    return `<span class="av av-${s}"><span class="av-dot"></span>${escapeHtml(avText(p))}</span>`;
  }
  function avRank(p){ return AV_ORDER[avState(p)] ?? 9; }

  // the editor's own control, shown in Edit profile
  function avPickerHtml(r){
    const st=["open","busy","closed"].includes(r.availability)?r.availability:"open";
    const ff=r.free_from||"";
    const min=new Date(Date.now()+86400000).toISOString().slice(0,10);
    const max=new Date(Date.now()+364*86400000).toISOString().slice(0,10);
    return `<label>${t("av_label")}</label>
      <div class="muted small" style="margin:-2px 0 8px">${t("av_hint")}</div>
      <div class="seg small av-seg">
        ${[["open","av_open"],["busy","av_busy"],["closed","av_closed"]].map(([v,k])=>
          `<button type="button" class="seg-btn${st===v?" active":""}" data-av="${v}">${t(k)}</button>`).join("")}
      </div>
      <div id="avFreeWrap" class="${st==="busy"?"":"hidden"}" style="margin-top:10px">
        <label>${t("av_freeFrom")}</label>
        <input type="date" id="avFreeFrom" min="${min}" max="${max}" value="${escapeHtml(ff)}">
      </div>`;
  }
  function avBindPicker(root){
    $$("[data-av]",root).forEach(b=>b.addEventListener("click",()=>{
      $$("[data-av]",root).forEach(x=>x.classList.toggle("active",x===b));
      $("#avFreeWrap",root).classList.toggle("hidden", b.dataset.av!=="busy");
      root.dataset.avTouched="1";     // an answer given on purpose restarts the 30 days
    }));
    $("#avFreeFrom",root)?.addEventListener("change",()=>{ root.dataset.avTouched="1"; });
  }
  function avReadPicker(root){
    const b=$(".av-seg .seg-btn.active",root); const status=b?b.dataset.av:"open";
    let free_from=null;
    if(status==="busy"){
      const v=($("#avFreeFrom",root)||{}).value||"";
      const d=avParse(v);
      if(d && d > avToday() && (d-avToday())/86400000 <= 364) free_from=v;
    }
    return { availability:status, free_from };
  }

  // tell the server the person was here, at most once an hour
  async function avTouch(){
    if(!REAL || !signedIn()) return;
    const k="cuvoriTouched";
    try{ if(Date.now() - Number(localStorage.getItem(k)||0) < 3600000) return; }catch(e){}
    const { error } = await sb.rpc("touch_activity");
    if(!error){ try{ localStorage.setItem(k, String(Date.now())); }catch(e){} }
  }

  // a nudge for an editor whose status has gone stale
  function avMaybeNudge(){
    if(!REAL || !signedIn() || !isEditor() || state.avNudged) return;
    const mine=PROFILES[ownKey()]; if(!mine || !mine.is_public) return;
    if(avDaysSince(avRaw(mine).setAt) <= AV_STALE_DAYS) return;
    state.avNudged=true;
    const bar=$("#avNudge"); if(!bar) return;
    bar.innerHTML=`<span>${escapeHtml(t("av_nudge"))}</span> <button class="link-btn" id="avNudgeGo">${escapeHtml(t("av_nudgeBtn"))}</button> <button class="link-btn" id="avNudgeNo">${escapeHtml(t("av_nudgeLater"))}</button>`;
    bar.classList.remove("hidden");
    $("#avNudgeGo").addEventListener("click",()=>{ bar.classList.add("hidden"); editProfileModal(ownKey()); });
    $("#avNudgeNo").addEventListener("click",()=>bar.classList.add("hidden"));
  }

  // ----- after a job is finished, the editor says whether they are free -----
  // The moment the work ends is the moment the answer is actually known, so this is
  // where the status gets kept honest. Answering sets availability_set_at, which is
  // what stops it being asked again for the same job.
  function avFinishedAt(c){
    const d = c.completed_at || c.paid_at || null;
    return d && ["completed","paid"].includes(c.status) ? d : null;
  }
  function avAfterJobCheck(rows){
    if(!REAL || !signedIn() || !isEditor()) return;
    if($("#modalRoot").innerHTML.trim() !== "") return;    // never interrupt whatever is already open

    const setAt = avRaw(PROFILES[ownKey()]).setAt;
    const since = setAt ? new Date(setAt).getTime() : 0;
    const done = (rows||[])
      .filter(c => c.editor === myId())
      .map(c => ({ c, at: avFinishedAt(c) }))
      .filter(x => x.at && new Date(x.at).getTime() > since)
      .sort((a,b) => new Date(b.at) - new Date(a.at))[0];
    if(done) avAfterJobModal(done.c);
  }
  function avAfterJobModal(c){
    const min=new Date(Date.now()+86400000).toISOString().slice(0,10);
    const max=new Date(Date.now()+364*86400000).toISOString().slice(0,10);
    openModal(t("av_doneTitle"),
      `<p>${escapeHtml(fill(t("av_doneBody"),{title:c.title||""}))}</p>
       <div class="av-choices">
         <button class="primary" data-avpick="open">${escapeHtml(t("av_open"))}</button>
         <button class="secondary" data-avpick="busy">${escapeHtml(t("av_busy"))}</button>
         <button class="secondary" data-avpick="closed">${escapeHtml(t("av_closed"))}</button>
       </div>
       <div id="avDoneDate" class="hidden" style="margin-top:12px">
         <label>${escapeHtml(t("av_freeFrom"))}</label>
         <input type="date" id="avDoneFrom" min="${min}" max="${max}">
         <button class="primary" id="avDoneSave" style="margin-top:10px;width:100%">${escapeHtml(t("p_saveChanges"))}</button>
       </div>
       <p class="muted small" style="margin-top:12px">${escapeHtml(t("av_doneHint"))}</p>`,
      root=>{
        const save=async(status, free_from)=>{
          const ok=await avSaveStatus(status, free_from);
          if(!ok) return;
          closeModal();
          toast(t("av_saved"));
          await loadOwnEditorProfile(); await loadEditors();
        };
        $$("[data-avpick]",root).forEach(b=>b.addEventListener("click",()=>{
          const v=b.dataset.avpick;
          if(v==="busy"){ $("#avDoneDate",root).classList.remove("hidden"); $("#avDoneFrom",root).focus(); return; }
          save(v, null);
        }));
        $("#avDoneSave",root).addEventListener("click",()=>{
          const v=$("#avDoneFrom",root).value;
          if(!v){ toast(t("a_fillAll")); return; }
          save("busy", v);
        });
      }, "locked");
  }
  async function avSaveStatus(availability, free_from){
    if(!REAL) return true;
    const { data, error } = await sb.rpc("set_availability",{ p_status:availability, p_free_from: availability==="busy" ? free_from : null });
    if(error || data!=="ok"){ toast(errText(error,data)); return false; }
    return true;
  }
